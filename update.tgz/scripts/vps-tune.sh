#!/bin/bash
# One-shot VPS tune for Katana on cPanel (Apache + Node + PGlite).
set -euo pipefail
APP=/home/dewastoreid/kaliaren
PUBLIC="$APP/.output/public"
STORE=store.ahtagroup.com
USER=dewastoreid

if [[ ! -d "$APP" ]]; then
  echo "app tidak ada: $APP" >&2
  exit 1
fi

write_proxy() {
  local dir="$1"
  mkdir -p "$dir"
  cat > "$dir/proxy.conf" <<EOF
ProxyPreserveHost On
RequestHeader set X-Forwarded-Proto "https"
ProxyTimeout 60
Alias /assets ${PUBLIC}/assets
<Directory "${PUBLIC}/assets">
  Options -Indexes
  AllowOverride None
  Require all granted
  <IfModule mod_headers.c>
    Header set Cache-Control "public, max-age=31536000, immutable"
  </IfModule>
</Directory>
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript application/json image/svg+xml
</IfModule>
ProxyPass /assets !
ProxyPass / http://127.0.0.1:3000/ connectiontimeout=5 timeout=60 keepalive=On ttl=120
ProxyPassReverse / http://127.0.0.1:3000/
EOF
}

write_proxy "/etc/apache2/conf.d/userdata/std/2_4/${USER}/${STORE}"
write_proxy "/etc/apache2/conf.d/userdata/ssl/2_4/${USER}/${STORE}"

install -m 644 "$APP/scripts/kaliaren.service" /etc/systemd/system/kaliaren.service
grep -q '^NODE_ENV=' "$APP/.env" 2>/dev/null || echo 'NODE_ENV=production' >> "$APP/.env"
sed -i 's/^NODE_OPTIONS=.*/NODE_OPTIONS=--max-old-space-size=384 --dns-result-order=ipv4first/' "$APP/.env" 2>/dev/null || true
grep -q '^NODE_OPTIONS=' "$APP/.env" || echo 'NODE_OPTIONS=--max-old-space-size=384 --dns-result-order=ipv4first' >> "$APP/.env"
chown "$USER:$USER" "$APP/.env"

if ! swapon --show | grep -q .; then
  if [[ ! -f /swapfile ]]; then
    fallocate -l 1G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=1024
    chmod 600 /swapfile
    mkswap /swapfile
  fi
  swapon /swapfile || true
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi
sysctl -w vm.swappiness=10 >/dev/null
grep -q '^vm.swappiness' /etc/sysctl.conf || echo 'vm.swappiness=10' >> /etc/sysctl.conf

if [[ -x /scripts/ensure_vhost_includes ]]; then
  /scripts/ensure_vhost_includes --user="$USER" >/dev/null 2>&1 || true
fi
if [[ -x /scripts/rebuildhttpdconf ]]; then
  /scripts/rebuildhttpdconf >/dev/null
  /scripts/restartsrv_httpd >/dev/null
else
  systemctl reload httpd 2>/dev/null || true
fi

systemctl daemon-reload
systemctl enable kaliaren >/dev/null
systemctl restart kaliaren
sleep 2
echo "---"
systemctl is-active kaliaren
free -h | head -2
swapon --show || true
echo "ok tune"
