#!/bin/bash
set -euo pipefail
APP=/home/dewastoreid/kaliaren
rm -rf "$APP/.vercel"
find "$APP/.output/public/assets" -name 'pglite-*' -delete 2>/dev/null || true
echo "== besar di app (bukan node_modules) =="
du -sh "$APP" "$APP/.output" "$APP/node_modules" "$APP/data" "$APP/.git" 2>/dev/null || true
echo "== tarball /tmp =="
ls -lh /tmp/kaliaren*.tgz /tmp/update.tgz 2>/dev/null || echo "(kosong)"
rm -f /tmp/kaliaren*.tgz /tmp/update.tgz /tmp/kaliaren-src.tgz
echo "== npm cache =="
sudo -u dewastoreid npm cache clean --force >/dev/null 2>&1 || true
echo "== file > 1MB di luar node_modules =="
find "$APP" -path "$APP/node_modules" -prune -o -path "$APP/.git" -prune -o -type f -size +1M -printf '%10s  %p\n' 2>/dev/null | sort -n
echo "== duplikat nama di public =="
find "$APP/public" -type f | awk -F/ '{print $NF}' | sort | uniq -d || true
echo "ok clean"
