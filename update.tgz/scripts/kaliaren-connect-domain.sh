#!/bin/bash
# Attach an ad domain to the Kaliaren vhost (store) via ServerAlias + proxy.
set -euo pipefail
DOMAIN="${1:-}"
USER="${KALIAREN_CPANEL_USER:-dewastoreid}"
STORE="${KALIAREN_STORE_HOST:-store.ahtagroup.com}"
if [[ ! "$DOMAIN" =~ ^[a-z0-9.-]+\.[a-z]{2,}$ ]]; then
  echo "domain tidak valid" >&2
  exit 1
fi

write_proxy() {
  local dir="$1"
  mkdir -p "$dir"
  cat > "$dir/proxy.conf" <<'EOF'
ProxyPreserveHost On
RequestHeader set X-Forwarded-Proto "https"
ProxyTimeout 60
Alias /assets /home/dewastoreid/kaliaren/.output/public/assets
<Directory "/home/dewastoreid/kaliaren/.output/public/assets">
  Options -Indexes
  AllowOverride None
  Require all granted
  <IfModule mod_headers.c>
    Header set Cache-Control "public, max-age=31536000, immutable"
  </IfModule>
</Directory>
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript application/json image/svg+xml
</IfModule>
ProxyPass /assets !
ProxyPass / http://127.0.0.1:3000/ connectiontimeout=5 timeout=60 keepalive=On ttl=120
ProxyPassReverse / http://127.0.0.1:3000/
EOF
}

alias_file() {
  local dir="$1"
  mkdir -p "$dir"
  local f="$dir/alias-lp.conf"
  touch "$f"
  grep -qx "ServerAlias ${DOMAIN}" "$f" 2>/dev/null || echo "ServerAlias ${DOMAIN}" >> "$f"
}

write_proxy "/etc/apache2/conf.d/userdata/std/2_4/${USER}/${STORE}"
write_proxy "/etc/apache2/conf.d/userdata/ssl/2_4/${USER}/${STORE}"
write_proxy "/etc/apache2/conf.d/userdata/std/2_4/${USER}/${DOMAIN}"
write_proxy "/etc/apache2/conf.d/userdata/ssl/2_4/${USER}/${DOMAIN}"
alias_file "/etc/apache2/conf.d/userdata/std/2_4/${USER}/${STORE}"
alias_file "/etc/apache2/conf.d/userdata/ssl/2_4/${USER}/${STORE}"

if [[ -x /scripts/ensure_vhost_includes ]]; then
  /scripts/ensure_vhost_includes --user="$USER" >/dev/null 2>&1 || true
fi
if [[ -x /scripts/rebuildhttpdconf ]]; then
  /scripts/rebuildhttpdconf >/dev/null
  /scripts/restartsrv_httpd >/dev/null
fi
echo "ok $DOMAIN"
