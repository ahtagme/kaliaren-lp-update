import { copyFileSync, existsSync, mkdirSync, readdirSync, rmSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = join(root, "node_modules/@electric-sql/pglite/dist");
const dest = join(root, ".output/server/_libs");

if (!existsSync(src) || !existsSync(join(root, ".output/server"))) process.exit(0);
mkdirSync(dest, { recursive: true });

for (const name of readdirSync(src)) {
  if (!name.endsWith(".wasm") && !name.endsWith(".data")) continue;
  copyFileSync(join(src, name), join(dest, name));
}

const publicAssets = join(root, ".output/public/assets");
if (existsSync(publicAssets)) {
  for (const name of readdirSync(publicAssets)) {
    if (name.startsWith("pglite-") && (name.endsWith(".wasm") || name.endsWith(".data"))) {
      rmSync(join(publicAssets, name));
    }
  }
}