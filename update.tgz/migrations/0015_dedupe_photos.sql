delete from product_photos a
where exists (
  select 1 from product_photos b
  where b.product_id = a.product_id
    and b.data = a.data
    and b.id < a.id
);
