alter table landing_pages
  add column if not exists checkout_url text not null default '';
