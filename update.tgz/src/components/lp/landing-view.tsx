import type { LandingPage } from "@/lib/lp";
import { rupiah } from "@/lib/utils";
import { OrderOnlineForm } from "@/components/lp/orderonline-form";
import { LpCreative } from "@/components/lp/lp-creative";
import { AdPixels } from "@/components/lp/ad-pixels";
import { scrollToLpForm, trackLpCheckout } from "@/lib/lp-pixels";

function scrollToForm() {
  trackLpCheckout();
  scrollToLpForm();
}

function FormBlock({
  page,
}: {
  page: LandingPage;
}) {
  if (page.embed) {
    return <OrderOnlineForm embed={page.embed} html={page.embedCode} />;
  }
  if (page.checkoutUrl) {
    return (
      <div id="pesan" className="scroll-mt-3 px-4 py-2">
        <a
          href={page.checkoutUrl}
          rel="noopener noreferrer"
          onClick={() => trackLpCheckout()}
          className="flex h-12 w-full items-center justify-center rounded-full bg-[#e11d2e] text-[15px] font-bold text-white uppercase"
        >
          Isi form pemesanan
        </a>
      </div>
    );
  }
  return (
    <div
      id="pesan"
      className="scroll-mt-3 rounded-xl bg-white px-4 py-6 text-center"
    >
      <p className="text-base text-[#666]">Form pemesanan belum dipasang.</p>
    </div>
  );
}

export function LandingView({
  page,
  embedFormOnly = false,
}: {
  page: LandingPage;
  embedFormOnly?: boolean;
}) {
  if (embedFormOnly) {
    return (
      <div className="lp mx-auto min-h-dvh w-full max-w-md min-w-0 overflow-x-hidden bg-white px-5 py-6 text-[#111]">
        <AdPixels
          metaPixelId={page.metaPixelId}
          tiktokPixelId={page.tiktokPixelId}
          sku={page.sku}
          productName={page.productName}
          price={page.price}
        />
        <p className="text-center text-sm font-medium tracking-[0.16em] text-[#666] uppercase">
          {page.productName}
        </p>
        <div className="mt-4">
          <FormBlock page={page} />
        </div>
      </div>
    );
  }

  return (
    <main className="flex min-h-dvh w-full max-w-full justify-center overflow-x-hidden bg-[#111] text-[#111]">
      <AdPixels
        metaPixelId={page.metaPixelId}
        tiktokPixelId={page.tiktokPixelId}
        sku={page.sku}
        productName={page.productName}
        price={page.price}
      />
      <div
        className={`lp w-full min-w-0 max-w-md overflow-x-hidden bg-white ${page.embed || page.checkoutUrl ? "pb-[calc(5.5rem+env(safe-area-inset-bottom,0px))]" : ""}`}
      >
        <LpCreative page={page} form={page.embed ? <FormBlock page={page} /> : null} />
        {page.embed || page.checkoutUrl ? (
          <div className="fixed inset-x-0 bottom-0 z-40 border-t border-black/10 bg-white/95 px-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))] pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-sm">
            <div className="mx-auto flex w-full max-w-md min-w-0 items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-[#666]">{page.productName}</p>
                <p className="font-bold tabular-nums text-[#e11d2e]">{rupiah(page.price)}</p>
              </div>
              {page.checkoutUrl ? (
                <a
                  href={page.checkoutUrl}
                  rel="noopener noreferrer"
                  onClick={() => trackLpCheckout()}
                  className="grid h-12 min-h-11 min-w-28 shrink-0 place-items-center rounded-full bg-[#e11d2e] px-5 text-[15px] font-bold text-white uppercase"
                >
                  {page.ctaPrimary || "PESAN"}
                </a>
              ) : (
                <button
                  type="button"
                  onClick={scrollToForm}
                  className="h-12 min-h-11 min-w-28 shrink-0 rounded-full bg-[#e11d2e] px-5 text-[15px] font-bold text-white uppercase"
                >
                  {page.ctaPrimary || "PESAN"}
                </button>
              )}
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}
