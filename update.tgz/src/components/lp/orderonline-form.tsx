import { useEffect, useRef } from "react";
import type { OrderOnlineEmbed } from "@/lib/orderonline";
import {
  OO_EMBED_SRC,
  OO_JQUERY_SRC,
  extractOoefHtml,
} from "@/lib/orderonline";
import { scrollToLpForm } from "@/lib/lp-pixels";

type OoeFn = {
  (...args: unknown[]): void;
  callMethod?: (...args: unknown[]) => void;
  queue: unknown[];
  loaded: boolean;
  version: string;
  push: OoeFn;
};

declare global {
  interface Window {
    ooe?: OoeFn;
    _ooe?: OoeFn;
    jQuery?: unknown;
    __lpWantForm?: boolean;
    __ooBoot?: Record<string, number>;
  }
}

function ensureOoe(): OoeFn {
  if (window.ooe) return window.ooe;
  const ooe = ((...args: unknown[]) => {
    if (ooe.callMethod) ooe.callMethod(...args);
    else ooe.queue.push(args);
  }) as OoeFn;
  ooe.queue = [];
  ooe.loaded = true;
  ooe.version = "8.0.2";
  ooe.push = ooe;
  window.ooe = ooe;
  window._ooe = ooe;
  return ooe;
}

function loadScript(src: string, id: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const existing = document.getElementById(id) as HTMLScriptElement | null;
    if (existing) {
      if (existing.dataset.ready === "1" || (id === "oo-embed-jquery" && window.jQuery)) {
        existing.dataset.ready = "1";
        resolve();
        return;
      }
      existing.addEventListener("load", () => {
        existing.dataset.ready = "1";
        resolve();
      }, { once: true });
      existing.addEventListener("error", () => reject(new Error("script")), { once: true });
      return;
    }
    const el = document.createElement("script");
    el.id = id;
    el.src = src;
    el.async = true;
    el.onload = () => {
      el.dataset.ready = "1";
      resolve();
    };
    el.onerror = () => reject(new Error("script"));
    document.head.appendChild(el);
  });
}

function bootOfficial(embed: OrderOnlineEmbed) {
  window.__ooBoot = window.__ooBoot || {};
  if (window.__ooBoot[embed.formId]) return;
  window.__ooBoot[embed.formId] = 1;
  const ooe = ensureOoe();
  ooe("setup", "redirect", embed.redirect);
  ooe("init", embed.storeId, embed.productId, null, embed.formId, {
    mode: embed.mode || "page",
    action: embed.action || "Klik untuk pemesanan",
    title: embed.title || "Form Pemesanan",
    triggerPixel: false,
    triggerGtm: false,
  });
}

export function OrderOnlineForm({
  embed,
  html,
}: {
  embed: OrderOnlineEmbed;
  html?: string;
}) {
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = boxRef.current;
    if (!host) return;
    host.innerHTML = extractOoefHtml(html ?? "", embed);
    bootOfficial(embed);
    let cancelled = false;
    loadScript(OO_JQUERY_SRC, "oo-embed-jquery")
      .then(() => loadScript(OO_EMBED_SRC, "oo-embed-js"))
      .then(() => {
        if (cancelled) return;
        if (window.__lpWantForm) scrollToLpForm();
      })
      .catch(() => {
        /* keep markup; slim.js may still hydrate later */
      });
    return () => {
      cancelled = true;
    };
  }, [embed.formId, embed.storeId, embed.productId, html]);

  return <div id="pesan" ref={boxRef} className="lp-form scroll-mt-4" />;
}
