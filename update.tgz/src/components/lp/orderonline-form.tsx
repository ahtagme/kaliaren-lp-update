import { useEffect, useRef, useState } from "react";
import type { OrderOnlineEmbed } from "@/lib/orderonline";
import { OO_EMBED_SRC, OO_JQUERY_SRC, orderOnlineBootScript } from "@/lib/orderonline";
import { scrollToLpForm } from "@/lib/lp-pixels";

type OoeFn = {
  (...args: unknown[]): void;
  callMethod?: (...args: unknown[]) => void;
  queue: unknown[];
  loaded: boolean;
  version: string;
  push: OoeFn;
};

declare global {
  interface Window {
    ooe?: OoeFn;
    _ooe?: OoeFn;
    jQuery?: unknown;
    __lpWantForm?: boolean;
    __ooBoot?: number;
  }
}

function loadScript(src: string, id: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const existing = document.getElementById(id) as HTMLScriptElement | null;
    if (existing) {
      if (existing.dataset.ready === "1" || (id === "oo-embed-jquery" && window.jQuery)) {
        existing.dataset.ready = "1";
        resolve();
        return;
      }
      existing.addEventListener("load", () => {
        existing.dataset.ready = "1";
        resolve();
      }, { once: true });
      existing.addEventListener("error", () => reject(new Error("Gagal memuat form")), {
        once: true,
      });
      return;
    }
    const el = document.createElement("script");
    el.id = id;
    el.src = src;
    el.async = true;
    el.onload = () => {
      el.dataset.ready = "1";
      resolve();
    };
    el.onerror = () => reject(new Error("Gagal memuat form"));
    document.head.appendChild(el);
  });
}

let scriptsPromise: Promise<void> | null = null;

function loadOrderOnlineScripts(): Promise<void> {
  if (!scriptsPromise) {
    scriptsPromise = (async () => {
      if (!window.jQuery) await loadScript(OO_JQUERY_SRC, "oo-embed-jquery");
      await loadScript(OO_EMBED_SRC, "oo-embed-js");
    })();
  }
  return scriptsPromise;
}

function formLooksReady(root: HTMLElement | null) {
  if (!root) return false;
  if (root.querySelector("input, textarea, select, iframe")) return true;
  if (root.querySelector(".ooef-field-name, .ooef-form, .orderonline-embed-form > *")) return true;
  return false;
}

function fitIframes(root: HTMLElement | null) {
  if (!root) return;
  root.querySelectorAll("iframe").forEach((frame) => {
    frame.setAttribute("width", "100%");
    frame.style.width = "100%";
    frame.style.maxWidth = "100%";
    frame.style.minHeight = "36rem";
    frame.style.border = "0";
  });
}

export function OrderOnlineForm({
  embed,
}: {
  embed: OrderOnlineEmbed;
  eager?: boolean;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    let cancelled = false;
    const root = () => boxRef.current;
    const markReady = () => {
      if (cancelled) return;
      fitIframes(root());
      setStatus("ready");
      if (window.__lpWantForm) scrollToLpForm();
    };
    const check = () => {
      if (cancelled) return;
      if (formLooksReady(root())) markReady();
    };
    const mo = new MutationObserver(() => {
      fitIframes(root());
      check();
    });
    if (boxRef.current) {
      mo.observe(boxRef.current, { childList: true, subtree: true, attributes: true });
    }
    loadOrderOnlineScripts()
      .then(check)
      .catch(() => {
        if (!cancelled) setStatus("error");
      });
    const readyTimer = window.setTimeout(markReady, 2200);
    const retry = window.setInterval(check, 400);
    return () => {
      cancelled = true;
      mo.disconnect();
      window.clearTimeout(readyTimer);
      window.clearInterval(retry);
    };
  }, [embed.formId]);

  return (
    <div id="pesan" ref={boxRef} className="lp-form scroll-mt-4">
      {status === "loading" ? (
        <div className="mb-3 grid gap-2" aria-hidden>
          <p className="text-[16px] font-bold">Data Penerima:</p>
          <div className="h-12 rounded-md bg-[#eee]" />
          <div className="h-12 rounded-md bg-[#eee]" />
          <div className="h-24 rounded-md bg-[#eee]" />
        </div>
      ) : null}
      {status === "error" ? (
        <p className="py-3 text-center text-[15px] text-[#9a3428]">
          Form belum tampil di HP ini.
        </p>
      ) : null}
      <div className="ooef" suppressHydrationWarning>
        <form
          className="orderonline-embed-form"
          data-username={embed.username}
          data-product-slug={embed.productSlug}
          data-product-id={embed.productId}
          id={embed.formId}
          data-origin={embed.origin}
          suppressHydrationWarning
        />
      </div>
      <script dangerouslySetInnerHTML={{ __html: orderOnlineBootScript(embed) }} />
    </div>
  );
}
