import {
  BadgeCheck,
  Camera,
  Clock,
  Droplets,
  Hand,
  Headset,
  Leaf,
  MessageCircle,
  Package,
  PackageCheck,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Star,
  Truck,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";
import type { LandingPage } from "@/lib/lp";
import {
  LP_CUSTOMER_PROOF,
  LP_DEFAULT_TESTIMONIALS,
  LP_EDU,
  LP_PERKS,
  LP_SHIPPING_PROOF,
  LP_TRUST,
  lpHeadline,
  lpPhotos,
  lpPunch,
} from "@/lib/lp-template";
import { angka } from "@/lib/utils";
import { scrollToLpForm, trackLpCheckout } from "@/lib/lp-pixels";
import { cdnSrc } from "@/lib/cdn";

function scrollToForm() {
  trackLpCheckout();
  scrollToLpForm();
}

function Cta({
  label,
  pulse,
  href,
}: {
  label: string;
  pulse?: boolean;
  href?: string;
}) {
  const className = `flex h-12 min-h-11 w-full items-center justify-center gap-2 rounded-full bg-[#e11d2e] text-[15px] font-bold tracking-wide text-white uppercase ${pulse ? "cta-pulse" : ""}`;
  const inner = (
    <>
      <ShoppingCart className="size-5" />
      {label}
      <span className="text-lg leading-none">›</span>
    </>
  );
  if (href) {
    return (
      <a
        href={href}
        className={className}
        rel="noopener noreferrer"
        onClick={() => trackLpCheckout()}
      >
        {inner}
      </a>
    );
  }
  return (
    <button type="button" onClick={scrollToForm} className={className}>
      {inner}
    </button>
  );
}

function SectionTitle({ children }: { children: string }) {
  const words = children.trim().split(/\s+/);
  const last = words.pop() ?? "";
  return (
    <h2 className="text-center text-[22px] font-black tracking-tight text-balance uppercase">
      {words.length ? `${words.join(" ")} ` : null}
      <span className="relative inline-block">
        <span className="absolute inset-x-0 bottom-0.5 h-2 bg-[#d4f01a]" />
        <span className="relative">{last}</span>
      </span>
    </h2>
  );
}

const WHY_ICONS = [Droplets, Leaf, Hand, Users] as const;
const BADGE_ICONS = [ShieldCheck, PackageCheck, Clock] as const;
const BADGE_LABELS = ["100% ORIGINAL", "READY STOCK", "STOK TERBATAS"] as const;

export function LpCreative({
  page,
  id = "lp-creative",
  form,
}: {
  page: LandingPage;
  id?: string;
  form?: ReactNode;
}) {
  const photos = lpPhotos(page);
  const cdnBase = page.cdnBase ?? "";
  function Photo({
    src,
    className,
    priority,
    width,
    height,
    sizes,
  }: {
    src: string;
    className: string;
    priority?: boolean;
    width?: number;
    height?: number;
    sizes?: string;
  }) {
    return (
      <img
        src={cdnSrc(src, cdnBase)}
        alt=""
        width={width ?? 640}
        height={height ?? 640}
        sizes={
          sizes ??
          (priority ? "(max-width: 28rem) 100vw, 448px" : "(max-width: 28rem) 50vw, 220px")
        }
        className={className}
        decoding="async"
        loading={priority ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : "auto"}
      />
    );
  }

  const hero = photos[0];
  const extra = photos.slice(1);
  const thumbs = extra.slice(0, 2);
  const eduPhoto = extra[2] || "";
  const benefits = (page.benefits.length
    ? page.benefits
    : ["Stok gudang", "Barang sesuai foto", "Sisa terbatas", "Banyak yang ambil"]
  )
    .map((item) => item.replace(/COD\s*cek\s*dulu/gi, "Barang sesuai foto"))
    .slice(0, 4);
  const specs = (page.specs.length ? page.specs.map((s) => s.value) : LP_EDU).slice(0, 4);
  const stories = (page.testimonials.length ? page.testimonials : LP_DEFAULT_TESTIMONIALS).slice(0, 3);
  const headline = lpHeadline(page);
  const sub = lpPunch(page);
  const cta1 = "PESAN SEKARANG";
  const cta2 = "CHECKOUT SEKARANG";
  const close = page.formNote?.trim() || "Kalau memang mau, order sekarang";
  const brand = page.productName.split(/\s+/)[0]?.toUpperCase() || "KALIAREN";

  return (
    <article id={id} className="lp-creative bg-white text-[#111]">
      <section className="px-4 pt-5 pb-5">
        <p className="text-center text-[11px] font-semibold tracking-[0.18em] text-[#111] uppercase">
          {brand} <span className="mx-1 text-[#999]">|</span> Official Store
        </p>

        {hero ? (
          <div className="-mx-4 mt-3 bg-white">
            <Photo
              src={hero}
              priority
              width={720}
              height={900}
              sizes="(max-width: 28rem) 100vw, 448px"
              className="block h-auto w-full object-contain"
            />
          </div>
        ) : null}

        <h1 className="mt-4 text-center text-[26px] leading-[1.15] font-black tracking-tight text-balance uppercase">
          {headline}
        </h1>
        <p className="mt-3 bg-[#d4f01a] px-3 py-2.5 text-center text-[22px] leading-snug font-black tracking-tight text-[#111] uppercase">
          {sub}
        </p>
        <p className="mt-3 text-center text-[15px] leading-snug text-[#333]">
          {benefits.slice(0, 3).join(" · ")}
        </p>

        <ul className="mt-4 flex justify-center gap-4">
          {BADGE_LABELS.map((label, i) => {
            const Icon = BADGE_ICONS[i] ?? ShieldCheck;
            return (
              <li key={label} className="grid w-20 justify-items-center gap-1 text-center">
                <span className="grid size-11 place-items-center rounded-full bg-[#111] text-white">
                  <Icon className="size-5" />
                </span>
                <p className="text-[10px] font-bold leading-tight uppercase">{label}</p>
              </li>
            );
          })}
        </ul>

        <div className="mt-4">
          <Cta label={cta1} href={page.checkoutUrl} />
        </div>
        {form ? <div className="mt-5">{form}</div> : null}

        {thumbs.length ? (
          <div className="mt-4 grid grid-cols-2 gap-2">
            {thumbs.map((src, i) => (
              <figure key={src} className="overflow-hidden bg-white">
                <Photo
                  src={src}
                  width={360}
                  height={360}
                  sizes="(max-width: 28rem) 50vw, 200px"
                  className="aspect-square w-full object-contain"
                />
                <figcaption className="px-2 py-1.5 text-center text-[11px] font-semibold text-[#111]">
                  {i === 0 ? "Masalahnya" : "Pakai rutin"}
                </figcaption>
              </figure>
            ))}
          </div>
        ) : null}
      </section>

      <section className="px-4 py-6">
        <SectionTitle>Kenapa banyak dipilih?</SectionTitle>
        <ul className="mt-5 grid grid-cols-2 gap-2 min-[380px]:grid-cols-4">
          {benefits.map((item, i) => {
            const Icon = WHY_ICONS[i] ?? Sparkles;
            return (
              <li
                key={item}
                className="grid justify-items-center gap-2 rounded-xl bg-[#f6f6f6] px-1 py-3 text-center"
              >
                <span className="grid size-11 place-items-center rounded-full bg-[#111] text-white">
                  <Icon className="size-5" />
                </span>
                <p className="text-[11px] font-bold leading-snug">{item}</p>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="lp-defer px-4 py-2 pb-6">
        <SectionTitle>Rutin pakai, hasilnya lebih terasa</SectionTitle>
        <div className="mt-4 grid gap-4">
          {eduPhoto ? (
            <Photo
              src={eduPhoto}
              width={640}
              height={640}
              className="mx-auto max-h-56 w-auto object-contain"
            />
          ) : null}
          <ul className="grid gap-2.5">
            {specs.map((line) => (
              <li key={line} className="flex gap-2 text-[15px] font-semibold leading-snug">
                <BadgeCheck className="mt-0.5 size-5 shrink-0 text-[#2f6b4f]" />
                {line}
              </li>
            ))}
          </ul>
          <p className="bg-[#d4f01a] px-3 py-2.5 text-center text-[15px] font-bold leading-snug">
            Semakin rutin dipakai, semakin maksimal perawatannya.
          </p>
        </div>
      </section>

      <section className="lp-defer bg-[#111] px-4 py-5 text-white">
        <p className="text-center text-[20px] font-black tracking-tight uppercase">
          <span className="text-[#d4f01a]">7 keuntungan</span> belanja di sini
        </p>
        <ol className="mt-4 grid gap-2">
          {LP_PERKS.map((line, i) => (
            <li key={line} className="flex items-center gap-3 text-[15px] font-medium">
              <span className="grid size-7 shrink-0 place-items-center rounded-full bg-[#d4f01a] text-[13px] font-black text-[#111]">
                {i + 1}
              </span>
              {line}
            </li>
          ))}
        </ol>
      </section>

      <section className="lp-defer px-4 py-6">
        <SectionTitle>Sudah banyak yang order</SectionTitle>
        <ul className="mt-4 grid gap-3">
          {stories.map((t) => (
            <li key={t.name + t.city} className="rounded-xl bg-[#f6f6f6] px-4 py-3">
              <span className="inline-flex text-[#e2b00f]">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={i < t.rating ? "size-3.5 fill-[#e2b00f]" : "size-3.5"} />
                ))}
              </span>
              <p className="mt-1 text-[14px] leading-snug font-medium">“{t.text}”</p>
              <p className="mt-1 text-[12px] text-[#666]">Pembeli {t.city}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="lp-defer">
        <Photo
          src={LP_SHIPPING_PROOF}
          className="h-auto w-full"
          width={720}
          height={480}
          sizes="(max-width: 28rem) 100vw, 448px"
        />
        <Photo
          src={LP_CUSTOMER_PROOF}
          className="h-auto w-full"
          width={720}
          height={480}
          sizes="(max-width: 28rem) 100vw, 448px"
        />
      </section>

      <section className="lp-defer px-4 py-5">
        <div className="flex items-center gap-3 rounded-xl bg-[#f6f6f6] px-4 py-4">
          <Clock className="size-10 shrink-0 text-[#e11d2e]" />
          <div>
            <p className="text-[18px] font-black uppercase leading-tight">
              Jangan tunggu <span className="text-[#e11d2e]">kehabisan</span>
            </p>
            <p className="mt-1 text-[13px] leading-snug text-[#444]">
              Sisa {angka(page.stockQty)} pcs. Promo bisa berakhir kapan saja.
            </p>
          </div>
        </div>
      </section>

      <section className="lp-defer px-4 pb-5">
        <p className="text-center text-[18px] font-black uppercase">Belanja aman, nggak ribet</p>
        <ul className="mt-3 grid grid-cols-3 gap-2 text-center">
          {[
            { icon: Camera, label: LP_TRUST[0] },
            { icon: Package, label: LP_TRUST[1] },
            { icon: MessageCircle, label: LP_TRUST[2] },
          ].map((item) => (
            <li key={item.label} className="grid justify-items-center gap-1.5 rounded-lg bg-[#f6f6f6] px-1 py-3">
              <item.icon className="size-5" />
              <p className="text-[11px] font-semibold leading-snug">{item.label}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="lp-defer bg-[#0b0b0b] px-4 py-7 text-white">
        <p className="text-center text-[15px] font-semibold leading-snug text-balance uppercase">
          {close}
        </p>
        <p className="mt-2 text-center text-[22px] font-black leading-snug text-[#d4f01a] uppercase">
          Order sekarang
        </p>
        <p className="mt-2 text-center text-[13px] leading-snug text-white/70">
          Jangan cuma lihat-lihat. Selagi ready, langsung checkout.
        </p>
        <div className="mt-4">
          <Cta label={cta2} pulse href={page.checkoutUrl} />
        </div>
        <ul className="mt-4 flex flex-wrap justify-center gap-x-4 gap-y-1 text-[11px] text-white/75">
          <li className="inline-flex items-center gap-1">
            <ShieldCheck className="size-3.5" /> Original
          </li>
          <li className="inline-flex items-center gap-1">
            <Truck className="size-3.5" /> Siap kirim
          </li>
          <li className="inline-flex items-center gap-1">
            <Headset className="size-3.5" /> Dipakai rutin
          </li>
        </ul>
      </section>
    </article>
  );
}
