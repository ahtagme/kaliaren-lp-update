import { useEffect, useState, type ReactNode } from "react";
import { AuthProvider } from "@/lib/auth/provider";
import { AppShell } from "@/components/app-shell";
import { Toaster } from "sonner";
import { listWarehouses } from "@/lib/inventory-fn";
import type { Warehouse } from "@/lib/inventory";

export default function StaffRoot({ children }: { children: ReactNode }) {
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  useEffect(() => {
    listWarehouses()
      .then(setWarehouses)
      .catch(() => setWarehouses([]));
  }, []);
  return (
    <AuthProvider>
      <AppShell warehouses={warehouses}>{children}</AppShell>
      <Toaster position="top-center" toastOptions={{ className: "font-sans" }} />
    </AuthProvider>
  );
}
