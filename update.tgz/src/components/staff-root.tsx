import type { ReactNode } from "react";
import { AuthProvider } from "@/lib/auth/provider";
import { AppShell } from "@/components/app-shell";
import { Toaster } from "sonner";
import type { Warehouse } from "@/lib/inventory";

export default function StaffRoot({
  children,
  warehouses,
}: {
  children: ReactNode;
  warehouses: Warehouse[];
}) {
  return (
    <AuthProvider>
      <AppShell warehouses={warehouses}>{children}</AppShell>
      <Toaster position="top-center" toastOptions={{ className: "font-sans" }} />
    </AuthProvider>
  );
}
