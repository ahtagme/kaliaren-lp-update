import { Link, useRouterState } from "@tanstack/react-router";
import {
  ClipboardCheck,
  History,
  LayoutDashboard,
  Package,
  ArrowLeftRight,
  Warehouse as WarehouseIcon,
  ChevronDown,
  Check,
  Users,
  Megaphone,
  ShoppingBag,
  Settings,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { pickWarehouse, useWarehouseStore } from "@/lib/warehouse-store";
import { WarehouseListContext } from "@/lib/use-active-warehouse";
import type { Warehouse } from "@/lib/inventory";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  RedirectToSignIn,
  UserButton,
} from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMyStaff, type StaffRole } from "@/lib/staff-fn";

const NAV = [
  { to: "/", label: "Beranda", icon: LayoutDashboard, exact: true },
  { to: "/stok", label: "Stok", icon: Package, exact: false },
  { to: "/catat", label: "Catat", icon: ArrowLeftRight, exact: false },
  { to: "/opname", label: "Opname", icon: ClipboardCheck, exact: false },
  { to: "/riwayat", label: "Riwayat", icon: History, exact: false },
] as const;

const EXTRA_NAV = [
  { to: "/lp", label: "Landing", icon: Megaphone },
  { to: "/pesanan", label: "Pesanan", icon: ShoppingBag },
] as const;

function isActive(pathname: string, to: string, exact: boolean) {
  if (exact) return pathname === to;
  return pathname === to || pathname.startsWith(`${to}/`);
}

export function AppShell({
  children,
  warehouses = [],
}: {
  children: ReactNode;
  warehouses?: Warehouse[];
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname === "/login" || pathname.startsWith("/p/")) {
    return <>{children}</>;
  }
  return <StaffShell warehouses={warehouses}>{children}</StaffShell>;
}

function StaffShell({
  children,
  warehouses,
}: {
  children: ReactNode;
  warehouses: Warehouse[];
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const warehouseId = useWarehouseStore((s) => s.warehouseId);
  const setWarehouseId = useWarehouseStore((s) => s.setWarehouseId);
  const active = pickWarehouse(warehouses, warehouseId);
  const [staffRole, setStaffRole] = useState<StaffRole | null>(null);
  const [staffError, setStaffError] = useState<string | null>(null);
  const [staffPending, setStaffPending] = useState(false);

  useEffect(() => {
    if (!warehouseId && warehouses[0]) setWarehouseId(warehouses[0].id);
  }, [warehouseId, warehouses, setWarehouseId]);

  useEffect(() => {
    if (!user) {
      setStaffRole(null);
      setStaffError(null);
      setStaffPending(false);
      return;
    }
    let cancelled = false;
    setStaffPending(true);
    getMyStaff()
      .then((profile) => {
        if (cancelled) return;
        setStaffRole(profile.role);
        setStaffError(null);
      })
      .catch((err: Error) => {
        if (cancelled) return;
        setStaffRole(null);
        setStaffError(err.message || "Akses ditolak");
      })
      .finally(() => {
        if (!cancelled) setStaffPending(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  if (pathname === "/login" || pathname.startsWith("/p/")) {
    return <>{children}</>;
  }

  if (isPending || (user && staffPending && !staffRole && !staffError)) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg">
        <p className="text-sm font-medium text-muted">Memuat…</p>
      </div>
    );
  }

  if (!user) {
    return <RedirectToSignIn />;
  }

  if (staffError) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-4">
        <div className="w-full max-w-sm rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]">
          <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">
            Katana
          </p>
          <h1 className="mt-2 text-xl font-semibold tracking-tight">Akses ditolak</h1>
          <p className="mt-2 text-sm text-muted">{staffError}</p>
          <div className="mt-5">
            <UserButton />
          </div>
        </div>
      </main>
    );
  }

  const showUsers = staffRole === "admin";

  return (
    <WarehouseListContext.Provider value={warehouses}>
      <div className="min-h-dvh bg-bg text-fg">
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col bg-ink text-ink-fg lg:flex">
          <div className="px-5 pt-6 pb-4">
            <p className="text-xs font-medium tracking-[0.18em] text-ink-fg/55 uppercase">
              Gudang
            </p>
            <p className="mt-1 font-semibold text-xl tracking-tight">Katana</p>
            <p className="text-sm text-ink-fg/65">Sistem stok & nilai</p>
          </div>
          <nav className="flex flex-1 flex-col gap-0.5 px-3">
            {NAV.map((item) => {
              const Icon = item.icon;
              const on = isActive(pathname, item.to, item.exact);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                    on
                      ? "bg-primary-fg/12 text-primary-fg"
                      : "text-ink-fg/70 hover:bg-primary-fg/8 hover:text-ink-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            <Link
              to="/gudang"
              className={cn(
                "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                pathname.startsWith("/gudang")
                  ? "bg-primary-fg/12 text-primary-fg"
                  : "text-ink-fg/70 hover:bg-primary-fg/8 hover:text-ink-fg",
              )}
            >
              <WarehouseIcon className="size-4" />
              Gudang
            </Link>
            {EXTRA_NAV.map((item) => {
              const Icon = item.icon;
              const on = pathname === item.to || pathname.startsWith(`${item.to}/`);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                    on
                      ? "bg-primary-fg/12 text-primary-fg"
                      : "text-ink-fg/70 hover:bg-primary-fg/8 hover:text-ink-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            {showUsers ? (
              <>
              <Link
                to="/pengguna"
                className={cn(
                  "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                  pathname.startsWith("/pengguna")
                    ? "bg-primary-fg/12 text-primary-fg"
                    : "text-ink-fg/70 hover:bg-primary-fg/8 hover:text-ink-fg",
                )}
              >
                <Users className="size-4" />
                Pengguna
              </Link>
              <Link
                to="/pengaturan"
                className={cn(
                  "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                  pathname.startsWith("/pengaturan")
                    ? "bg-primary-fg/12 text-primary-fg"
                    : "text-ink-fg/70 hover:bg-primary-fg/8 hover:text-ink-fg",
                )}
              >
                <Settings className="size-4" />
                Pengaturan
              </Link>
              </>
            ) : null}
          </nav>
          <div className="px-4 py-4 text-xs text-ink-fg/80">
            <UserButton />
          </div>
        </aside>

        <div className="lg:pl-60">
          <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm lg:px-8">
            <div className="lg:hidden">
              <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
                Katana
              </p>
              <p className="font-semibold leading-tight">Sistem stok & nilai</p>
            </div>
            <div className="hidden lg:block">
              <p className="text-sm text-muted">Lokasi aktif</p>
            </div>
            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger className="inline-flex h-11 max-w-[55vw] items-center gap-2 rounded-md bg-surface px-3 text-sm font-medium shadow-[var(--shadow-border)]">
                  <WarehouseIcon className="size-4 text-muted" />
                  <span className="truncate">{active?.name ?? "Pilih gudang"}</span>
                  <ChevronDown className="size-4 text-muted" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Gudang</DropdownMenuLabel>
                  {warehouses.map((w) => (
                    <DropdownMenuItem
                      key={w.id}
                      onSelect={() => setWarehouseId(w.id)}
                    >
                      <span className="flex-1">
                        <span className="block">{w.name}</span>
                        <span className="block font-mono text-xs text-muted">
                          {w.code}
                        </span>
                      </span>
                      {active?.id === w.id ? <Check className="size-4" /> : null}
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuItem asChild>
                    <Link to="/gudang">Kelola gudang</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Link
                to="/lp"
                className="inline-flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)] lg:hidden"
                aria-label="Landing page"
              >
                <Megaphone className="size-4" />
              </Link>
              <Link
                to="/pesanan"
                className="inline-flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)] lg:hidden"
                aria-label="Pesanan"
              >
                <ShoppingBag className="size-4" />
              </Link>
              {showUsers ? (
                <Link
                  to="/pengguna"
                  className="inline-flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)] lg:hidden"
                  aria-label="Pengguna"
                >
                  <Users className="size-4" />
                </Link>
              ) : null}
              {showUsers ? (
                <Link
                  to="/pengaturan"
                  className="inline-flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)] lg:hidden"
                  aria-label="Pengaturan"
                >
                  <Settings className="size-4" />
                </Link>
              ) : null}
              <div className="lg:hidden">
                <UserButton />
              </div>
            </div>
          </header>

          <main className="px-4 pt-5 pb-28 lg:px-8 lg:pb-10">{children}</main>
        </div>

        <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 px-2 pt-1 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-sm lg:hidden">
          <ul className="grid grid-cols-5">
            {NAV.map((item) => {
              const Icon = item.icon;
              const on = isActive(pathname, item.to, item.exact);
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={cn(
                      "flex h-12 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                      on ? "text-primary" : "text-muted",
                    )}
                  >
                    <Icon className="size-4" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </WarehouseListContext.Provider>
  );
}
