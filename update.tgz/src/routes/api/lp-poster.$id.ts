import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";
import { packPhotoForLp } from "@/lib/lp-image";
import { readPosterFile } from "@/lib/lp-poster-fs";

export const Route = createFileRoute("/api/lp-poster/$id")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const id = Number(params.id);
        if (!Number.isInteger(id) || id <= 0) {
          return new Response("Not found", { status: 404 });
        }
        const panel = new URL(request.url).searchParams.get("p") === "2" ? 2 : 1;
        const fromDisk = readPosterFile(id, panel === 2 ? 2 : 1);
        if (fromDisk) {
          return new Response(new Uint8Array(fromDisk.body), {
            headers: {
              "Content-Type": fromDisk.mime,
              "Cache-Control": "public, max-age=31536000, immutable",
              "Content-Length": String(fromDisk.body.length),
            },
          });
        }
        const sql = await getSql();
        const rows = await sql.query<{ mime: string | null; data: string | null }>(
          panel === 2
            ? `select poster2_mime as mime, poster2_data as data from landing_pages where id = $1`
            : `select poster_mime as mime, poster_data as data from landing_pages where id = $1`,
          [id],
        );
        const row = rows[0];
        if (!row?.data) return new Response("Not found", { status: 404 });
        const packed = await packPhotoForLp(`lp-${id}-${panel}`, row.mime || "image/jpeg", row.data);
        return new Response(new Uint8Array(packed.body), {
          headers: {
            "Content-Type": packed.mime,
            "Cache-Control": "public, max-age=31536000, immutable",
            "Content-Length": String(packed.body.length),
          },
        });
      },
    },
  },
});
