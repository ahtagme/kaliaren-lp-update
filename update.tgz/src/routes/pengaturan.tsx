import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import {
  Plus,
  RefreshCw,
  Settings,
  Trash2,
  CheckCircle2,
} from "lucide-react";
import {
  connectLpDomain,
  getCpanelConfig,
  getAiConfig,
  listLpDomains,
  refreshLpDomain,
  removeLpDomain,
  saveCpanelConfig,
  saveAiKey,
  testCpanel,
} from "@/lib/settings-fn";
import { LP_A_RECORD_IP, type LpDomain } from "@/lib/lp-domains";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/pengaturan")({
  component: SettingsPage,
});

function SettingsPage() {
  const [primary, setPrimary] = useState("");
  const [extra, setExtra] = useState<LpDomain[] | null>(null);
  const [newHost, setNewHost] = useState("");
  const [busy, setBusy] = useState(false);
  const [host, setHost] = useState("");
  const [user, setUser] = useState("");
  const [token, setToken] = useState("");
  const [hasToken, setHasToken] = useState(false);
  const [cpanelOk, setCpanelOk] = useState<boolean | null>(null);
  const [cpanelDomains, setCpanelDomains] = useState<string[]>([]);
  const [cpanelError, setCpanelError] = useState("");
  const [aiKey, setAiKey] = useState("");
  const [hasAiKey, setHasAiKey] = useState(false);

  function applyList(d: { primary: string; extra: LpDomain[] }) {
    setPrimary(d.primary);
    setExtra(d.extra);
  }

  useEffect(() => {
    Promise.all([listLpDomains(), getCpanelConfig(), getAiConfig()])
      .then(([domains, cfg, ai]) => {
        applyList(domains);
        setHost(cfg.host);
        setUser(cfg.user);
        setHasToken(cfg.hasToken);
        setHasAiKey(ai.hasKey);
      })
      .catch((e: Error) => toast.error(e.message));
  }, []);

  async function saveCpanel(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await saveCpanelConfig({ data: { host, user, token } });
      setToken("");
      setHasToken(hasToken || Boolean(token.trim()));
      toast.success("Konfigurasi cPanel disimpan");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal simpan");
    } finally {
      setBusy(false);
    }
  }

  async function pingCpanel() {
    setBusy(true);
    setCpanelError("");
    try {
      const res = await testCpanel();
      setCpanelOk(res.ok);
      setCpanelDomains(res.domains);
      setCpanelError(res.error);
      if (res.ok) toast.success(`Terhubung · ${res.domains.length} domain di cPanel`);
      else toast.error(res.error);
    } catch (err) {
      setCpanelOk(false);
      toast.error(err instanceof Error ? err.message : "Gagal tes");
    } finally {
      setBusy(false);
    }
  }

  async function addHost(e: FormEvent) {
    e.preventDefault();
    if (!newHost.trim()) return;
    setBusy(true);
    try {
      const saved = await connectLpDomain({ data: { host: newHost } });
      applyList(saved);
      setNewHost("");
      if (saved.domain.status === "active") toast.success(`${saved.domain.host} aktif`);
      else toast.error(saved.domain.detail);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal konek domain");
    } finally {
      setBusy(false);
    }
  }

  async function recheck(hostName?: string) {
    setBusy(true);
    try {
      const saved = await refreshLpDomain({ data: { host: hostName } });
      applyList(saved);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal cek");
    } finally {
      setBusy(false);
    }
  }

  async function remove(hostName: string) {
    setBusy(true);
    try {
      const saved = await removeLpDomain({ data: { host: hostName } });
      applyList(saved);
      toast.success("Domain dihapus dari Kaliaren");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal hapus");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 pb-16">
      <div>
        <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">Admin</p>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Pengaturan cPanel</h1>
        <p className="mt-1 text-sm text-muted">
          Konek domain LP dari dasbor. Token hanya disimpan di server.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <CardContent className="grid gap-4 p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-semibold">Kelola domain</p>
                <p className="text-sm text-muted">Domain untuk landing page</p>
              </div>
            </div>

            {primary ? (
              <div className="flex items-center justify-between gap-2 rounded-lg bg-bg px-3 py-3">
                <div className="min-w-0">
                  <p className="font-mono text-sm">{primary}</p>
                  <p className="text-xs text-muted">utama · admin/stok</p>
                </div>
                <Badge variant="aman">Aktif</Badge>
              </div>
            ) : null}

            {extra == null ? (
              <Skeleton className="h-24 rounded-lg" />
            ) : extra.length === 0 ? (
              <p className="text-sm text-muted">Belum ada domain iklan.</p>
            ) : (
              extra.map((d) => (
                <div
                  key={d.host}
                  className="flex items-start justify-between gap-2 rounded-lg bg-bg px-3 py-3"
                >
                  <div className="min-w-0">
                    <p className="font-mono text-sm break-all">{d.host}</p>
                    <p className={d.status === "active" ? "text-xs text-ok" : "text-xs text-danger"}>
                      {d.detail}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Badge variant={d.status === "active" ? "aman" : "default"}>
                      {d.status === "active" ? "Aktif" : "Belum"}
                    </Badge>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      disabled={busy}
                      onClick={() => void recheck(d.host)}
                    >
                      <RefreshCw className="size-4" />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      disabled={busy}
                      onClick={() => void remove(d.host)}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}

            <form onSubmit={(e) => void addHost(e)} className="grid gap-2 border-t border-border pt-4">
              <Label htmlFor="add-host">Tambah domain LP</Label>
              <div className="flex flex-col gap-2 sm:flex-row">
                <Input
                  id="add-host"
                  value={newHost}
                  onChange={(e) => setNewHost(e.target.value)}
                  placeholder="cart.otiskosmetika.com"
                />
                <Button type="submit" disabled={busy || !newHost.trim()} className="sm:w-auto">
                  <Plus className="size-4" />
                  {busy ? "Mengecek…" : "Tambah"}
                </Button>
              </div>
              <p className="text-xs text-muted">
                A record ke {LP_A_RECORD_IP} (Cloudflare boleh proxied).
              </p>
            </form>
          </CardContent>
        </Card>

        <div className="grid gap-5">
          <Card>
            <CardContent className="grid gap-4 p-5">
              <div>
                <p className="font-semibold">Konfigurasi cPanel</p>
                <p className="text-sm text-muted">Supaya domain dibuat otomatis, tanpa WHM.</p>
              </div>
              <form onSubmit={(e) => void saveCpanel(e)} className="grid gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="cp-host">cPanel host</Label>
                  <Input
                    id="cp-host"
                    value={host}
                    onChange={(e) => setHost(e.target.value)}
                    placeholder="dewastoreid.com"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="cp-user">Username</Label>
                  <Input
                    id="cp-user"
                    value={user}
                    onChange={(e) => setUser(e.target.value)}
                    placeholder="dewastoreid"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="cp-token">API token</Label>
                  <Input
                    id="cp-token"
                    type="password"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    placeholder={hasToken ? "Tersimpan · isi untuk ganti" : "Token cPanel"}
                  />
                  <p className="text-xs text-muted">
                    cPanel → Security → Manage API Tokens. Token tidak dikirim ke browser lagi
                    setelah disimpan.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button type="submit" disabled={busy}>
                    <Settings className="size-4" />
                    Simpan
                  </Button>
                  <Button type="button" variant="outline" disabled={busy} onClick={() => void pingCpanel()}>
                    <RefreshCw className="size-4" />
                    Tes koneksi
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="grid gap-3 p-5">
              <div className="flex items-center justify-between">
                <p className="font-semibold">Status koneksi</p>
                {cpanelOk == null ? null : (
                  <Badge variant={cpanelOk ? "aman" : "default"}>
                    {cpanelOk ? "Terhubung" : "Gagal"}
                  </Badge>
                )}
              </div>
              {cpanelOk ? (
                <p className="flex items-center gap-2 text-sm text-ok">
                  <CheckCircle2 className="size-4" />
                  Koneksi cPanel berhasil · {cpanelDomains.length} domain
                </p>
              ) : (
                <p className="text-sm text-muted">
                  {cpanelError || "Simpan token, lalu tes koneksi."}
                </p>
              )}
              {cpanelDomains.length > 0 ? (
                <ul className="grid gap-1 text-sm">
                  {cpanelDomains.slice(0, 12).map((d) => (
                    <li key={d} className="font-mono text-xs text-muted">
                      {d}
                    </li>
                  ))}
                </ul>
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="grid gap-3 p-5">
              <div>
                <p className="font-semibold">Kunci AI (Grok)</p>
                <p className="text-sm text-muted">
                  Untuk Generate LP dari foto. Tanpa kunci, LP hanya template.
                </p>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!aiKey.trim()) return;
                  setBusy(true);
                  saveAiKey({ data: { key: aiKey } })
                    .then((r) => {
                      setHasAiKey(r.hasKey);
                      setAiKey("");
                      toast.success("Kunci AI disimpan");
                    })
                    .catch((err: Error) => toast.error(err.message))
                    .finally(() => setBusy(false));
                }}
                className="grid gap-2"
              >
                <Input
                  type="password"
                  value={aiKey}
                  onChange={(e) => setAiKey(e.target.value)}
                  placeholder={hasAiKey ? "Tersimpan · isi untuk ganti" : "xai-..."}
                />
                <Button type="submit" disabled={busy || !aiKey.trim()}>
                  Simpan kunci AI
                </Button>
              </form>
              <p className={hasAiKey ? "text-xs text-ok" : "text-xs text-danger"}>
                {hasAiKey ? "AI siap" : "AI belum aktif"}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <p className="text-sm text-muted">
        <Link to="/lp" className="underline-offset-2 hover:underline">
          Kembali ke Landing
        </Link>
        <span className="mx-2">·</span>
        Pilih domain di tiap LP lalu salin tautan iklan.
      </p>
    </div>
  );
}
