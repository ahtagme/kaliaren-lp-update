import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { listStock, recordOpname } from "@/lib/inventory-fn";
import type { StockRow } from "@/lib/inventory";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { angka } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/opname")({ component: OpnamePage });

function OpnamePage() {
  const { active } = useActiveWarehouse();
  const [rows, setRows] = useState<StockRow[] | null>(null);
  const [physical, setPhysical] = useState<Record<number, string>>({});
  const [q, setQ] = useState("");
  const [note, setNote] = useState("");
  const [pending, setPending] = useState(false);
  const [onlyDiff, setOnlyDiff] = useState(false);

  async function reload() {
    if (!active) return;
    const data = await listStock({ data: { warehouseId: active.id, photos: false } });
    setRows(data);
    const next: Record<number, string> = {};
    for (const r of data) next[r.id] = String(r.qty);
    setPhysical(next);
  }

  useEffect(() => {
    if (!active) return;
    setRows(null);
    reload().catch((e: Error) => toast.error(e.message));
  }, [active?.id]);

  const diffs = useMemo(() => {
    if (!rows) return [];
    return rows
      .map((r) => {
        const raw = physical[r.id];
        const n = Number(raw);
        const valid = Number.isInteger(n) && n >= 0;
        const qty = valid ? n : r.qty;
        return { product: r, physicalQty: qty, delta: qty - r.qty, valid };
      })
      .filter((d) => d.delta !== 0);
  }, [rows, physical]);

  const shown = useMemo(() => {
    if (!rows) return [];
    const needle = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (needle && !r.name.toLowerCase().includes(needle) && !r.sku.toLowerCase().includes(needle)) {
        return false;
      }
      if (onlyDiff) {
        const n = Number(physical[r.id]);
        return Number.isInteger(n) && n !== r.qty;
      }
      return true;
    });
  }, [rows, q, onlyDiff, physical]);

  async function submit() {
    if (!active) return;
    const items = diffs.filter((d) => d.valid).map((d) => ({
      productId: d.product.id,
      physicalQty: d.physicalQty,
    }));
    if (items.length === 0) {
      toast.error("Belum ada selisih. Ubah angka fisik yang berbeda dari sistem.");
      return;
    }
    setPending(true);
    try {
      const res = await recordOpname({
        data: {
          warehouseId: active.id,
          items,
          note: note.trim() || undefined,
        },
      });
      toast.success(`${res.adjusted} produk disesuaikan`);
      setNote("");
      await reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal opname");
    } finally {
      setPending(false);
    }
  }

  if (!rows || !active) return <Skeleton className="h-96 rounded-xl" />;

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Stok opname</h1>
        <p className="mt-1 text-sm text-muted">
          Hitung fisik di {active.name}, lalu simpan selisihnya. Angka kiri
          adalah stok sistem.
        </p>
      </div>

      <div className="grid gap-2 sm:grid-cols-[1fr_auto]">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari produk"
        />
        <Button
          type="button"
          variant={onlyDiff ? "default" : "outline"}
          onClick={() => setOnlyDiff((v) => !v)}
        >
          {onlyDiff ? "Selisih saja" : "Semua"}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="grid grid-cols-[1fr_4.5rem_5.5rem_4.5rem] gap-2 border-b border-border px-4 py-2 text-xs font-medium tracking-wide text-muted uppercase">
            <span>Produk</span>
            <span className="text-right">Sistem</span>
            <span className="text-right">Fisik</span>
            <span className="text-right">Selisih</span>
          </div>
          <ul className="max-h-[28rem] overflow-y-auto">
            {shown.map((r) => {
              const n = Number(physical[r.id]);
              const delta = (Number.isInteger(n) ? n : r.qty) - r.qty;
              return (
                <li
                  key={r.id}
                  className="grid grid-cols-[1fr_4.5rem_5.5rem_4.5rem] items-center gap-2 border-b border-border px-4 py-2 last:border-0"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{r.name}</p>
                    <p className="font-mono text-xs text-muted">{r.sku}</p>
                  </div>
                  <p className="text-right font-mono text-sm tabular-nums">
                    {angka(r.qty)}
                  </p>
                  <Input
                    inputMode="numeric"
                    value={physical[r.id] ?? ""}
                    onChange={(e) =>
                      setPhysical((prev) => ({ ...prev, [r.id]: e.target.value }))
                    }
                    className="h-10 px-2 text-right font-mono"
                    aria-label={`Stok fisik ${r.name}`}
                  />
                  <p
                    className={cn(
                      "text-right font-mono text-sm tabular-nums",
                      delta > 0 && "text-ok",
                      delta < 0 && "text-danger",
                      delta === 0 && "text-subtle",
                    )}
                  >
                    {delta > 0 ? "+" : ""}
                    {angka(delta)}
                  </p>
                </li>
              );
            })}
          </ul>
        </CardContent>
      </Card>

      <div className="grid gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="opname-note">Catatan hitungan</Label>
          <Textarea
            id="opname-note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Mis. opname rak A, 21 Sep 2026"
            rows={2}
          />
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted">
            {diffs.length === 0
              ? "Tidak ada selisih."
              : `${diffs.length} produk akan disesuaikan.`}
          </p>
          <Button onClick={submit} disabled={pending || diffs.length === 0}>
            {pending ? "Menyimpan…" : "Simpan opname"}
          </Button>
        </div>
      </div>
    </div>
  );
}
