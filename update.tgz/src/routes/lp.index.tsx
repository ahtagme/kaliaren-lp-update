import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ExternalLink, Globe, Megaphone, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { createLanding, listLandings, listProductOptions } from "@/lib/lp-fn";
import { listWarehouses } from "@/lib/inventory-fn";
import { listLpDomains, saveLpDomains, connectLpDomain, refreshLpDomain } from "@/lib/settings-fn";
import type { LandingListItem, ProductOption } from "@/lib/lp";
import { LP_A_RECORD_IP, lpAdUrl, type LpDomain } from "@/lib/lp-domains";
import type { Warehouse } from "@/lib/inventory";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { angka, formatWaktu, rupiah } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/lp/")({
  component: LandingListPage,
});

function LandingListPage() {
  const navigate = useNavigate();
  const { active } = useActiveWarehouse();
  const [rows, setRows] = useState<LandingListItem[] | null>(null);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [productId, setProductId] = useState<string>("");
  const [warehouseId, setWarehouseId] = useState<string>("");
  const [pending, setPending] = useState(false);
  const [productQ, setProductQ] = useState("");
  const [domainOpen, setDomainOpen] = useState(false);
  const [primaryDomain, setPrimaryDomain] = useState("");
  const [extraDomains, setExtraDomains] = useState<LpDomain[]>([]);
  const [newDomain, setNewDomain] = useState("");
  const [domainPending, setDomainPending] = useState(false);

  async function reload() {
    const data = await listLandings();
    setRows(data);
  }

  useEffect(() => {
    reload().catch((e: Error) => {
      if (e.message === "Unauthorized") return;
      toast.error(e.message);
    });
  }, []);

  useEffect(() => {
    if (!open) return;
    Promise.all([listProductOptions(), listWarehouses()])
      .then(([p, w]) => {
        setProducts(p);
        setWarehouses(w);
        setWarehouseId(String(active?.id ?? w[0]?.id ?? ""));
      })
      .catch((e: Error) => toast.error(e.message));
  }, [open, active?.id]);

  const filtered = useMemo(() => {
    if (!rows) return [];
    const needle = q.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter(
      (r) =>
        r.productName.toLowerCase().includes(needle) ||
        r.slug.includes(needle) ||
        r.sku.toLowerCase().includes(needle),
    );
  }, [rows, q]);

  const productChoices = useMemo(() => {
    const needle = productQ.trim().toLowerCase();
    const list = needle
      ? products.filter(
          (p) =>
            p.name.toLowerCase().includes(needle) ||
            p.sku.toLowerCase().includes(needle),
        )
      : products;
    return list.slice(0, 40);
  }, [products, productQ]);

  async function onCreate(e: FormEvent) {
    e.preventDefault();
    const pid = Number(productId);
    const wid = Number(warehouseId);
    if (!pid || !wid) return;
    setPending(true);
    try {
      const created = await createLanding({
        data: { productId: pid, warehouseId: wid },
      });
      toast.success(
        created.reused
          ? "LP produk ini diperbarui dari foto"
          : "LP jadi. Foto produk jadi hero.",
      );
      setOpen(false);
      navigate({ to: "/lp/$id", params: { id: String(created.id) } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal membuat LP");
    } finally {
      setPending(false);
    }
  }

  useEffect(() => {
    if (!domainOpen) return;
    listLpDomains()
      .then(async (d) => {
        setPrimaryDomain(d.primary);
        setExtraDomains(d.extra);
        if (d.extra.length > 0) {
          const saved = await refreshLpDomain({ data: {} });
          setPrimaryDomain(saved.primary);
          setExtraDomains(saved.extra);
        }
      })
      .catch((e: Error) => toast.error(e.message));
  }, [domainOpen]);

  async function persistDomains(nextHosts: string[]) {
    setDomainPending(true);
    try {
      const saved = await saveLpDomains({ data: { domains: nextHosts } });
      setPrimaryDomain(saved.primary);
      setExtraDomains(saved.extra);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal simpan domain");
    } finally {
      setDomainPending(false);
    }
  }

  async function addDomain(e: FormEvent) {
    e.preventDefault();
    const host = newDomain.trim();
    if (!host) return;
    setDomainPending(true);
    try {
      const saved = await connectLpDomain({ data: { host } });
      setPrimaryDomain(saved.primary);
      setExtraDomains(saved.extra);
      setNewDomain("");
      if (saved.domain.status === "active") {
        toast.success(`${saved.domain.host} aktif`);
      } else {
        toast.error(saved.domain.detail);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal cek domain");
    } finally {
      setDomainPending(false);
    }
  }

  async function recheckDomain(host?: string) {
    setDomainPending(true);
    try {
      const saved = await refreshLpDomain({ data: { host } });
      setPrimaryDomain(saved.primary);
      setExtraDomains(saved.extra);
      const focus = host
        ? saved.extra.find((d) => d.host === host)
        : saved.extra[0];
      if (focus?.status === "active") toast.success(`${focus.host} aktif`);
      else if (focus) toast.error(focus.detail);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal cek domain");
    } finally {
      setDomainPending(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Landing page</h1>
          <p className="mt-1 text-sm text-muted">
            Halaman jual COD per produk. Form pesanan langsung potong stok gudang.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => setDomainOpen(true)} className="shrink-0">
          <Globe className="size-4" />
          Domain iklan
        </Button>
        <Button onClick={() => setOpen(true)} className="shrink-0">
          <Plus className="size-4" />
          Buat LP
        </Button>
        </div>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute top-3.5 left-3 size-4 text-muted" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari produk atau slug"
          className="pl-9"
        />
      </div>

      {!rows ? (
        <Skeleton className="h-64 rounded-xl" />
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 px-6 py-12 text-center">
            <Megaphone className="size-8 text-muted" />
            <p className="font-medium">Belum ada landing page</p>
            <p className="text-sm text-muted">
              Pilih produk dari stok, isi copy, terbitkan, lalu bagikan tautannya.
            </p>
          </CardContent>
        </Card>
      ) : (
        <ul className="grid gap-3">
          {filtered.map((r) => (
            <li key={r.id}>
              <Link
                to="/lp/$id"
                params={{ id: String(r.id) }}
                className="block rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)] transition-colors hover:bg-bg-elevated"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold tracking-tight">{r.productName}</p>
                    <p className="mt-0.5 font-mono text-xs text-muted">
                      {r.publicDomain
                        ? lpAdUrl(r.publicDomain, r.slug).replace(/^https:\/\//, "")
                        : `/p/${r.slug}`}{" "}
                      · {r.sku}
                    </p>
                  </div>
                  <Badge variant={r.isPublished ? "aman" : "default"}>
                    {r.isPublished ? "Terbit" : "Draft"}
                  </Badge>
                </div>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
                  <span>{rupiah(r.price)}</span>
                  <span>{angka(r.soldCount)} terjual</span>
                  <span>{angka(r.orderCount)} pesanan</span>
                  <span>stok {angka(r.stockQty)}</span>
                  <span>{formatWaktu(r.updatedAt)}</span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}

      {rows?.some((r) => r.isPublished) ? (
        <p className="text-xs text-subtle">
          Tautan publik:{" "}
          <span className="font-mono">/p/slug</span>
          {rows
            .filter((r) => r.isPublished)
            .slice(0, 2)
            .map((r) => (
              <Link
                key={r.id}
                to="/p/$slug"
                params={{ slug: r.slug }}
                className="ml-2 inline-flex items-center gap-1 text-primary underline-offset-2 hover:underline"
              >
                {r.slug}
                <ExternalLink className="size-3" />
              </Link>
            ))}
        </p>
      ) : null}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Buat landing page</DialogTitle>
            <DialogDescription>
              Copy, harga, dan form COD terisi otomatis. Tinggal rapikan lalu terbitkan.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={onCreate} className="grid gap-3">
            <div className="grid gap-1.5">
              <Label>Produk</Label>
              <Input
                value={productQ}
                onChange={(e) => setProductQ(e.target.value)}
                placeholder="Cari nama atau SKU"
              />
              <Select value={productId || undefined} onValueChange={setProductId}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih produk" />
                </SelectTrigger>
                <SelectContent>
                  {productChoices.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label>Potong stok dari gudang</Label>
              <Select value={warehouseId || undefined} onValueChange={setWarehouseId}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih gudang" />
                </SelectTrigger>
                <SelectContent>
                  {warehouses.map((w) => (
                    <SelectItem key={w.id} value={String(w.id)}>
                      {w.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" disabled={pending || !productId}>
              {pending ? "Membuat…" : "Buat draft"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={domainOpen} onOpenChange={setDomainOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Domain iklan</DialogTitle>
            <DialogDescription>
              Pilih domain ini saat buat LP. Domain harus mengarah ke server yang sama.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            {primaryDomain ? (
              <p className="rounded-lg bg-bg px-3 py-2 font-mono text-sm">
                {primaryDomain}
                <span className="ml-2 text-xs text-muted">utama</span>
              </p>
            ) : null}
            {extraDomains.map((d) => (
              <div
                key={d.host}
                className="flex items-start justify-between gap-2 rounded-lg bg-bg px-3 py-2"
              >
                <div className="min-w-0">
                  <p className="font-mono text-sm break-all">{d.host}</p>
                  <p
                    className={
                      d.status === "active"
                        ? "mt-0.5 text-xs text-ok"
                        : "mt-0.5 text-xs text-danger"
                    }
                  >
                    {d.status === "active" ? "Aktif" : "Belum aktif"}
                    {d.detail ? ` · ${d.detail}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    disabled={domainPending}
                    onClick={() => void recheckDomain(d.host)}
                  >
                    Cek
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    disabled={domainPending}
                    onClick={() =>
                      void persistDomains(extraDomains.filter((x) => x.host !== d.host).map((x) => x.host))
                    }
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>
            ))}
            <form onSubmit={(e) => void addDomain(e)} className="grid gap-2">
              <Label htmlFor="new-domain">Konek domain baru</Label>
              <Input
                id="new-domain"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                placeholder="otiskosmetika.com"
              />
              <Button type="submit" disabled={domainPending || !newDomain.trim()}>
                {domainPending ? "Mengecek DNS…" : "Verifikasi & tambah"}
              </Button>
            </form>
            <p className="text-xs text-muted">
              A record ke {LP_A_RECORD_IP}. Token cPanel dan tambah domain otomatis ada di{" "}
              <Link to="/pengaturan" className="underline-offset-2 hover:underline">
                Pengaturan
              </Link>
              .
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
