import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { listOrders, updateOrderStatus } from "@/lib/lp-fn";
import { ORDER_LABEL, ORDER_STATUSES, type CodOrder, type OrderStatus } from "@/lib/lp";
import { angka, formatWaktu, rupiah } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/pesanan")({
  component: OrdersPage,
});

function statusVariant(status: OrderStatus) {
  if (status === "selesai") return "aman" as const;
  if (status === "batal") return "habis" as const;
  if (status === "baru") return "menipis" as const;
  return "default" as const;
}

function OrdersPage() {
  const [rows, setRows] = useState<CodOrder[] | null>(null);
  const [status, setStatus] = useState<"semua" | OrderStatus>("semua");
  const [busyId, setBusyId] = useState<number | null>(null);

  async function reload(next = status) {
    const data = await listOrders({ data: { status: next } });
    setRows(data);
  }

  useEffect(() => {
    setRows(null);
    reload(status).catch((e: Error) => {
      if (e.message === "Unauthorized") return;
      toast.error(e.message);
    });
  }, [status]);

  async function changeStatus(id: number, next: OrderStatus) {
    setBusyId(id);
    try {
      await updateOrderStatus({ data: { id, status: next } });
      await reload();
      toast.success("Status pesanan diubah");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal mengubah status");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Pesanan</h1>
          <p className="mt-1 text-sm text-muted">
            Pesanan dari landing page. Stok terpotong saat form dikirim, kembali jika dibatalkan.
          </p>
        </div>
        <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
          <SelectTrigger className="w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="semua">Semua status</SelectItem>
            {ORDER_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {ORDER_LABEL[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {!rows ? (
        <Skeleton className="h-64 rounded-xl" />
      ) : rows.length === 0 ? (
        <Card>
          <CardContent className="px-6 py-12 text-center text-sm text-muted">
            Belum ada pesanan. Bagikan tautan landing page yang sudah terbit.
          </CardContent>
        </Card>
      ) : (
        <ul className="grid gap-3">
          {rows.map((o) => (
            <li
              key={o.id}
              className="rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold tracking-tight">{o.customerName}</p>
                  <p className="text-sm text-muted">
                    {o.phone} · {o.city}
                  </p>
                </div>
                <Badge variant={statusVariant(o.status)}>{ORDER_LABEL[o.status]}</Badge>
              </div>
              <p className="mt-3 text-sm">
                {o.qty} × {o.productName} · {rupiah(o.total)}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-muted">{o.address}</p>
              {o.note ? (
                <p className="mt-1 text-sm text-muted">Catatan: {o.note}</p>
              ) : null}
              <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-subtle">
                <span>{formatWaktu(o.createdAt)}</span>
                <span>{o.warehouseName}</span>
                <Link
                  to="/p/$slug"
                  params={{ slug: o.slug }}
                  className="text-primary underline-offset-2 hover:underline"
                >
                  LP {o.slug}
                </Link>
                <span className="tabular-nums">#{angka(o.id)}</span>
              </div>
              <div className="mt-3 max-w-56">
                <Select
                  value={o.status}
                  disabled={busyId === o.id}
                  onValueChange={(v) => changeStatus(o.id, v as OrderStatus)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ORDER_STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {ORDER_LABEL[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
