import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { createWarehouse, updateWarehouse } from "@/lib/inventory-fn";
import { getImageCdn, setImageCdn } from "@/lib/settings-fn";
import { getMyStaff } from "@/lib/staff-fn";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { useWarehouseStore } from "@/lib/warehouse-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/gudang")({ component: GudangPage });

function GudangPage() {
  const { warehouses, active } = useActiveWarehouse();
  const setWarehouseId = useWarehouseStore((s) => s.setWarehouseId);
  const router = useRouter();
  const [open, setOpen] = useState(false);

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-5">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Gudang</h1>
          <p className="mt-1 text-sm text-muted">
            Stok dihitung per lokasi. Gudang utama sudah terisi; tambah gudang lain
            kapan saja.
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus />
          Tambah
        </Button>
      </div>

      <CdnCard />

      <ul className="grid gap-3">
        {warehouses.map((w) => (
          <li key={w.id}>
            <Card>
              <CardHeader className="flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle>{w.name}</CardTitle>
                  <p className="mt-1 font-mono text-xs text-muted">{w.code}</p>
                  {w.address ? (
                    <p className="mt-1 text-sm text-muted">{w.address}</p>
                  ) : null}
                </div>
                {active?.id === w.id ? (
                  <span className="rounded-full bg-ok-bg px-2.5 py-0.5 text-xs font-medium text-ok">
                    Aktif
                  </span>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setWarehouseId(w.id)}
                  >
                    Pakai
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <WarehouseEdit
                  warehouse={w}
                  onSaved={() => router.invalidate()}
                />
              </CardContent>
            </Card>
          </li>
        ))}
      </ul>

      <WarehouseDialog
        open={open}
        onOpenChange={setOpen}
        onCreated={async (id) => {
          setWarehouseId(id);
          await router.invalidate();
        }}
      />
    </div>
  );
}

function CdnCard() {
  const [role, setRole] = useState<"admin" | "staff" | null>(null);
  const [base, setBase] = useState("");
  const [auto, setAuto] = useState(false);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([getMyStaff(), getImageCdn()])
      .then(([staff, cdn]) => {
        if (cancelled) return;
        setRole(staff.role);
        setBase(cdn.base.startsWith("weserv:") ? "" : cdn.base);
        setAuto(cdn.auto);
      })
      .catch(() => {
        if (!cancelled) setRole("staff");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (role !== "admin") return null;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setPending(true);
    try {
      const saved = await setImageCdn({ data: { base } });
      setBase(saved.base);
      toast.success(saved.base ? "CDN gambar disimpan" : "CDN custom dilepas. Pakai otomatis.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan CDN");
    } finally {
      setPending(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>CDN gambar</CardTitle>
        <p className="text-sm text-muted">
          Foto LP lewat CDN biar iklan cepat. Kosong = otomatis
          {auto ? " (aktif setelah publish)" : ""}.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="cdn-base">URL pull zone (opsional)</Label>
            <Input
              id="cdn-base"
              value={base}
              onChange={(e) => setBase(e.target.value)}
              placeholder="https://xxx.b-cdn.net"
              autoComplete="off"
            />
          </div>
          <div>
            <Button type="submit" variant="outline" disabled={pending}>
              {pending ? "Menyimpan…" : "Simpan CDN"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function WarehouseEdit({
  warehouse,
  onSaved,
}: {
  warehouse: { id: number; name: string; code: string; address: string | null };
  onSaved: () => Promise<void>;
}) {
  const [name, setName] = useState(warehouse.name);
  const [code, setCode] = useState(warehouse.code);
  const [address, setAddress] = useState(warehouse.address ?? "");
  const [pending, setPending] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setPending(true);
    try {
      await updateWarehouse({
        data: {
          id: warehouse.id,
          name: name.trim(),
          code: code.trim(),
          address: address.trim() || undefined,
        },
      });
      toast.success("Gudang diperbarui");
      await onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={submit} className="grid gap-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1.5">
          <Label>Nama</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="grid gap-1.5">
          <Label>Kode</Label>
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="font-mono uppercase"
            required
          />
        </div>
      </div>
      <div className="grid gap-1.5">
        <Label>Alamat / keterangan</Label>
        <Input value={address} onChange={(e) => setAddress(e.target.value)} />
      </div>
      <div>
        <Button type="submit" variant="outline" disabled={pending}>
          {pending ? "Menyimpan…" : "Simpan"}
        </Button>
      </div>
    </form>
  );
}

function WarehouseDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: (id: number) => Promise<void>;
}) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [address, setAddress] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setPending(true);
    try {
      const res = await createWarehouse({
        data: {
          name: name.trim(),
          code: code.trim(),
          address: address.trim() || undefined,
        },
      });
      toast.success("Gudang ditambahkan");
      setName("");
      setCode("");
      setAddress("");
      onOpenChange(false);
      await onCreated(res.id);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menambah");
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Gudang baru</DialogTitle>
          <DialogDescription>
            Stok di lokasi baru mulai dari nol. Pindahkan barang dari gudang utama
            lewat menu Catat.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="w-name">Nama</Label>
            <Input
              id="w-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="w-code">Kode</Label>
            <Input
              id="w-code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="mis. SBY"
              className="font-mono uppercase"
              required
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="w-addr">Alamat</Label>
            <Input
              id="w-addr"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={pending}>
            {pending ? "Menyimpan…" : "Buat gudang"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
