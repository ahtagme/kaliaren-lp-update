import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Package, AlertTriangle, Coins, Boxes } from "lucide-react";
import { getDashboard } from "@/lib/inventory-fn";
import type { DashboardData } from "@/lib/inventory";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { angka, formatWaktu, rupiah } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MovementBadge, StockBadge } from "@/components/stock-badge";

export const Route = createFileRoute("/")({
  component: DashboardPage,
});

const CHART_NAME: Record<string, string> = {
  "Kesehatan & Herbal": "Herbal",
  "Perawatan Mobil": "Otomotif",
  "Jam & Aksesoris": "Aksesoris",
  "Rumah Tangga": "RT",
};

function DashboardPending() {
  return (
    <div className="grid gap-4">
      <Skeleton className="h-10 w-48" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
    </div>
  );
}

function DashboardPage() {
  const { active } = useActiveWarehouse();
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    setError(null);
    setData(null);
    getDashboard({ data: { warehouseId: active.id } })
      .then((d) => {
        if (!cancelled) setData(d);
      })
      .catch((e: Error) => {
        if (!cancelled) setError(e.message);
      });
    return () => {
      cancelled = true;
    };
  }, [active?.id]);

  if (error) {
    return <p className="text-danger">{error}</p>;
  }

  if (!data || !active) {
    return <DashboardPending />;
  }

  const stats = [
    {
      label: "SKU di gudang",
      value: angka(data.summary.skuCount),
      hint: active.name,
      icon: Package,
    },
    {
      label: "Stok fisik",
      value: angka(data.summary.totalQty),
      hint: "pcs",
      icon: Boxes,
    },
    {
      label: "Nilai persediaan",
      value: rupiah(data.summary.totalValue),
      hint: "harga modal",
      icon: Coins,
    },
    {
      label: data.summary.totalQty === 0 ? "Belum diopname" : "Perlu restok",
      value: angka(data.summary.lowCount + data.summary.zeroCount),
      hint:
        data.summary.totalQty === 0
          ? "stok fisik masih 0"
          : `${data.summary.zeroCount} habis`,
      icon: AlertTriangle,
    },
  ];

  const chartData = data.byCategory.slice(0, 7).map((c) => ({
    name: CHART_NAME[c.category] ?? c.category,
    nilai: Math.round(c.value / 1000),
  }));

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight lg:text-3xl">
          Ringkasan stok
        </h1>
        <p className="mt-1 text-sm text-muted">
          Stok sistem mengikuti mutasi. Cocokkan dengan hitungan fisik lewat
          opname.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Link
            to="/lp"
            className="inline-flex h-10 items-center rounded-md bg-surface px-3 text-sm font-medium shadow-[var(--shadow-border)]"
          >
            Landing
          </Link>
          <Link
            to="/pesanan"
            className="inline-flex h-10 items-center rounded-md bg-surface px-3 text-sm font-medium shadow-[var(--shadow-border)]"
          >
            Pesanan masuk
          </Link>
        </div>
      </div>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="rounded-xl">
              <CardContent className="p-4 lg:p-5">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-xs font-medium tracking-wide text-muted uppercase">
                    {s.label}
                  </p>
                  <Icon className="size-4 text-muted" />
                </div>
                <p className="mt-3 font-mono text-lg font-semibold tabular-nums tracking-tight lg:text-xl">
                  {s.value}
                </p>
                <p className="mt-1 text-xs text-subtle">{s.hint}</p>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Nilai per kategori</CardTitle>
            <p className="text-sm text-muted">Dalam ribuan rupiah, harga modal</p>
          </CardHeader>
          <CardContent className="grid gap-3 pb-5">
            {chartData.length === 0 ? (
              <p className="text-sm text-muted">Belum ada nilai kategori.</p>
            ) : (
              chartData.map((row) => {
                const max = Math.max(...chartData.map((c) => c.nilai), 1);
                const pct = Math.max(4, Math.round((row.nilai / max) * 100));
                return (
                  <div key={row.name} className="grid gap-1">
                    <div className="flex items-baseline justify-between gap-2 text-sm">
                      <span className="font-medium">{row.name}</span>
                      <span className="font-mono text-xs tabular-nums text-muted">
                        {rupiah(row.nilai * 1000)}
                      </span>
                    </div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full bg-primary"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Stok menipis</CardTitle>
            <Link to="/stok" className="text-xs font-medium text-primary">
              Lihat semua
            </Link>
          </CardHeader>
          <CardContent className="px-0">
            {data.lowStock.length === 0 ? (
              <p className="px-5 pb-5 text-sm text-muted">
                Semua stok masih di atas batas minimum.
              </p>
            ) : (
              <ul>
                {data.lowStock.map((p) => (
                  <li key={p.id}>
                    <Link
                      to="/stok/$id"
                      params={{ id: String(p.id) }}
                      className="flex items-center justify-between gap-3 px-5 py-2.5 hover:bg-bg-elevated"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">
                          {p.name}
                        </span>
                        <span className="block font-mono text-xs text-muted">
                          min {angka(p.minStock)}
                        </span>
                      </span>
                      <span className="flex shrink-0 items-center gap-2">
                        <span className="font-mono text-sm tabular-nums">
                          {angka(p.qty)}
                        </span>
                        <StockBadge status={p.status} />
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </section>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Stok masih banyak</CardTitle>
            <p className="text-sm text-muted">Qty ≥ 50, siap didorong jual</p>
          </div>
          <Link to="/stok" className="text-xs font-medium text-primary">
            Lihat stok
          </Link>
        </CardHeader>
        <CardContent className="px-0">
          {(data.highStock ?? []).length === 0 ? (
            <p className="px-5 pb-5 text-sm text-muted">
              Belum ada SKU dengan stok ≥ 50.
            </p>
          ) : (
            <ul className="divide-y divide-border">
              {(data.highStock ?? []).map((p) => (
                <li key={p.id}>
                  <Link
                    to="/stok/$id"
                    params={{ id: String(p.id) }}
                    className="flex items-center justify-between gap-3 px-5 py-2.5 hover:bg-bg-elevated"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">
                        {p.name}
                      </span>
                      <span className="block font-mono text-xs text-muted">
                        {rupiah(p.value)}
                      </span>
                    </span>
                    <span className="font-mono text-sm font-medium tabular-nums">
                      {angka(p.qty)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>Mutasi terbaru</CardTitle>
          <Link to="/riwayat" className="text-xs font-medium text-primary">
            Riwayat
          </Link>
        </CardHeader>
        <CardContent className="px-0">
          {data.recent.length === 0 ? (
            <p className="px-5 pb-5 text-sm text-muted">Belum ada mutasi.</p>
          ) : (
            <ul className="divide-y divide-border">
              {data.recent.map((m) => (
                <li
                  key={m.id}
                  className="flex items-start justify-between gap-3 px-5 py-3"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{m.productName}</p>
                    <p className="text-xs text-muted">
                      {m.reason ?? "—"} · {formatWaktu(m.createdAt)}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <MovementBadge type={m.type} />
                    <p className="font-mono text-sm tabular-nums">
                      {m.type === "out" || m.type === "transfer_out" ? "−" : "+"}
                      {angka(m.qty)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
