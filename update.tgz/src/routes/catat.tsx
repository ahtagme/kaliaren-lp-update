import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import {
  listStock,
  recordIn,
  recordOut,
  recordTransfer,
} from "@/lib/inventory-fn";
import { IN_REASONS, OUT_REASONS, type StockRow } from "@/lib/inventory";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { angka, rupiah } from "@/lib/utils";
import { ProductPicker } from "@/components/product-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/catat")({ component: CatatPage });

function CatatPage() {
  const { active, warehouses } = useActiveWarehouse();
  const [products, setProducts] = useState<StockRow[] | null>(null);

  async function reload() {
    if (!active) return;
    const rows = await listStock({ data: { warehouseId: active.id, photos: false } });
    setProducts(rows);
  }

  useEffect(() => {
    if (!active) return;
    setProducts(null);
    reload().catch((e: Error) => toast.error(e.message));
  }, [active?.id]);

  if (!active || !products) {
    return <Skeleton className="h-96 rounded-xl" />;
  }

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Catat mutasi</h1>
        <p className="mt-1 text-sm text-muted">
          Barang masuk, keluar, atau pindah antar gudang. Stok {active.name}{" "}
          langsung berubah.
        </p>
      </div>

      <Tabs defaultValue="in">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="in">Masuk</TabsTrigger>
          <TabsTrigger value="out">Keluar</TabsTrigger>
          <TabsTrigger value="pindah">Pindah</TabsTrigger>
        </TabsList>
        <TabsContent value="in">
          <MovementForm
            kind="in"
            products={products}
            warehouseId={active.id}
            onDone={reload}
          />
        </TabsContent>
        <TabsContent value="out">
          <MovementForm
            kind="out"
            products={products}
            warehouseId={active.id}
            onDone={reload}
          />
        </TabsContent>
        <TabsContent value="pindah">
          <TransferForm
            products={products}
            fromWarehouseId={active.id}
            warehouses={warehouses}
            onDone={reload}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MovementForm({
  kind,
  products,
  warehouseId,
  onDone,
}: {
  kind: "in" | "out";
  products: StockRow[];
  warehouseId: number;
  onDone: () => Promise<void>;
}) {
  const [productId, setProductId] = useState<number | null>(null);
  const [qty, setQty] = useState("");
  const [cost, setCost] = useState("");
  const [reason, setReason] = useState<string>(
    kind === "in" ? IN_REASONS[0] : OUT_REASONS[0],
  );
  const [note, setNote] = useState("");
  const [updateCost, setUpdateCost] = useState(false);
  const [pending, setPending] = useState(false);
  const selected = products.find((p) => p.id === productId);

  useEffect(() => {
    if (selected) setCost(String(Math.round(selected.costPrice)));
  }, [selected?.id]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!productId) {
      toast.error("Pilih produk dulu");
      return;
    }
    const n = Number(qty);
    if (!Number.isInteger(n) || n <= 0) {
      toast.error("Jumlah harus angka bulat lebih dari 0");
      return;
    }
    setPending(true);
    try {
      if (kind === "in") {
        await recordIn({
          data: {
            warehouseId,
            productId,
            qty: n,
            unitCost: Number(cost) || 0,
            reason,
            note: note.trim() || undefined,
            updateCost,
          },
        });
        toast.success(`Stok masuk ${n} pcs`);
      } else {
        await recordOut({
          data: {
            warehouseId,
            productId,
            qty: n,
            reason,
            note: note.trim() || undefined,
          },
        });
        toast.success(`Stok keluar ${n} pcs`);
      }
      setQty("");
      setNote("");
      await onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    } finally {
      setPending(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{kind === "in" ? "Barang masuk" : "Barang keluar"}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-3">
          <div className="grid gap-1.5">
            <Label>Produk</Label>
            <ProductPicker
              products={products}
              value={productId}
              onChange={setProductId}
            />
            {selected ? (
              <p className="text-xs text-muted">
                Stok sekarang {angka(selected.qty)} {selected.unit} · modal{" "}
                {rupiah(selected.costPrice)}
              </p>
            ) : null}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor={`qty-${kind}`}>Jumlah</Label>
              <Input
                id={`qty-${kind}`}
                inputMode="numeric"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                required
              />
            </div>
            {kind === "in" ? (
              <div className="grid gap-1.5">
                <Label htmlFor="cost-in">Harga modal / pcs</Label>
                <Input
                  id="cost-in"
                  inputMode="numeric"
                  value={cost}
                  onChange={(e) => setCost(e.target.value)}
                />
              </div>
            ) : (
              <div className="grid gap-1.5">
                <Label>Alasan</Label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {OUT_REASONS.map((r) => (
                      <SelectItem key={r} value={r}>
                        {r}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          {kind === "in" ? (
            <>
              <div className="grid gap-1.5">
                <Label>Asal barang</Label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {IN_REASONS.map((r) => (
                      <SelectItem key={r} value={r}>
                        {r}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={updateCost}
                  onCheckedChange={(v) => setUpdateCost(v === true)}
                />
                Perbarui harga modal produk
              </label>
            </>
          ) : null}
          <div className="grid gap-1.5">
            <Label htmlFor={`note-${kind}`}>Catatan</Label>
            <Textarea
              id={`note-${kind}`}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
            />
          </div>
          <Button type="submit" disabled={pending}>
            {pending
              ? "Menyimpan…"
              : kind === "in"
                ? "Simpan stok masuk"
                : "Simpan stok keluar"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function TransferForm({
  products,
  fromWarehouseId,
  warehouses,
  onDone,
}: {
  products: StockRow[];
  fromWarehouseId: number;
  warehouses: { id: number; name: string }[];
  onDone: () => Promise<void>;
}) {
  const others = warehouses.filter((w) => w.id !== fromWarehouseId);
  const [toId, setToId] = useState(others[0] ? String(others[0].id) : "");
  const [productId, setProductId] = useState<number | null>(null);
  const [qty, setQty] = useState("");
  const [note, setNote] = useState("");
  const [pending, setPending] = useState(false);
  const selected = products.find((p) => p.id === productId);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!productId) {
      toast.error("Pilih produk dulu");
      return;
    }
    if (!toId) {
      toast.error("Tambah gudang tujuan dulu di menu Gudang");
      return;
    }
    const n = Number(qty);
    if (!Number.isInteger(n) || n <= 0) {
      toast.error("Jumlah harus angka bulat lebih dari 0");
      return;
    }
    setPending(true);
    try {
      await recordTransfer({
        data: {
          fromWarehouseId,
          toWarehouseId: Number(toId),
          productId,
          qty: n,
          note: note.trim() || undefined,
        },
      });
      toast.success("Barang dipindahkan");
      setQty("");
      setNote("");
      await onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal pindah stok");
    } finally {
      setPending(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pindah antar gudang</CardTitle>
      </CardHeader>
      <CardContent>
        {others.length === 0 ? (
          <p className="text-sm text-muted">
            Baru ada satu gudang. Tambah lokasi lain di menu Gudang, lalu stok
            bisa dipindah ke sana.
          </p>
        ) : (
          <form onSubmit={submit} className="grid gap-3">
            <div className="grid gap-1.5">
              <Label>Ke gudang</Label>
              <Select value={toId} onValueChange={setToId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {others.map((w) => (
                    <SelectItem key={w.id} value={String(w.id)}>
                      {w.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label>Produk</Label>
              <ProductPicker
                products={products}
                value={productId}
                onChange={setProductId}
              />
              {selected ? (
                <p className="text-xs text-muted">
                  Tersedia {angka(selected.qty)} {selected.unit}
                </p>
              ) : null}
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="qty-tf">Jumlah</Label>
              <Input
                id="qty-tf"
                inputMode="numeric"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="note-tf">Catatan</Label>
              <Textarea
                id="note-tf"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={2}
              />
            </div>
            <Button type="submit" disabled={pending}>
              {pending ? "Memindahkan…" : "Pindahkan stok"}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
