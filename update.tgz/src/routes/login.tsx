import { createFileRoute, Navigate, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  authClient,
  authEnabled,
  GROK_PROVIDERS,
  signIn,
} from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { bootstrapAdmin, needsBootstrap } from "@/lib/staff-fn";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const router = useRouter();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"login" | "bootstrap">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    needsBootstrap()
      .then((r) => {
        if (r.needsAdmin) setMode("bootstrap");
      })
      .catch(() => {});
  }, []);

  if (!isPending && user) {
    return <Navigate to="/" />;
  }

  async function onLogin(e: FormEvent) {
    e.preventDefault();
    if (!authEnabled) return;
    setBusy(true);
    setError(null);
    try {
      const { error: err } = await authClient.signIn.email({
        email: email.trim(),
        password,
        callbackURL: "/",
      });
      if (err) throw new Error(err.message || "Email atau kata sandi salah");
      await router.invalidate();
      await router.navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal masuk");
    } finally {
      setBusy(false);
    }
  }

  async function onBootstrap(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await bootstrapAdmin({
        data: { name: name.trim(), email: email.trim(), password },
      });
      const { error: err } = await authClient.signIn.email({
        email: email.trim(),
        password,
        callbackURL: "/",
      });
      if (err) throw new Error(err.message || "Akun dibuat, gagal masuk otomatis");
      await router.invalidate();
      await router.navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal membuat admin");
    } finally {
      setBusy(false);
    }
  }

  const isBootstrap = mode === "bootstrap";

  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-4 py-10">
      <div className="w-full max-w-sm">
        <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">
          Gudang AHTA
        </p>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          {isBootstrap ? "Admin pertama" : "Masuk"}
        </h1>
        <p className="mt-1 text-sm text-muted">
          {isBootstrap
            ? "Sekali ini saja: buat admin. Setelah itu akun staf hanya dari menu Pengguna."
            : "Akun dibuat oleh admin. Tidak ada pendaftaran mandiri."}
        </p>

        {authEnabled ? (
          <div className="mt-6 space-y-5">
            <form
              onSubmit={isBootstrap ? onBootstrap : onLogin}
              className="grid gap-3"
            >
              {isBootstrap ? (
                <div className="grid gap-1.5">
                  <Label htmlFor="name">Nama</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
              ) : null}
              <div className="grid gap-1.5">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="username"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="password">Kata sandi</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete={isBootstrap ? "new-password" : "current-password"}
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error ? <p className="text-sm text-danger">{error}</p> : null}
              <Button type="submit" disabled={busy} className="h-11">
                {busy
                  ? "Menyimpan…"
                  : isBootstrap
                    ? "Buat admin & masuk"
                    : "Masuk"}
              </Button>
            </form>

            {!isBootstrap ? (
              <>
                <div className="flex items-center gap-3">
                  <span className="h-px flex-1 bg-border" />
                  <span className="text-xs text-muted">atau</span>
                  <span className="h-px flex-1 bg-border" />
                </div>
                <div className="grid gap-2">
                  {GROK_PROVIDERS.map((p) => (
                    <Button
                      key={p.providerId}
                      type="button"
                      variant="outline"
                      className="h-11"
                      onClick={() =>
                        void signIn(p.providerId, { callbackURL: "/" })
                      }
                    >
                      Masuk dengan {p.label}
                    </Button>
                  ))}
                </div>
              </>
            ) : null}
          </div>
        ) : (
          <p className="mt-6 text-sm text-muted">Masuk sedang dimatikan.</p>
        )}
      </div>
    </main>
  );
}
