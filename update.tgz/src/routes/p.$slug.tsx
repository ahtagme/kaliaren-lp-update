import { createFileRoute } from "@tanstack/react-router";
import { getPublicLanding } from "@/lib/lp-fn";
import { LandingView } from "@/components/lp/landing-view";
import { cdnPreconnect } from "@/lib/cdn";
import { lpHeadline, lpPunch } from "@/lib/lp-template";

export const Route = createFileRoute("/p/$slug")({
  validateSearch: (s: Record<string, unknown>): { embed?: "form" } =>
    s.embed === "form" ? { embed: "form" } : {},
  loader: async ({ params }) => {
    try {
      return await getPublicLanding({ data: { slug: params.slug } });
    } catch (err) {
      console.error("[lp]", params.slug, err);
      return null;
    }
  },
  head: ({ loaderData }) => {
    const cdn = cdnPreconnect(loaderData?.cdnBase ?? "");
    const lcp = (
      loaderData?.posterUrl ||
      loaderData?.heroImageUrl ||
      loaderData?.productPhotoUrls?.[0] ||
      ""
    ).trim();
    return {
      meta: [
        {
          title: loaderData ? lpHeadline(loaderData) : "Produk",
        },
        {
          name: "description",
          content: loaderData ? lpPunch(loaderData) : "Pesan dari gudang.",
        },
        {
          name: "viewport",
          content: "width=device-width, initial-scale=1, viewport-fit=cover",
        },
        { name: "format-detection", content: "telephone=no" },
        { name: "theme-color", content: "#ffffff" },
      ],
      links: [
        ...(lcp
          ? [{ rel: "preload" as const, as: "image" as const, href: lcp }]
          : []),
        ...(loaderData?.embed
          ? [
              { rel: "preconnect" as const, href: "https://cdn.orderonline.id" },
              { rel: "dns-prefetch" as const, href: "https://api.orderonline.id" },
            ]
          : []),
        ...(cdn ? [{ rel: "preconnect" as const, href: cdn }] : []),
        ...(loaderData?.metaPixelId
          ? [{ rel: "preconnect" as const, href: "https://connect.facebook.net" }]
          : []),
        ...(loaderData?.tiktokPixelId
          ? [{ rel: "preconnect" as const, href: "https://analytics.tiktok.com" }]
          : []),
      ],
    };
  },
  component: PublicLandingPage,
});

function PublicLandingPage() {
  const page = Route.useLoaderData();
  const { embed } = Route.useSearch();

  if (!page) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-6 text-center">
        <div>
          <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">
            Official Store
          </p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight">
            Halaman tidak ditemukan
          </h1>
          <p className="mt-2 text-sm text-muted">
            Landing page ini belum terbit atau tautannya salah.
          </p>
        </div>
      </main>
    );
  }

  return <LandingView page={page} embedFormOnly={embed === "form"} />;
}
