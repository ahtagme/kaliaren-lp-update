import { lazy, Suspense } from "react";
import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
  useRouterState,
} from "@tanstack/react-router";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Katana";
const StaffRoot = lazy(() => import("@/components/staff-root"));

export const Route = createRootRoute({
  loader: async () => [],
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content: "Pantau stok fisik, barang masuk-keluar, dan nilai gudang.",
      },
      { name: "theme-color", content: "#2C4638" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: RootDocument,
});

function RootDocument() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPublicLp = pathname.startsWith("/p/");
  const isBare = isPublicLp || pathname === "/login";
  return (
    <html lang="id" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        {isBare ? (
          <Outlet />
        ) : (
          <Suspense fallback={null}>
            <StaffRoot>
              <Outlet />
            </StaffRoot>
          </Suspense>
        )}
        <Scripts />
      </body>
    </html>
  );
}
