import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
  useRouterState,
} from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { AppShell } from "@/components/app-shell";
import { listWarehouses } from "@/lib/inventory-fn";
import { Toaster } from "sonner";
import appCss from "../styles.css?url";

const APP_NAME = "AHTA Stok";

export const Route = createRootRoute({
  loader: async ({ location }) => {
    const path = location.pathname;
    if (path === "/login" || path.startsWith("/p/")) return [];
    try {
      return await listWarehouses();
    } catch (err) {
      if (err instanceof Error && err.message === "Unauthorized") return [];
      throw err;
    }
  },
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Pantau stok fisik, barang masuk-keluar, dan nilai gudang AHTA.",
      },
      { name: "theme-color", content: "#2C4638" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: RootDocument,
});

function RootDocument() {
  const warehouses = Route.useLoaderData() ?? [];
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPublicLp = pathname.startsWith("/p/");
  return (
    <html lang="id" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <AppShell warehouses={warehouses}>
            <Outlet />
          </AppShell>
          {isPublicLp ? null : (
            <Toaster
              position="top-center"
              toastOptions={{
                className: "font-sans",
              }}
            />
          )}
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}
