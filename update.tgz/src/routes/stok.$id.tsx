import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, Megaphone } from "lucide-react";
import { getProductDetail, updateProduct } from "@/lib/inventory-fn";
import { createLanding, getLandingByProduct } from "@/lib/lp-fn";
import { CATEGORIES } from "@/lib/inventory";
import type { Movement, Product, ProductPhoto } from "@/lib/inventory";
import { useActiveWarehouse } from "@/lib/use-active-warehouse";
import { angka, formatWaktu, rupiah } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MovementBadge } from "@/components/stock-badge";
import { ProductPhotos } from "@/components/product-photos";

export const Route = createFileRoute("/stok/$id")({
  component: ProductDetailPage,
});

type Detail = {
  product: Product;
  photos: ProductPhoto[];
  stock: { warehouseId: number; warehouseName: string; qty: number; value: number }[];
  movements: Movement[];
};

function ProductDetailPage() {
  const { id } = Route.useParams();
  const productId = Number(id);
  const navigate = useNavigate();
  const { active } = useActiveWarehouse();
  const [detail, setDetail] = useState<Detail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [landing, setLanding] = useState<{
    id: number;
    slug: string;
    isPublished: boolean;
  } | null>(null);
  const [generating, setGenerating] = useState(false);

  async function reload() {
    const data = await getProductDetail({ data: { productId } });
    setDetail(data);
  }

  useEffect(() => {
    if (!Number.isInteger(productId) || productId <= 0) {
      setError("Produk tidak ditemukan");
      return;
    }
    setDetail(null);
    reload().catch((e: Error) => setError(e.message));
    getLandingByProduct({ data: { productId } })
      .then(setLanding)
      .catch(() => setLanding(null));
  }, [productId]);

  if (error) return <p className="text-danger">{error}</p>;
  if (!detail) return <Skeleton className="h-80 rounded-xl" />;

  const { product, stock, movements, photos } = detail;
  const totalQty = stock.reduce((s, r) => s + r.qty, 0);
  const totalValue = stock.reduce((s, r) => s + r.value, 0);

  async function generateLp() {
    if (!photos.length) {
      toast.error("Upload foto dulu. LP memakai foto produk.");
      return;
    }
    const warehouseId = active?.id ?? stock[0]?.warehouseId;
    if (!warehouseId) {
      toast.error("Pilih gudang dulu");
      return;
    }
    setGenerating(true);
    try {
      const created = await createLanding({
        data: { productId: product.id, warehouseId },
      });
      setLanding({ id: created.id, slug: created.slug, isPublished: true });
      if (created.source === "grok" && created.poster) {
        toast.success("Grok baca foto + poster panjang. LP siap.");
      } else if (created.source === "grok") {
        toast.success(created.aiError || "Grok baca foto. Poster belum jadi.");
      } else {
        toast.error(created.aiError || "AI tidak jalan. LP pakai template.");
      }
      navigate({ to: "/lp/$id", params: { id: String(created.id) } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal generate LP");
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-5">
      <div>
        <Link
          to="/stok"
          className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg"
        >
          <ArrowLeft className="size-4" />
          Semua stok
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          {product.name}
        </h1>
        <p className="font-mono text-sm text-muted">{product.sku}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            type="button"
            onClick={() => void generateLp()}
            disabled={generating || photos.length === 0}
          >
            <Megaphone className="size-4" />
            {generating
              ? "Grok baca foto…"
              : landing
                ? "Perbarui LP dari foto"
                : "Generate LP dari foto"}
          </Button>
          {landing ? (
            <>
              <Button variant="outline" asChild>
                <Link to="/lp/$id" params={{ id: String(landing.id) }}>
                  Edit LP + form
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/p/$slug" params={{ slug: landing.slug }}>
                  <ExternalLink className="size-4" />
                  Lihat LP
                </Link>
              </Button>
            </>
          ) : null}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Foto produk</CardTitle>
        </CardHeader>
        <CardContent>
          <ProductPhotos
            productId={product.id}
            photos={photos}
            onChange={(next) =>
              setDetail((d) =>
                d
                  ? {
                      ...d,
                      photos: next,
                      product: {
                        ...d.product,
                        imageUrl:
                          next.find((p) => p.isPrimary)?.url ?? next[0]?.url ?? "",
                      },
                    }
                  : d,
              )
            }
          />
          <p className="mt-3 text-xs text-muted">
            Upload foto kamu di sini. Foto utama jadi hero LP, foto lain jadi
            galeri. Setelah foto masuk, klik generate.
          </p>
        </CardContent>
      </Card>

      <section className="grid grid-cols-2 gap-3">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">
              Total fisik
            </p>
            <p className="mt-2 font-mono text-xl font-semibold tabular-nums">
              {angka(totalQty)} {product.unit}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">
              Nilai
            </p>
            <p className="mt-2 font-mono text-xl font-semibold tabular-nums">
              {rupiah(totalValue)}
            </p>
          </CardContent>
        </Card>
      </section>

      <Card>
        <CardHeader>
          <CardTitle>Stok per gudang</CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-2">
          <ul className="divide-y divide-border">
            {stock.map((s) => (
              <li
                key={s.warehouseId}
                className="flex items-center justify-between px-5 py-3"
              >
                <span className="text-sm">{s.warehouseName}</span>
                <span className="font-mono text-sm tabular-nums">
                  {angka(s.qty)} · {rupiah(s.value)}
                </span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <EditProductForm product={product} onSaved={reload} />

      <Card>
        <CardHeader>
          <CardTitle>Riwayat produk</CardTitle>
        </CardHeader>
        <CardContent className="px-0">
          {movements.length === 0 ? (
            <p className="px-5 pb-5 text-sm text-muted">Belum ada mutasi.</p>
          ) : (
            <ul className="divide-y divide-border">
              {movements.map((m) => (
                <li
                  key={m.id}
                  className="flex items-start justify-between gap-3 px-5 py-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{m.warehouseName}</p>
                    <p className="text-xs text-muted">
                      {m.reason ?? m.note ?? "—"} · {formatWaktu(m.createdAt)}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <MovementBadge type={m.type} />
                    <p className="font-mono text-sm tabular-nums">
                      {m.type === "out" || m.type === "transfer_out" ? "−" : "+"}
                      {angka(m.qty)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EditProductForm({
  product,
  onSaved,
}: {
  product: Product;
  onSaved: () => Promise<void>;
}) {
  const [pending, setPending] = useState(false);
  const [name, setName] = useState(product.name);
  const [sku, setSku] = useState(product.sku);
  const [category, setCategory] = useState(product.category);
  const [cost, setCost] = useState(String(Math.round(product.costPrice)));
  const [minStock, setMinStock] = useState(String(product.minStock));
  const [notes, setNotes] = useState(product.notes ?? "");

  useEffect(() => {
    setName(product.name);
    setSku(product.sku);
    setCategory(product.category);
    setCost(String(Math.round(product.costPrice)));
    setMinStock(String(product.minStock));
    setNotes(product.notes ?? "");
  }, [product]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setPending(true);
    try {
      await updateProduct({
        data: {
          id: product.id,
          name: name.trim(),
          sku: sku.trim(),
          category,
          unit: product.unit,
          costPrice: Number(cost) || 0,
          minStock: Number(minStock) || 0,
          notes: notes.trim() || undefined,
        },
      });
      toast.success("Produk diperbarui");
      await onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    } finally {
      setPending(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Data & harga modal</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="e-name">Nama</Label>
              <Input
                id="e-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="e-sku">SKU</Label>
              <Input
                id="e-sku"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                className="font-mono"
                required
              />
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="grid gap-1.5">
              <Label>Kategori</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                  {CATEGORIES.includes(category as (typeof CATEGORIES)[number]) ? null : (
                    <SelectItem value={category}>{category}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="e-cost">Harga modal (Rp)</Label>
              <Input
                id="e-cost"
                inputMode="numeric"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="e-min">Stok minimum</Label>
              <Input
                id="e-min"
                inputMode="numeric"
                value={minStock}
                onChange={(e) => setMinStock(e.target.value)}
              />
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="e-notes">Catatan</Label>
            <Textarea
              id="e-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
          <div>
            <Button type="submit" disabled={pending}>
              {pending ? "Menyimpan…" : "Simpan perubahan"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
