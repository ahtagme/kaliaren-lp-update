import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { ArrowLeft, Copy, Download, ExternalLink } from "lucide-react";
import { getLanding, updateLanding } from "@/lib/lp-fn";
import { listWarehouses } from "@/lib/inventory-fn";
import { listLpDomains } from "@/lib/settings-fn";
import type { LandingPage } from "@/lib/lp";
import { discountPercent } from "@/lib/lp";
import { lpAdUrl, mergeDomainChoices, normalizeLpHost } from "@/lib/lp-domains";
import { describeEmbed, parseOrderOnlineEmbed } from "@/lib/orderonline";
import { downloadNodeAsWebp } from "@/lib/export-webp";
import { LpCreative } from "@/components/lp/lp-creative";
import type { Warehouse } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/lp/$id")({
  component: LandingEditorPage,
});

type Draft = {
  warehouseId: string;
  slug: string;
  isPublished: boolean;
  publicDomain: string;
  trustBanner: string;
  headline: string;
  subheadline: string;
  heroImageUrl: string;
  benefits: string;
  gallery: string;
  specs: string;
  price: string;
  compareAtPrice: string;
  soldCount: string;
  ctaPrimary: string;
  ctaSecondary: string;
  proofs: string;
  testimonials: string;
  formTitle: string;
  formNote: string;
  embedCode: string;
  metaPixelId: string;
  tiktokPixelId: string;
};

function toDraft(p: LandingPage): Draft {
  return {
    warehouseId: String(p.warehouseId),
    slug: p.slug,
    isPublished: p.isPublished,
    publicDomain: p.publicDomain,
    trustBanner: p.trustBanner,
    headline: p.headline,
    subheadline: p.subheadline,
    heroImageUrl: p.heroImageUrl,
    benefits: p.benefits.join("\n"),
    gallery: p.gallery.join("\n"),
    specs: p.specs.map((s) => `${s.label} | ${s.value}`).join("\n"),
    price: String(p.price),
    compareAtPrice: String(p.compareAtPrice),
    soldCount: String(p.soldCount),
    ctaPrimary: p.ctaPrimary,
    ctaSecondary: p.ctaSecondary,
    proofs: p.proofs.map((x) => `${x.caption} | ${x.imageUrl}`).join("\n"),
    testimonials: p.testimonials
      .map((t) => `${t.name} | ${t.city} | ${t.rating} | ${t.text}`)
      .join("\n"),
    formTitle: p.formTitle,
    formNote: p.formNote,
    embedCode: p.embedCode ?? "",
    metaPixelId: p.metaPixelId ?? "",
    tiktokPixelId: p.tiktokPixelId ?? "",
  };
}

function lines(value: string): string[] {
  return value
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}

function parseSpecs(value: string) {
  return lines(value).map((row) => {
    const [label, ...rest] = row.split("|");
    return { label: (label ?? "").trim(), value: rest.join("|").trim() || "-" };
  }).filter((s) => s.label);
}

function parseProofs(value: string) {
  return lines(value).map((row) => {
    const idx = row.lastIndexOf("|");
    if (idx < 0) return { caption: row, imageUrl: row };
    return {
      caption: row.slice(0, idx).trim(),
      imageUrl: row.slice(idx + 1).trim(),
    };
  }).filter((p) => p.imageUrl);
}

function parseTestimonials(value: string) {
  return lines(value).map((row) => {
    const parts = row.split("|").map((s) => s.trim());
    return {
      name: parts[0] || "Pembeli",
      city: parts[1] || "Indonesia",
      rating: Math.min(5, Math.max(1, Number(parts[2]) || 5)),
      text: parts.slice(3).join(" | ") || "",
    };
  }).filter((t) => t.text);
}

function LandingEditorPage() {
  const { id } = Route.useParams();
  const landingId = Number(id);
  const [page, setPage] = useState<LandingPage | null>(null);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [domains, setDomains] = useState<string[]>([]);
  const [primaryDomain, setPrimaryDomain] = useState("");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    if (!Number.isInteger(landingId) || landingId <= 0) {
      setError("Landing page tidak ditemukan");
      return;
    }
    Promise.all([
      getLanding({ data: { id: landingId } }),
      listWarehouses(),
      listLpDomains(),
    ])
      .then(([lp, wh, dom]) => {
        setPage(lp);
        setDraft(toDraft(lp));
        setWarehouses(wh);
        setPrimaryDomain(dom.primary);
        setDomains(dom.choices);
      })
      .catch((e: Error) => setError(e.message));
  }, [landingId]);

  useEffect(() => {
    if (!exporting || !draft) return;
    let cancelled = false;
    const timer = window.setTimeout(() => {
      const node = document.getElementById("lp-export");
      if (!node) {
        setExporting(false);
        toast.error("Preview belum siap");
        return;
      }
      void downloadNodeAsWebp(node, `${draft.slug || "lp"}.webp`)
        .then(() => {
          if (!cancelled) toast.success("WebP tersimpan");
        })
        .catch((err) => {
          if (!cancelled) {
            toast.error(err instanceof Error ? err.message : "Gagal unduh WebP");
          }
        })
        .finally(() => {
          if (!cancelled) setExporting(false);
        });
    }, 80);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [exporting, draft]);

  function set<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((d) => (d ? { ...d, [key]: value } : d));
  }

  async function onSave(e: FormEvent) {
    e.preventDefault();
    if (!draft) return;
    setPending(true);
    try {
      const result = await updateLanding({
        data: {
          id: landingId,
          warehouseId: Number(draft.warehouseId),
          slug: draft.slug.trim(),
          isPublished: draft.isPublished,
          publicDomain: draft.publicDomain,
          trustBanner: draft.trustBanner.trim(),
          headline: draft.headline.trim(),
          subheadline: draft.subheadline.trim(),
          heroImageUrl: draft.heroImageUrl.trim(),
          benefits: lines(draft.benefits),
          gallery: lines(draft.gallery),
          specs: parseSpecs(draft.specs),
          price: Number(draft.price) || 0,
          compareAtPrice: Number(draft.compareAtPrice) || 0,
          soldCount: Number(draft.soldCount) || 0,
          ctaPrimary: draft.ctaPrimary.trim(),
          ctaSecondary: draft.ctaSecondary.trim(),
          proofs: parseProofs(draft.proofs),
          testimonials: parseTestimonials(draft.testimonials),
          formTitle: draft.formTitle.trim() || "Form Pemesanan",
          formNote: draft.formNote.trim(),
          embedCode: draft.embedCode,
          metaPixelId: draft.metaPixelId,
          tiktokPixelId: draft.tiktokPixelId,
        },
      });
      toast.success("Landing page disimpan");
      setDraft((d) => (d ? { ...d, slug: result.slug } : d));
      if (page) setPage({ ...page, slug: result.slug, isPublished: draft.isPublished });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    } finally {
      setPending(false);
    }
  }

  async function copyText(label: string, text: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} disalin`);
    } catch {
      toast.error("Tidak bisa menyalin");
    }
  }

  async function unduhWebp() {
    if (!draft) return;
    setExporting(true);
  }

  const parsedCheckout = useMemo(() => {
    const raw = draft?.embedCode ?? "";
    const embed = parseOrderOnlineEmbed(raw);
    if (embed) return { embed, checkoutUrl: "" };
    const m = raw.trim().match(/https?:\/\/[^\s"'<>]+/i);
    return { embed: null, checkoutUrl: m?.[0] ?? "" };
  }, [draft?.embedCode]);

  if (error) return <p className="text-danger">{error}</p>;
  if (!page || !draft) return <Skeleton className="h-80 rounded-xl" />;

  const hostChoices = mergeDomainChoices(
    draft.publicDomain || primaryDomain || (typeof window !== "undefined" ? window.location.host : ""),
    domains,
  );
  const adHost = normalizeLpHost(draft.publicDomain) || hostChoices[0] || "";
  const adUrl = lpAdUrl(adHost, draft.slug);
  const disc = discountPercent(Number(draft.price) || 0, Number(draft.compareAtPrice) || 0);

  return (
    <form onSubmit={onSave} className="mx-auto flex max-w-3xl flex-col gap-6 pb-16">
      <div>
        <Link
          to="/lp"
          className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg"
        >
          <ArrowLeft className="size-4" />
          Semua landing
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">{page.productName}</h1>
        <p className="font-mono text-sm text-muted">{page.sku}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {draft.isPublished ? (
          <Button type="button" variant="outline" asChild>
            <a href={adUrl} target="_blank" rel="noreferrer">
              <ExternalLink className="size-4" />
              Lihat LP
            </a>
          </Button>
        ) : null}
        <Button
          type="button"
          variant="outline"
          onClick={() => copyText("Tautan iklan", adUrl)}
        >
          <Copy className="size-4" />
          Salin tautan
        </Button>
        <Button type="button" variant="outline" onClick={() => void unduhWebp()} disabled={exporting}>
          <Download className="size-4" />
          {exporting ? "Menyimpan…" : "Unduh WebP"}
        </Button>
      </div>

      {exporting ? (
      <div
        aria-hidden
        className="pointer-events-none fixed top-0 left-[-9999px] w-[420px]"
      >
        <LpCreative
          id="lp-export"
          page={{
            ...page,
            headline: draft.headline,
            subheadline: draft.subheadline,
            trustBanner: draft.trustBanner,
            heroImageUrl: draft.heroImageUrl,
            gallery: lines(draft.gallery),
            benefits: lines(draft.benefits),
            specs: parseSpecs(draft.specs),
            proofs: parseProofs(draft.proofs),
            testimonials: parseTestimonials(draft.testimonials),
            price: Number(draft.price) || 0,
            compareAtPrice: Number(draft.compareAtPrice) || 0,
            soldCount: Number(draft.soldCount) || 0,
            ctaPrimary: draft.ctaPrimary,
            ctaSecondary: draft.ctaSecondary,
            stockQty: page.stockQty,
          }}
        />
      </div>
      ) : null}

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">Terbit & gudang</legend>
        <label className="flex items-center gap-3 text-sm">
          <Checkbox
            checked={draft.isPublished}
            onCheckedChange={(v) => set("isPublished", v === true)}
          />
          Terbitkan (bisa dibuka publik)
        </label>
        <div className="grid gap-1.5">
          <Label>Domain iklan</Label>
          <Select value={adHost} onValueChange={(v) => set("publicDomain", v)}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih domain" />
            </SelectTrigger>
            <SelectContent>
              {hostChoices.map((host) => (
                <SelectItem key={host} value={host}>
                  {host}
                  {host === primaryDomain ? " · utama" : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="font-mono text-xs text-subtle break-all">{adUrl}</p>
          <p className="text-xs text-muted">
            Tautan ini yang dipakai di iklan. Domain lain ditambah dari daftar Landing.
          </p>
        </div>
        <div className="grid gap-1.5">
          <Label>Slug URL</Label>
          <Input value={draft.slug} onChange={(e) => set("slug", e.target.value)} />
        </div>
        <div className="grid gap-1.5">
          <Label>Potong stok dari</Label>
          <Select value={draft.warehouseId} onValueChange={(v) => set("warehouseId", v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {warehouses.map((w) => (
                <SelectItem key={w.id} value={String(w.id)}>
                  {w.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">Form / checkout</legend>
        <p className="text-sm text-muted">
          Tempel embed OrderOnline, atau tautan checkout. Domain iklan sering
          gagal embed — tautan lebih aman. Tombol PESAN mengarah ke tautan itu.
        </p>
        <Label htmlFor="embed-code">Embed atau tautan</Label>
        <Textarea
          id="embed-code"
          className="min-h-28 font-mono text-xs"
          value={draft.embedCode}
          onChange={(e) => set("embedCode", e.target.value)}
          placeholder={"https://ahtashop.orderonline.id/produk-kamu\natau kode embed OrderOnline"}
          spellCheck={false}
        />
        {draft.embedCode.trim() ? (
          parsedCheckout.embed ? (
            <p className="text-sm text-ok">
              Embed siap: {describeEmbed(parsedCheckout.embed)}
            </p>
          ) : parsedCheckout.checkoutUrl ? (
            <p className="text-sm text-ok">
              Tombol PESAN → {parsedCheckout.checkoutUrl}
            </p>
          ) : (
            <p className="text-sm text-danger">
              Bukan embed utuh dan bukan tautan https://
            </p>
          )
        ) : (
          <p className="text-xs text-muted">
            Kosong = LP tanpa checkout. Tempel tautan OrderOnline paling simpel.
          </p>
        )}
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">Pixel iklan</legend>
        <p className="text-sm text-muted">
          Isi ID pixel, atau tempel kode pixel utuh. Tiap LP pixel-nya sendiri.
        </p>
        <div className="grid gap-1.5">
          <Label htmlFor="meta-pixel">Meta Ads (Facebook / Instagram)</Label>
          <Input
            id="meta-pixel"
            value={draft.metaPixelId}
            onChange={(e) => set("metaPixelId", e.target.value)}
            placeholder="123456789012345"
            autoComplete="off"
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="tt-pixel">TikTok Ads</Label>
          <Input
            id="tt-pixel"
            value={draft.tiktokPixelId}
            onChange={(e) => set("tiktokPixelId", e.target.value)}
            placeholder="CXXXXXXXXXXXXXXX"
            autoComplete="off"
          />
        </div>
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">1 · Banner trust</legend>
        <Input
          value={draft.trustBanner}
          onChange={(e) => set("trustBanner", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">2 · Hero image</legend>
        <Label>URL gambar</Label>
        <Input
          value={draft.heroImageUrl}
          onChange={(e) => set("heroImageUrl", e.target.value)}
          placeholder="/lp/foto.jpg atau foto produk"
        />
        {draft.heroImageUrl ? (
          <img
            src={draft.heroImageUrl}
            alt=""
            className="aspect-video w-full max-w-md rounded-lg object-cover"
          />
        ) : null}
        {page.productPhotoUrls?.length ? (
          <div className="grid gap-2">
            <p className="text-xs text-muted">Foto dari produk — klik untuk pakai</p>
            <div className="flex flex-wrap gap-2">
              {page.productPhotoUrls.map((url) => (
                <button
                  key={url}
                  type="button"
                  onClick={() => {
                    set("heroImageUrl", url);
                    const existing = draft.gallery
                      .split("\n")
                      .map((s) => s.trim())
                      .filter(Boolean);
                    const extras = page.productPhotoUrls!.filter((u) => u !== url);
                    const merged = [...new Set([...extras, ...existing])];
                    set("gallery", merged.join("\n"));
                  }}
                  className="size-16 overflow-hidden rounded-md bg-ink"
                >
                  <img src={url} alt="" className="size-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-xs text-muted">
            Upload foto di halaman produk, lalu foto itu bisa dipakai di sini.
          </p>
        )}
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">3 · Headline + deskripsi</legend>
        <Label>Headline</Label>
        <Textarea
          value={draft.headline}
          onChange={(e) => set("headline", e.target.value)}
        />
        <Label>Deskripsi emosional</Label>
        <Textarea
          value={draft.subheadline}
          onChange={(e) => set("subheadline", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">4 · CTA pertama (Ambil Promo)</legend>
        <Input value={draft.ctaPrimary} onChange={(e) => set("ctaPrimary", e.target.value)} />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">5 · Keunggulan (satu baris satu poin)</legend>
        <Textarea
          className="min-h-36"
          value={draft.benefits}
          onChange={(e) => set("benefits", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">6 · Foto produk (satu URL per baris)</legend>
        <Textarea
          className="min-h-28"
          value={draft.gallery}
          onChange={(e) => set("gallery", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">7 · Spesifikasi (Label | Isi)</legend>
        <Textarea
          className="min-h-32"
          value={draft.specs}
          onChange={(e) => set("specs", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">8 · Harga coret + terjual</legend>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label>Harga jual</Label>
            <Input
              inputMode="numeric"
              value={draft.price}
              onChange={(e) => set("price", e.target.value)}
            />
          </div>
          <div className="grid gap-1.5">
            <Label>Harga coret</Label>
            <Input
              inputMode="numeric"
              value={draft.compareAtPrice}
              onChange={(e) => set("compareAtPrice", e.target.value)}
            />
          </div>
        </div>
        <div className="grid gap-1.5">
          <Label>Jumlah terjual (tampil di LP)</Label>
          <Input
            inputMode="numeric"
            value={draft.soldCount}
            onChange={(e) => set("soldCount", e.target.value)}
          />
        </div>
        {disc > 0 ? (
          <p className="text-sm text-muted">Diskon tampil: {disc}%</p>
        ) : null}
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">9 · CTA kedua (tombol animasi)</legend>
        <Input
          value={draft.ctaPrimary}
          onChange={(e) => set("ctaPrimary", e.target.value)}
        />
        <p className="text-xs text-muted">Teks sama dengan CTA pertama. Di LP tombol ini berdenyut.</p>
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">
          10 · Bukti kirim tambahan (Keterangan | URL)
        </legend>
        <p className="text-xs text-muted">
          Foto gudang & packing sudah ada di template. Isi ini hanya kalau mau
          tambah foto sendiri.
        </p>
        <Textarea
          className="min-h-28"
          value={draft.proofs}
          onChange={(e) => set("proofs", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">
          11 · Testimoni teks (Nama | Kota | Rating | Isi)
        </legend>
        <p className="text-xs text-muted">
          Screenshot chat WA sudah di template. Isi ini tampil di bawahnya.
        </p>
        <Textarea
          className="min-h-36"
          value={draft.testimonials}
          onChange={(e) => set("testimonials", e.target.value)}
        />
      </fieldset>

      <fieldset className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <legend className="px-1 text-sm font-semibold">
          12 · CTA terakhir (Pesan Sekarang Bisa COD)
        </legend>
        <Input
          value={draft.ctaSecondary}
          onChange={(e) => set("ctaSecondary", e.target.value)}
        />
      </fieldset>

      <Button type="submit" disabled={pending} className="h-12">
        {pending ? "Menyimpan…" : "Simpan landing page"}
      </Button>
    </form>
  );
}
