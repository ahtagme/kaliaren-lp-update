import { createServerFn } from "@tanstack/react-start";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { hashPassword } from "better-auth/crypto";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

export type StaffRole = "admin" | "staff";

export type StaffUser = {
  id: string;
  name: string;
  email: string;
  role: StaffRole;
  isActive: boolean;
  createdAt: string;
};

type ProfileRow = {
  user_id: string;
  role: StaffRole;
  is_active: boolean;
};

async function countCredentialAccounts(): Promise<number> {
  const sql = await getSql();
  const rows = await sql.query<{ n: number }>(
    `select count(*)::int as n from account where "providerId" = 'credential'`,
  );
  return rows[0]?.n ?? 0;
}

export async function ensureStaffProfile(userId: string): Promise<{
  role: StaffRole;
  isActive: boolean;
}> {
  const sql = await getSql();
  const existing = await sql.query<ProfileRow>(
    `select user_id, role, is_active from staff_profiles where user_id = $1`,
    [userId],
  );
  if (existing[0]) {
    return { role: existing[0].role, isActive: Boolean(existing[0].is_active) };
  }
  const counts = await sql.query<{ n: number }>(
    `select count(*)::int as n from staff_profiles`,
  );
  if ((counts[0]?.n ?? 0) > 0) {
    throw new Error("Akun tidak terdaftar. Minta admin membuat akun di menu Pengguna.");
  }
  await sql.query(
    `insert into staff_profiles (user_id, role, is_active)
     values ($1, 'admin', true)
     on conflict (user_id) do nothing`,
    [userId],
  );
  return { role: "admin", isActive: true };
}

export async function assertActiveStaff(userId: string): Promise<{
  role: StaffRole;
  isActive: boolean;
}> {
  const profile = await ensureStaffProfile(userId);
  if (!profile.isActive) throw new Error("Akun dinonaktifkan");
  return profile;
}

async function requireAdmin(userId: string): Promise<void> {
  const profile = await assertActiveStaff(userId);
  if (profile.role !== "admin") throw new Error("Hanya admin yang bisa mengelola user");
}

export const needsBootstrap = createServerFn({ method: "GET" }).handler(
  async () => {
    try {
      const n = await countCredentialAccounts();
      return { needsAdmin: n === 0 };
    } catch {
      return { needsAdmin: true };
    }
  },
);

async function insertCredentialUser(input: {
  name: string;
  email: string;
  password: string;
  role: StaffRole;
}): Promise<string> {
  const sql = await getSql();
  const userId = randomUUID();
  const accountId = randomUUID();
  const hashed = await hashPassword(input.password);
  await sql.query(
    `insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
     values ($1, $2, $3, true, now(), now())`,
    [userId, input.name, input.email],
  );
  await sql.query(
    `insert into "account" (
       id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt"
     ) values ($1, $2, 'credential', $3, $4, now(), now())`,
    [accountId, userId, userId, hashed],
  );
  await sql.query(
    `insert into staff_profiles (user_id, role, is_active)
     values ($1, $2, true)
     on conflict (user_id) do update set role = excluded.role, is_active = true`,
    [userId, input.role],
  );
  return userId;
}

export const bootstrapAdmin = createServerFn({ method: "POST" })
  .validator(
    z.object({
      name: z.string().min(2).max(80),
      email: z.string().email(),
      password: z.string().min(8).max(80),
    }),
  )
  .handler(async ({ data }) => {
    if ((await countCredentialAccounts()) > 0) {
      throw new Error("Admin sudah ada. Silakan masuk.");
    }
    const email = data.email.trim().toLowerCase();
    const sql = await getSql();
    const dup = await sql.query<{ id: string }>(
      `select id from "user" where lower(email) = $1`,
      [email],
    );
    if (dup[0]) throw new Error("Email sudah terpakai. Masuk dengan akun itu, atau pakai email lain.");
    await insertCredentialUser({
      name: data.name.trim(),
      email,
      password: data.password,
      role: "admin",
    });
    return { ok: true as const };
  });

const staffMemo = new Map<string, { at: number; profile: { role: StaffRole; isActive: boolean } }>();

export const getMyStaff = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const hit = staffMemo.get(context.userId);
    if (hit && Date.now() - hit.at < 45_000) return hit.profile;
    const profile = await ensureStaffProfile(context.userId);
    if (!profile.isActive) throw new Error("Akun dinonaktifkan");
    staffMemo.set(context.userId, { at: Date.now(), profile });
    return profile;
  });

export const listStaffUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<StaffUser[]> => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const rows = await sql.query<{
      id: string;
      name: string;
      email: string;
      role: StaffRole | null;
      is_active: boolean | null;
      createdAt: string | Date;
    }>(
      `select u.id, u.name, u.email, s.role, s.is_active, u."createdAt"
       from "user" u
       left join staff_profiles s on s.user_id = u.id
       order by u."createdAt" asc`,
    );
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      email: r.email,
      role: r.role ?? "staff",
      isActive: Boolean(r.is_active),
      createdAt:
        r.createdAt instanceof Date
          ? r.createdAt.toISOString()
          : new Date(r.createdAt).toISOString(),
    }));
  });

export const createStaffUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      name: z.string().min(2).max(80),
      email: z.string().email(),
      password: z.string().min(8).max(80),
      role: z.enum(["admin", "staff"]),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const email = data.email.trim().toLowerCase();
    const sql = await getSql();
    const dup = await sql.query<{ id: string }>(
      `select id from "user" where lower(email) = $1`,
      [email],
    );
    if (dup[0]) throw new Error("Email sudah terdaftar");

    const userId = await insertCredentialUser({
      name: data.name.trim(),
      email,
      password: data.password,
      role: data.role,
    });
    return { id: userId, ok: true as const };
  });

export const updateStaffUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      userId: z.string().min(1),
      role: z.enum(["admin", "staff"]).optional(),
      isActive: z.boolean().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    if (data.userId === context.userId && data.isActive === false) {
      throw new Error("Tidak bisa menonaktifkan akun sendiri");
    }
    if (data.userId === context.userId && data.role === "staff") {
      throw new Error("Tidak bisa menurunkan peran sendiri");
    }
    const sql = await getSql();
    const role = data.role ?? null;
    const isActive = data.isActive === undefined ? null : data.isActive;
    await sql.query(
      `insert into staff_profiles (user_id, role, is_active)
       values ($1, coalesce($2, 'staff'), coalesce($3, true))
       on conflict (user_id) do update set
         role = coalesce($2, staff_profiles.role),
         is_active = coalesce($3, staff_profiles.is_active)`,
      [data.userId, role, isActive],
    );
    return { ok: true as const };
  });
