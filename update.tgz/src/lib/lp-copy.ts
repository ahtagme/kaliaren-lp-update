import type { LpSpec, LpTestimonial } from "@/lib/lp";

export type ExtremeCopy = {
  trustBanner: string;
  headline: string;
  subheadline: string;
  benefits: string[];
  specs: LpSpec[];
  testimonials: LpTestimonial[];
  ctaPrimary: string;
  ctaSecondary: string;
  formTitle: string;
  formNote: string;
  proofs: { caption: string; imageUrl: string }[];
};

type Angle = {
  problem: string;
  punch: string;
  why: string[];
  edu: string[];
  stories: LpTestimonial[];
  close: string;
};

function brandWord(name: string) {
  const first = name.trim().split(/\s+/)[0] ?? name;
  return first.slice(0, 18).toUpperCase();
}

function stories(
  a: [string, string, string],
  b: [string, string, string],
  c: [string, string, string],
): LpTestimonial[] {
  return [
    { name: a[0], city: a[1], text: a[2], rating: 5 },
    { name: b[0], city: b[1], text: b[2], rating: 5 },
    { name: c[0], city: c[1], text: c[2], rating: 5 },
  ];
}

function detectAngle(name: string): Angle {
  const n = name.toLowerCase();

  if (/parfum|perfume|tapputi|raudhah|wangi/.test(n)) {
    return {
      problem: "WANGI CEPAT HILANG?",
      punch: "JANGAN PAKAI YANG CEPAT LENYAP",
      why: ["Tahan lama", "Cocok harian", "Bukan PHP", "Stok gudang"],
      edu: [
        "Satu semprot, nempel.",
        "Cocok kerja dan undangan.",
        "Bukan foto temple. Stok fisik.",
        "COD. Cek di kurir, baru bayar.",
      ],
      stories: stories(
        ["Rina S.", "Bandung", "Wangi nempel. Bukan yang ilang 5 menit."],
        ["Andi P.", "Bekasi", "Stok fisik. COD. Deal. Gak nyesel."],
        ["Laila M.", "Surabaya", "Temen beli duluan. Gua nyusul. Ambil."],
      ),
      close: "Kalau memang mau, order sekarang",
    };
  }

  if (/shampo|rambut|ketombe|colouring|ginseng|hair/.test(n)) {
    return {
      problem: "RAMBUT RONTOK & KETOMBEAN?",
      punch: "JANGAN DIBIARKAN MAKIN PARAH",
      why: [
        "Bantu kurangi ketombe",
        "Bantu rawat kulit kepala",
        "Nyaman dipakai rutin",
        "Cocok pria & wanita",
      ],
      edu: [
        "Kulit kepala terasa lebih bersih",
        "Rambut tampak lebih rapi",
        "Lebih nyaman dari rasa gatal",
        "Mudah dipakai sehari-hari",
      ],
      stories: stories(
        ["Rina S.", "Bandung", "Baru pakai rutin, kulit kepala terasa lebih nyaman."],
        ["Andi P.", "Jakarta", "Ketombenya lebih terawat, rambut juga terasa lebih bersih."],
        ["Laila M.", "Surabaya", "Packing aman, barang datang bagus, admin responsif."],
      ),
      close: "Kalau memang mau rawat rambutmu, order sekarang",
    };
  }

  if (/lotion|cream|acne|keloid|sabun|foam/.test(n)) {
    return {
      problem: "KULIT MASIH BANDEL?",
      punch: "JANGAN TUNDA PAKAI YANG BENAR",
      why: ["Pakai rutin", "Terasa ringan", "Stok gudang", "Barang sesuai foto"],
      edu: [
        "Pakai sesuai petunjuk. Rutin.",
        "Bukan PHP. Barang fisik.",
        "Cek di kurir. Pas, bayar.",
        "Sisa dikit. Jangan nanti.",
      ],
      stories: stories(
        ["Rina S.", "Bandung", "Rutin 1 minggu. Kelihatan bedanya."],
        ["Andi P.", "Bekasi", "Bukan yang foto doang. Barang dateng."],
        ["Laila M.", "Surabaya", "COD. Cek. Bayar. Selesai."],
      ),
      close: "Kalau memang mau, order sekarang",
    };
  }

  if (/kacamata|lensa|fokus|polarized|krystal|baca/.test(n)) {
    return {
      problem: "MATA CEPAT LELAH?",
      punch: "JANGAN PAKSA TANPA BANTUAN",
      why: ["Pakai nyaman", "Tampil rapi", "Stok terbatas", "Barang sesuai foto"],
      edu: [
        "Langsung terasa bedanya pas dipakai.",
        "Cocok kerja dan jalan.",
        "Stok fisik gudang. Bukan PHP.",
        "Cek di tempat. Deal.",
      ],
      stories: stories(
        ["Rina S.", "Bandung", "Pakai sehari, mata gak gampang pedes."],
        ["Andi P.", "Bekasi", "Barang sesuai foto. COD lancar."],
        ["Laila M.", "Surabaya", "Sisa dikit. Untung sempat ambil."],
      ),
      close: "Kalau memang mau, order sekarang",
    };
  }

  const short = name.length > 28 ? `${name.slice(0, 26)}…` : name;
  return {
    problem: `${short.toUpperCase()} INI YANG LAGI DICARI`,
    punch: "STOK FISIK. BUKAN PHP. YANG TELAT, KEHABISAN.",
    why: ["Stok gudang", "Barang sesuai foto", "Sisa terbatas", "Banyak yang ambil"],
    edu: [
      "Stok dari gudang. Bukan foto temple.",
      "Cek di kurir. Pas, bayar.",
      "Yang scroll “nanti” biasanya kehabisan.",
      "Ikut yang sudah order. Jangan nyesel.",
    ],
    stories: stories(
      ["Rina S.", "Bandung", "Ragu 2 hari. Pas checkout stok tinggal dikit. Untung sempat."],
      ["Andi P.", "Bekasi", "Yang lain PHP. Ini barang beneran. COD, cek, bayar. Selesai."],
      ["Laila M.", "Surabaya", "Temen beli duluan. Gua nyusul. Kalau masih ada, ambil."],
    ),
    close: "Kalau memang mau, order sekarang",
  };
}

/** Copy LP: overclaim, hard sell, ikut-ikutan, terbatas, anti PHP, anti retur, closing. Pendek. */
export function extremeCopyFor(name: string): ExtremeCopy {
  const angle = detectAngle(name);
  return {
    trustBanner: `${brandWord(name)} · OFFICIAL STORE`,
    headline: angle.problem,
    subheadline: angle.punch,
    benefits: angle.why,
    specs: angle.edu.map((value) => ({ label: "✓", value })),
    testimonials: angle.stories,
    ctaPrimary: "PESAN SEKARANG",
    ctaSecondary: "CHECKOUT SEKARANG",
    formTitle: "Form Pemesanan",
    formNote: angle.close,
    proofs: [] as { caption: string; imageUrl: string }[],
  };
}
