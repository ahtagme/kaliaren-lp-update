import type { ExtremeCopy } from "@/lib/lp-copy";
import { grokImagineEdit } from "@/lib/xai";

export type LpPoster = { mime: string; data: string };

function dataUrl(mime: string, data: string) {
  if (data.startsWith("data:")) return data;
  const type = mime.startsWith("image/") ? mime : "image/jpeg";
  return `data:${type};base64,${data}`;
}

function panelPrompt(kind: "top" | "bottom", name: string, copy: ExtremeCopy) {
  const why = copy.benefits.slice(0, 4).join(" · ");
  const edu = copy.specs.map((s) => s.value).slice(0, 4).join(" · ");
  const stories = copy.testimonials
    .slice(0, 3)
    .map((t) => `${t.name}: ${t.text}`)
    .join(" / ");

  const brief = `Buatkan panel LP versi NEXT LEVEL. Gabung: overclaim, hard selling, hukum ikut-ikutan, hukum keterbatasan, anti PHP, anti retur, edukasi terselubung, testimoni brutal, no mercy closing. SIAP UNTUK ORANG LANGSUNG BELI TANPA MIKIR.
Gambar panjang 9:16, HP. Tulisan sedang, jangan kecil. Sedikit teks, simpel, high conversion. Bahasa Indonesia. Latar putih, headline hitam, aksen kuning neon, tombol merah.
PAKAI PRODUK PERSIS DARI FOTO REFERENSI (kemasan, label, bentuk). Jangan ganti produk. Tidak ada watermark.`;

  if (kind === "top") {
    return `${brief}

Panel ATAS:
- Header kecil: ${copy.trustBanner}
- Foto produk besar
- Headline: ${copy.headline}
- Punch kuning: ${copy.subheadline}
- 3 bullet: ${why}
- Tombol merah: ${copy.ctaPrimary}
Produk: ${name}`;
  }
  return `${brief}

Panel BAWAH, produk yang sama:
- Edukasi: ${edu}
- 3 testimoni brutal: ${stories}
- Scarcity: sisa terbatas
- Closing: ${copy.formNote}
- Tombol merah: ${copy.ctaSecondary}
Produk: ${name}`;
}

export async function grokLongLpPosters(opts: {
  name: string;
  mime: string;
  data: string;
  copy: ExtremeCopy;
}): Promise<{ top: LpPoster | null; bottom: LpPoster | null }> {
  const imageDataUrl = dataUrl(opts.mime, opts.data);
  const [top, bottom] = await Promise.all([
    grokImagineEdit({
      prompt: panelPrompt("top", opts.name, opts.copy),
      imageDataUrl,
      timeoutMs: 50_000,
    }),
    grokImagineEdit({
      prompt: panelPrompt("bottom", opts.name, opts.copy),
      imageDataUrl,
      timeoutMs: 50_000,
    }),
  ]);
  return { top, bottom };
}
