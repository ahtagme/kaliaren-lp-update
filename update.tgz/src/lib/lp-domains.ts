export type LpDomainStatus = "active" | "pending" | "invalid";

export type LpDomain = {
  host: string;
  status: LpDomainStatus;
  detail: string;
};

export function normalizeLpHost(raw: string): string {
  let s = raw.trim().toLowerCase();
  s = s.replace(/^https?:\/\//, "");
  s = s.replace(/\/.*$/, "");
  s = s.replace(/:\d+$/, "");
  s = s.replace(/\.$/, "");
  if (!s || s.length > 80) return "";
  if (s === "localhost") return s;
  if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(s)) {
    return "";
  }
  return s;
}

export function parseLpDomains(raw: string): string[] {
  return parseLpDomainRecords(raw).map((d) => d.host);
}

export function parseLpDomainRecords(raw: string): LpDomain[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const seen = new Set<string>();
    const out: LpDomain[] = [];
    for (const item of parsed) {
      if (typeof item === "string") {
        const host = normalizeLpHost(item);
        if (!host || seen.has(host)) continue;
        seen.add(host);
        out.push({ host, status: "pending", detail: "Belum dicek" });
        continue;
      }
      if (!item || typeof item !== "object") continue;
      const rec = item as Partial<LpDomain>;
      const host = normalizeLpHost(String(rec.host ?? ""));
      if (!host || seen.has(host)) continue;
      seen.add(host);
      const status: LpDomainStatus =
        rec.status === "active" || rec.status === "invalid" ? rec.status : "pending";
      out.push({
        host,
        status,
        detail: String(rec.detail ?? "").slice(0, 200),
      });
    }
    return out;
  } catch {
    return [];
  }
}

export function lpAdUrl(host: string, slug: string): string {
  const h = normalizeLpHost(host);
  const path = `/p/${slug.replace(/^\/+/, "")}`;
  if (!h) return path;
  return `https://${h}${path}`;
}

export function mergeDomainChoices(primary: string, extra: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const host of [primary, ...extra]) {
    const h = normalizeLpHost(host);
    if (!h || seen.has(h)) continue;
    seen.add(h);
    out.push(h);
  }
  return out;
}

export const LP_A_RECORD_IP = "45.76.179.245";

function ip4ToInt(ip: string): number | null {
  const p = ip.split(".").map((n) => Number(n));
  if (p.length !== 4 || p.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return ((p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]) >>> 0;
}

const CF_RANGES: Array<[number, number]> = [
  [ip4ToInt("104.16.0.0")!, ip4ToInt("104.31.255.255")!],
  [ip4ToInt("172.64.0.0")!, ip4ToInt("172.71.255.255")!],
  [ip4ToInt("173.245.48.0")!, ip4ToInt("173.245.63.255")!],
  [ip4ToInt("103.21.244.0")!, ip4ToInt("103.21.247.255")!],
  [ip4ToInt("103.22.200.0")!, ip4ToInt("103.22.203.255")!],
  [ip4ToInt("103.31.4.0")!, ip4ToInt("103.31.7.255")!],
  [ip4ToInt("141.101.64.0")!, ip4ToInt("141.101.127.255")!],
  [ip4ToInt("108.162.192.0")!, ip4ToInt("108.162.255.255")!],
  [ip4ToInt("190.93.240.0")!, ip4ToInt("190.93.255.255")!],
  [ip4ToInt("188.114.96.0")!, ip4ToInt("188.114.111.255")!],
  [ip4ToInt("197.234.240.0")!, ip4ToInt("197.234.243.255")!],
  [ip4ToInt("198.41.128.0")!, ip4ToInt("198.41.255.255")!],
  [ip4ToInt("162.158.0.0")!, ip4ToInt("162.159.255.255")!],
];

export function isCloudflareIp(ip: string): boolean {
  const n = ip4ToInt(ip);
  if (n == null) return false;
  return CF_RANGES.some(([a, b]) => n >= a && n <= b);
}

