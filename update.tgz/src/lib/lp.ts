import type { OrderOnlineEmbed } from "@/lib/orderonline";
import { extremeCopyFor } from "@/lib/lp-copy";

export const ORDER_STATUSES = [
  "baru",
  "diproses",
  "dikirim",
  "selesai",
  "batal",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_LABEL: Record<OrderStatus, string> = {
  baru: "Baru",
  diproses: "Diproses",
  dikirim: "Dikirim",
  selesai: "Selesai",
  batal: "Batal",
};

export type LpSpec = { label: string; value: string };
export type LpProof = { caption: string; imageUrl: string };
export type LpTestimonial = {
  name: string;
  city: string;
  text: string;
  rating: number;
};

export type LandingPage = {
  id: number;
  productId: number;
  productName: string;
  sku: string;
  warehouseId: number;
  warehouseName: string;
  slug: string;
  isPublished: boolean;
  trustBanner: string;
  headline: string;
  subheadline: string;
  heroImageUrl: string;
  benefits: string[];
  gallery: string[];
  specs: LpSpec[];
  price: number;
  compareAtPrice: number;
  soldCount: number;
  ctaPrimary: string;
  ctaSecondary: string;
  proofs: LpProof[];
  testimonials: LpTestimonial[];
  formTitle: string;
  formNote: string;
  embedCode: string;
  embed: OrderOnlineEmbed | null;
  checkoutUrl?: string;
  metaPixelId: string;
  tiktokPixelId: string;
  publicDomain: string;
  stockQty: number;
  orderCount: number;
  updatedAt: string;
  productPhotoUrls?: string[];
  cdnBase?: string;
  posterUrl?: string;
  posterUrl2?: string;
};

export type LandingListItem = {
  id: number;
  productId: number;
  productName: string;
  sku: string;
  slug: string;
  isPublished: boolean;
  publicDomain: string;
  price: number;
  soldCount: number;
  orderCount: number;
  stockQty: number;
  updatedAt: string;
};

export type CodOrder = {
  id: number;
  landingPageId: number;
  productId: number;
  productName: string;
  slug: string;
  warehouseId: number;
  warehouseName: string;
  customerName: string;
  phone: string;
  address: string;
  city: string;
  qty: number;
  unitPrice: number;
  total: number;
  status: OrderStatus;
  note: string | null;
  createdAt: string;
};

export type ProductOption = {
  id: number;
  name: string;
  sku: string;
  category: string;
  costPrice: number;
};

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "produk";
}

export function suggestSellPrice(cost: number): number {
  if (!cost || cost <= 0) return 89000;
  const raw = cost * 3.6;
  return Math.max(Math.round(raw / 1000) * 1000, cost + 15000);
}

export function suggestComparePrice(sell: number): number {
  const raw = sell / 0.56;
  return Math.round(raw / 1000) * 1000;
}

export function discountPercent(price: number, compareAt: number): number {
  if (!compareAt || compareAt <= price) return 0;
  return Math.round((1 - price / compareAt) * 100);
}

export function defaultLandingCopy(name: string, costPrice: number) {
  const price = suggestSellPrice(costPrice);
  const compareAtPrice = suggestComparePrice(price);
  return {
    ...extremeCopyFor(name),
    price,
    compareAtPrice,
  };
}
