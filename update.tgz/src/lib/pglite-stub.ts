/** Client stub — PGLite never runs in the browser. */
export class PGlite {
  constructor() {
    throw new Error("PGLite is server-only");
  }
}
