/** Server-only xAI (Grok) helper. Never import from client code. */

const XAI_CHAT_URL = "https://api.x.ai/v1/chat/completions";
const XAI_EDIT_URL = "https://api.x.ai/v1/images/edits";

export function xaiKey(): string | undefined {
  const key = process.env.XAI_API_KEY?.trim();
  return key || undefined;
}

let settingsKey = "";

export function setXaiSettingsKey(key: string) {
  settingsKey = key.trim();
}

export function resolveXaiKey(): string | undefined {
  return xaiKey() || settingsKey || undefined;
}

type ChatContent =
  | string
  | Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string; detail?: "low" | "high" } }
    >;

export async function grokChat(opts: {
  prompt: string;
  imageDataUrl?: string;
  maxTokens?: number;
  timeoutMs?: number;
}): Promise<string | null> {
  const apiKey = resolveXaiKey();
  if (!apiKey) {
    console.error("[xai] no key");
    return null;
  }

  const content: ChatContent = opts.imageDataUrl
    ? [
        {
          type: "image_url",
          image_url: { url: opts.imageDataUrl, detail: "low" },
        },
        { type: "text", text: opts.prompt },
      ]
    : opts.prompt;

  const models = ["grok-4-fast-reasoning", "grok-4.5"];
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 60_000);
  try {
    let last = "";
    for (const model of models) {
      const res = await fetch(XAI_CHAT_URL, {
        method: "POST",
        signal: ctrl.signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          max_tokens: opts.maxTokens ?? 1800,
          temperature: 0.6,
          reasoning_effort: "low",
          response_format: { type: "json_object" },
          messages: [{ role: "user", content }],
        }),
      });
      if (!res.ok) {
        last = `${model} ${res.status} ${(await res.text().catch(() => "")).slice(0, 180)}`;
        console.error("[xai]", last);
        continue;
      }
      const body = (await res.json()) as {
        choices?: { message?: { content?: string }; finish_reason?: string }[];
      };
      const text = body.choices?.[0]?.message?.content?.trim() || "";
      if (!text) {
        last = `${model} empty ${body.choices?.[0]?.finish_reason ?? ""}`;
        console.error("[xai]", last);
        continue;
      }
      return text;
    }
    return null;
  } catch (err) {
    console.error("[xai]", err instanceof Error ? err.name : "fail");
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function grokImagineEdit(opts: {
  prompt: string;
  imageDataUrl: string;
  timeoutMs?: number;
}): Promise<{ mime: string; data: string } | null> {
  const apiKey = resolveXaiKey();
  if (!apiKey) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 90_000);
  try {
    const res = await fetch(XAI_EDIT_URL, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-imagine-image-2.0",
        prompt: opts.prompt,
        image: { url: opts.imageDataUrl, type: "image_url" },
        aspect_ratio: "9:16",
        resolution: "1k",
        response_format: "b64_json",
      }),
    });
    if (!res.ok) {
      console.error("[imagine]", res.status, (await res.text()).slice(0, 240));
      return null;
    }
    const body = (await res.json()) as {
      data?: { b64_json?: string; mime_type?: string }[];
    };
    const data = body.data?.[0]?.b64_json?.replace(/\s/g, "") ?? "";
    if (data.length < 80 || data.length > 500_000) return null;
    return { mime: body.data?.[0]?.mime_type || "image/jpeg", data };
  } catch (err) {
    console.error("[imagine]", err instanceof Error ? err.name : "fail");
    return null;
  } finally {
    clearTimeout(timer);
  }
}
