import type { ExtremeCopy } from "@/lib/lp-copy";
import { extremeCopyFor } from "@/lib/lp-copy";
import { grokChat } from "@/lib/xai";

function clip(s: string, n: number) {
  return s.replace(/\s+/g, " ").trim().slice(0, n);
}

function parseJson(raw: string): Record<string, unknown> | null {
  const trimmed = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try {
    const v = JSON.parse(trimmed) as unknown;
    return v && typeof v === "object" ? (v as Record<string, unknown>) : null;
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    try {
      return JSON.parse(trimmed.slice(start, end + 1)) as Record<string, unknown>;
    } catch {
      return null;
    }
  }
}

function pickStr(json: Record<string, unknown>, keys: string[], maxLen: number): string {
  for (const key of keys) {
    const v = json[key];
    if (typeof v === "string" && v.trim()) return clip(v, maxLen);
  }
  return "";
}

function strings(v: unknown, n: number, maxLen: number): string[] {
  let list: unknown[] = [];
  if (typeof v === "string") list = v.split(/\n|;/).map((s) => s.trim());
  else if (Array.isArray(v)) list = v;
  else return [];
  return list
    .map((x) => {
      if (typeof x === "string") return clip(x, maxLen);
      if (x && typeof x === "object") {
        const row = x as Record<string, unknown>;
        const s = row.text ?? row.value ?? row.label ?? row.title;
        return typeof s === "string" ? clip(s, maxLen) : "";
      }
      return "";
    })
    .filter(Boolean)
    .slice(0, n);
}

export async function grokExtremeCopy(opts: {
  name: string;
  sku?: string;
  mime: string;
  data: string;
}): Promise<ExtremeCopy | null> {
  const mime = opts.mime.startsWith("image/") ? opts.mime : "image/jpeg";
  const dataUrl = opts.data.startsWith("data:")
    ? opts.data
    : `data:${mime};base64,${opts.data}`;

  const prompt = `Kamu copywriter COD Indonesia. LIHAT FOTO produk ini.

Nama produk: ${opts.name}
${opts.sku ? `SKU: ${opts.sku}` : ""}

Tulis LP versi NEXT LEVEL. Gabung: overclaim, hard selling, hukum ikut-ikutan, hukum keterbatasan, anti PHP, anti retur, edukasi terselubung, testimoni brutal, no mercy closing. SIAP UNTUK ORANG LANGSUNG BELI TANPA MIKIR.

Aturan:
- Pendek. Jangan esai. Teks sedang, jelas di HP.
- Klaim harus cocok dengan yang TERLIHAT di foto (kemasan, teks, jenis produk). Jangan ngarang manfaat yang tidak ada.
- Bahasa Indonesia percakapan.

Balas JSON saja:
{
  "trustBanner": "maks 42 karakter",
  "headline": "maks 8 kata HURUF BESAR, masalah pembeli",
  "subheadline": "maks 8 kata HURUF BESAR, punch keras",
  "benefits": ["4 frase pendek manfaat dari foto"],
  "edu": ["4 kalimat pendek edukasi terselubung"],
  "testimonials": [
    {"name":"Rina S.","city":"Bandung","text":"1 kalimat brutal","rating":5},
    {"name":"Andi P.","city":"Jakarta","text":"1 kalimat brutal","rating":5},
    {"name":"Laila M.","city":"Surabaya","text":"1 kalimat brutal","rating":5}
  ],
  "ctaPrimary": "PESAN SEKARANG",
  "ctaSecondary": "CHECKOUT SEKARANG",
  "formNote": "1 kalimat closing no mercy"
}`;

  const raw = await grokChat({
    prompt,
    imageDataUrl: dataUrl,
    maxTokens: 1800,
    timeoutMs: 60_000,
  });
  if (!raw) return null;
  const json = parseJson(raw);
  if (!json) {
    console.error("[lp-ai] json fail", raw.slice(0, 180));
    return null;
  }

  const base = extremeCopyFor(opts.name);
  const headline = pickStr(json, ["headline", "title", "h1"], 72);
  const punch = pickStr(json, ["subheadline", "punch", "subhead", "sub"], 72);
  if (!headline && !punch) {
    console.error("[lp-ai] no headline", Object.keys(json).join(","));
    return null;
  }

  const benefits = strings(json.benefits ?? json.why, 4, 42);
  const edu = strings(json.edu ?? json.specs ?? json.edukasi, 4, 72);
  const testersRaw = Array.isArray(json.testimonials) ? json.testimonials : [];
  const testimonials = testersRaw
    .map((t) => {
      if (!t || typeof t !== "object") return null;
      const row = t as Record<string, unknown>;
      const name = typeof row.name === "string" ? clip(row.name, 24) : "";
      const city = typeof row.city === "string" ? clip(row.city, 20) : "";
      const text = typeof row.text === "string" ? clip(row.text, 90) : "";
      if (!name || !text) return null;
      return { name, city: city || "Indonesia", text, rating: 5 };
    })
    .filter((x): x is NonNullable<typeof x> => Boolean(x))
    .slice(0, 3);

  const banner = pickStr(json, ["trustBanner", "banner"], 48);

  return {
    trustBanner: banner || base.trustBanner,
    headline: (headline || base.headline).toUpperCase(),
    subheadline: (punch || base.subheadline).toUpperCase(),
    benefits: (benefits.length >= 2 ? benefits : base.benefits).slice(0, 4),
    specs: (edu.length >= 2 ? edu : base.specs.map((s) => s.value))
      .slice(0, 4)
      .map((value) => ({ label: "✓", value })),
    testimonials: testimonials.length === 3 ? testimonials : base.testimonials,
    ctaPrimary: (pickStr(json, ["ctaPrimary", "cta"], 28) || base.ctaPrimary).toUpperCase(),
    ctaSecondary: (pickStr(json, ["ctaSecondary"], 32) || base.ctaSecondary).toUpperCase(),
    formTitle: "Form Pemesanan",
    formNote: pickStr(json, ["formNote", "close"], 80) || base.formNote,
    proofs: [],
  };
}
