import { spawn } from "node:child_process";

type Packed = { mime: string; body: Buffer };

const cache = new Map<string, Packed>();

function runPipe(
  cmd: string,
  args: string[],
  input: Buffer,
  timeoutMs: number,
): Promise<Buffer | null> {
  return new Promise((resolve) => {
    const proc = spawn(cmd, args, { stdio: ["pipe", "pipe", "pipe"] });
    const chunks: Buffer[] = [];
    const timer = setTimeout(() => {
      proc.kill("SIGKILL");
      resolve(null);
    }, timeoutMs);
    proc.stdout.on("data", (c: Buffer) => chunks.push(c));
    proc.on("error", () => {
      clearTimeout(timer);
      resolve(null);
    });
    proc.on("close", (code) => {
      clearTimeout(timer);
      const body = Buffer.concat(chunks);
      resolve(code === 0 && body.length > 32 ? body : null);
    });
    proc.stdin.on("error", () => {});
    proc.stdin.end(input);
  });
}

async function toWebp(input: Buffer, width: number): Promise<Buffer | null> {
  const ffmpeg = await runPipe(
    "ffmpeg",
    [
      "-hide_banner",
      "-loglevel",
      "error",
      "-i",
      "pipe:0",
      "-vf",
      `scale='min(${width},iw)':-2`,
      "-frames:v",
      "1",
      "-c:v",
      "libwebp",
      "-quality",
      "62",
      "-compression_level",
      "5",
      "-f",
      "webp",
      "pipe:1",
    ],
    input,
    8000,
  );
  if (ffmpeg) return ffmpeg;
  return runPipe(
    "magick",
    ["-", "-resize", `${width}x>`, "-quality", "62", "webp:-"],
    input,
    8000,
  );
}

export async function compressGeneratedPhoto(
  data: string,
  mime: string,
): Promise<{ mime: string; data: string }> {
  const raw = Buffer.from(data.replace(/\s/g, ""), "base64");
  if (raw.length <= 40_000) return { mime: mime || "image/jpeg", data };
  const webp = await toWebp(raw, 720);
  if (webp && webp.length < raw.length) {
    return { mime: "image/webp", data: webp.toString("base64") };
  }
  return { mime: mime || "image/jpeg", data };
}

export async function packPhotoForLp(
  id: number | string,
  mime: string,
  base64: string,
): Promise<Packed> {
  const key = String(id);
  const hit = cache.get(key);
  if (hit) return hit;
  const raw = Buffer.from(base64, "base64");
  const type = mime || "image/jpeg";
  if (raw.length <= 24_000) {
    const small = { mime: type, body: raw };
    cache.set(key, small);
    return small;
  }
  const webp = await toWebp(raw, type.includes("webp") || key.includes("lp-") ? 720 : 640);
  const packed: Packed =
    webp && webp.length < raw.length
      ? { mime: "image/webp", body: webp }
      : { mime: type, body: raw };
  cache.set(key, packed);
  if (cache.size > 120) {
    const first = cache.keys().next().value;
    if (first) cache.delete(first);
  }
  return packed;
}
