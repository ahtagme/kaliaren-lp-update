import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import type { Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { assertActiveStaff } from "@/lib/staff-fn";
import {
  parseMoney,
  stockStatus,
  type CategorySummary,
  type DashboardData,
  type Movement,
  type MovementType,
  type Product,
  type ProductPhoto,
  type StockRow,
  type Warehouse,
  productPhotoUrl,
} from "@/lib/inventory";

type WarehouseRow = {
  id: number;
  name: string;
  code: string;
  address: string | null;
  is_active: boolean;
};

type ProductRow = {
  id: number;
  sku: string;
  name: string;
  category: string;
  unit: string;
  cost_price: string | number;
  min_stock: number;
  notes: string | null;
  photo_id?: number | null;
};

type StockJoinRow = ProductRow & {
  warehouse_id: number;
  qty: number;
};

type MovementRow = {
  id: number;
  warehouse_id: number;
  warehouse_name: string;
  product_id: number;
  product_name: string;
  sku: string;
  type: MovementType;
  qty: number;
  unit_cost: string | number;
  related_warehouse_id: number | null;
  related_warehouse_name: string | null;
  reason: string | null;
  note: string | null;
  created_at: string | Date;
};

function mapWarehouse(r: WarehouseRow): Warehouse {
  return {
    id: r.id,
    name: r.name,
    code: r.code,
    address: r.address,
    isActive: Boolean(r.is_active),
  };
}

function mapProduct(r: ProductRow): Product {
  return {
    id: r.id,
    sku: r.sku,
    name: r.name,
    category: r.category,
    unit: r.unit,
    costPrice: parseMoney(r.cost_price),
    minStock: Number(r.min_stock) || 0,
    notes: r.notes,
    imageUrl: productPhotoUrl(r.photo_id),
  };
}

function mapStock(r: StockJoinRow): StockRow {
  const qty = Number(r.qty) || 0;
  const cost = parseMoney(r.cost_price);
  const min = Number(r.min_stock) || 0;
  return {
    ...mapProduct(r),
    warehouseId: r.warehouse_id,
    qty,
    value: qty * cost,
    status: stockStatus(qty, min),
  };
}

function mapMovement(r: MovementRow): Movement {
  const created =
    r.created_at instanceof Date
      ? r.created_at.toISOString()
      : new Date(r.created_at).toISOString();
  return {
    id: r.id,
    warehouseId: r.warehouse_id,
    warehouseName: r.warehouse_name,
    productId: r.product_id,
    productName: r.product_name,
    sku: r.sku,
    type: r.type,
    qty: Number(r.qty) || 0,
    unitCost: parseMoney(r.unit_cost),
    relatedWarehouseId: r.related_warehouse_id,
    relatedWarehouseName: r.related_warehouse_name,
    reason: r.reason,
    note: r.note,
    createdAt: created,
  };
}

const PRODUCT_COLS = `p.id, p.sku, p.name, p.category, p.unit, p.cost_price, p.min_stock, p.notes,
         (select ph.id from product_photos ph
           where ph.product_id = p.id
           order by ph.is_primary desc, ph.id
           limit 1) as photo_id`;

const PRODUCT_COLS_LITE = `p.id, p.sku, p.name, p.category, p.unit, p.cost_price, p.min_stock, p.notes,
         null::int as photo_id`;

const MOVEMENT_SELECT = `
  select m.id, m.warehouse_id, w.name as warehouse_name,
         m.product_id, p.name as product_name, p.sku,
         m.type, m.qty, m.unit_cost, m.related_warehouse_id,
         rw.name as related_warehouse_name,
         m.reason, m.note, m.created_at
  from stock_movements m
  join warehouses w on w.id = m.warehouse_id
  join products p on p.id = m.product_id
  left join warehouses rw on rw.id = m.related_warehouse_id
`;

async function fetchWarehouses(): Promise<Warehouse[]> {
  const sql = await getSql();
  const rows = await sql<WarehouseRow>`
    select id, name, code, address, is_active
    from warehouses
    where is_active = true
    order by id
  `;
  return rows.map(mapWarehouse);
}

export const listWarehouses = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(
  async ({ context }) => {
    await assertActiveStaff(context.userId);
    return fetchWarehouses();
  },
);

export const listStock = createServerFn({ method: "GET" }).middleware([authMiddleware])
  .validator(z.object({ warehouseId: z.number(), photos: z.boolean().optional() }))
  .handler(async ({ data, context }): Promise<StockRow[]> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const cols = data.photos === false ? PRODUCT_COLS_LITE : PRODUCT_COLS;
    const rows = await sql.query<StockJoinRow>(
      `select ${cols},
              ws.warehouse_id, ws.qty
       from warehouse_stock ws
       join products p on p.id = ws.product_id
       where ws.warehouse_id = $1
       order by p.name`,
      [data.warehouseId],
    );
    return rows.map(mapStock);
  });

export const getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware])
  .validator(z.object({ warehouseId: z.number() }))
  .handler(async ({ data, context }): Promise<DashboardData> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();

    const [summaryRows, byCategory, lowRows, highRows, recentRows] = await Promise.all([
      sql.query<{
        sku_count: number;
        total_qty: number;
        total_value: string | number;
        low_count: number;
        zero_count: number;
      }>(
        `select
           count(*)::int as sku_count,
           coalesce(sum(ws.qty), 0)::int as total_qty,
           coalesce(sum(ws.qty * p.cost_price), 0) as total_value,
           count(*) filter (where ws.qty > 0 and ws.qty <= p.min_stock)::int as low_count,
           count(*) filter (where ws.qty = 0)::int as zero_count
         from warehouse_stock ws
         join products p on p.id = ws.product_id
         where ws.warehouse_id = $1`,
        [data.warehouseId],
      ),
      sql.query<{
        category: string;
        sku_count: number;
        qty: number;
        value: string | number;
      }>(
        `select p.category,
                count(*)::int as sku_count,
                coalesce(sum(ws.qty), 0)::int as qty,
                coalesce(sum(ws.qty * p.cost_price), 0) as value
         from warehouse_stock ws
         join products p on p.id = ws.product_id
         where ws.warehouse_id = $1
         group by p.category
         order by coalesce(sum(ws.qty * p.cost_price), 0) desc`,
        [data.warehouseId],
      ),
      sql.query<StockJoinRow>(
        `select ${PRODUCT_COLS_LITE},
                ws.warehouse_id, ws.qty
         from warehouse_stock ws
         join products p on p.id = ws.product_id
         where ws.warehouse_id = $1
           and ws.qty > 0
           and ws.qty <= p.min_stock
         order by ws.qty asc, p.name
         limit 12`,
        [data.warehouseId],
      ),
      sql.query<StockJoinRow>(
        `select ${PRODUCT_COLS_LITE},
                ws.warehouse_id, ws.qty
         from warehouse_stock ws
         join products p on p.id = ws.product_id
         where ws.warehouse_id = $1
           and ws.qty >= 50
         order by ws.qty desc, p.name
         limit 12`,
        [data.warehouseId],
      ),
      sql.query<MovementRow>(
        `${MOVEMENT_SELECT}
         where m.warehouse_id = $1
         order by m.created_at desc
         limit 10`,
        [data.warehouseId],
      ),
    ]);

    const s = summaryRows[0];
    const byCat: CategorySummary[] = byCategory.map((r) => ({
      category: r.category,
      skuCount: Number(r.sku_count) || 0,
      qty: Number(r.qty) || 0,
      value: parseMoney(r.value),
    }));

    return {
      warehouses: [],
      summary: {
        skuCount: Number(s?.sku_count) || 0,
        totalQty: Number(s?.total_qty) || 0,
        totalValue: parseMoney(s?.total_value),
        lowCount: Number(s?.low_count) || 0,
        zeroCount: Number(s?.zero_count) || 0,
      },
      byCategory: byCat,
      lowStock: lowRows.map(mapStock),
      highStock: highRows.map(mapStock),
      recent: recentRows.map(mapMovement),
      trend: [],
    };
  });

async function fetchProductPhotos(sql: Sql, productId: number): Promise<ProductPhoto[]> {
  const rows = await sql.query<{ id: number; is_primary: boolean }>(
    `select id, is_primary from product_photos
     where product_id = $1
     order by is_primary desc, id`,
    [productId],
  );
  return rows.map((r) => ({
    id: r.id,
    url: productPhotoUrl(r.id),
    isPrimary: Boolean(r.is_primary),
  }));
}

const DATA_URL_RE =
  /^data:(image\/jpeg|image\/png|image\/webp);base64,([A-Za-z0-9+/=\s]+)$/i;

function parseImageDataUrl(dataUrl: string): { mime: string; data: string } {
  const m = dataUrl.trim().match(DATA_URL_RE);
  if (!m) throw new Error("Format gambar tidak didukung. Pakai jpg, png, atau webp.");
  const data = m[2].replace(/\s/g, "");
  if (data.length < 80 || data.length > 280_000) {
    throw new Error("Ukuran gambar tidak valid");
  }
  return { mime: m[1].toLowerCase(), data };
}

export const getProductDetail = createServerFn({ method: "GET" }).middleware([authMiddleware])
  .validator(z.object({ productId: z.number() }))
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const products = await sql.query<ProductRow>(
      `select ${PRODUCT_COLS} from products p where p.id = $1`,
      [data.productId],
    );
    const product = products[0];
    if (!product) throw new Error("Produk tidak ditemukan");

    const stock = await sql.query<{
      warehouse_id: number;
      warehouse_name: string;
      qty: number;
    }>(
      `select w.id as warehouse_id, w.name as warehouse_name, coalesce(ws.qty, 0) as qty
       from warehouses w
       left join warehouse_stock ws
         on ws.warehouse_id = w.id and ws.product_id = $1
       where w.is_active = true
       order by w.id`,
      [data.productId],
    );

    const movements = await sql.query<MovementRow>(
      `${MOVEMENT_SELECT}
       where m.product_id = $1
       order by m.created_at desc
       limit 40`,
      [data.productId],
    );

    const photos = await fetchProductPhotos(sql, data.productId);
    const cost = parseMoney(product.cost_price);
    return {
      product: mapProduct(product),
      photos,
      stock: stock.map((r) => ({
        warehouseId: r.warehouse_id,
        warehouseName: r.warehouse_name,
        qty: Number(r.qty) || 0,
        value: (Number(r.qty) || 0) * cost,
      })),
      movements: movements.map(mapMovement),
    };
  });

export const listMovements = createServerFn({ method: "GET" }).middleware([authMiddleware])
  .validator(
    z.object({
      warehouseId: z.number().optional(),
      type: z
        .enum(["in", "out", "opname", "transfer_in", "transfer_out"])
        .optional(),
      q: z.string().optional(),
      limit: z.number().optional(),
    }),
  )
  .handler(async ({ data, context }): Promise<Movement[]> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const limit = Math.min(data.limit ?? 80, 200);
    const clauses: string[] = [];
    const params: unknown[] = [];
    if (data.warehouseId) {
      params.push(data.warehouseId);
      clauses.push(`m.warehouse_id = $${params.length}`);
    }
    if (data.type) {
      params.push(data.type);
      clauses.push(`m.type = $${params.length}`);
    }
    if (data.q && data.q.trim()) {
      params.push(`%${data.q.trim().toLowerCase()}%`);
      clauses.push(
        `(lower(p.name) like $${params.length} or lower(p.sku) like $${params.length})`,
      );
    }
    params.push(limit);
    const where = clauses.length ? `where ${clauses.join(" and ")}` : "";
    const rows = await sql.query<MovementRow>(
      `${MOVEMENT_SELECT}
       ${where}
       order by m.created_at desc
       limit $${params.length}`,
      params,
    );
    return rows.map(mapMovement);
  });

const movementInput = z.object({
  warehouseId: z.number().int().positive(),
  productId: z.number().int().positive(),
  qty: z.number().int().positive(),
  unitCost: z.number().nonnegative().optional(),
  reason: z.string().max(80).optional(),
  note: z.string().max(500).optional(),
  updateCost: z.boolean().optional(),
});

async function ensureStockRow(
  warehouseId: number,
  productId: number,
): Promise<void> {
  const sql = await getSql();
  await sql.query(
    `insert into warehouse_stock (warehouse_id, product_id, qty)
     values ($1, $2, 0)
     on conflict (warehouse_id, product_id) do nothing`,
    [warehouseId, productId],
  );
}

export const recordIn = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(movementInput)
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    await ensureStockRow(data.warehouseId, data.productId);

    const products = await sql.query<ProductRow>(
      `select id, sku, name, category, unit, cost_price, min_stock, notes
       from products where id = $1`,
      [data.productId],
    );
    const product = products[0];
    if (!product) throw new Error("Produk tidak ditemukan");

    const unitCost =
      data.unitCost !== undefined ? data.unitCost : parseMoney(product.cost_price);

    await sql.query(
      `update warehouse_stock
       set qty = qty + $1
       where warehouse_id = $2 and product_id = $3`,
      [data.qty, data.warehouseId, data.productId],
    );

    if (data.updateCost && data.unitCost !== undefined) {
      await sql.query(`update products set cost_price = $1 where id = $2`, [
        data.unitCost,
        data.productId,
      ]);
    }

    const inserted = await sql.query<{ id: number }>(
      `insert into stock_movements
         (warehouse_id, product_id, type, qty, unit_cost, reason, note)
       values ($1, $2, 'in', $3, $4, $5, $6)
       returning id`,
      [
        data.warehouseId,
        data.productId,
        data.qty,
        unitCost,
        data.reason ?? "Pembelian / restok",
        data.note ?? null,
      ],
    );
    return { id: inserted[0]?.id, ok: true as const };
  });

export const recordOut = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(movementInput)
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    await ensureStockRow(data.warehouseId, data.productId);

    const products = await sql.query<ProductRow>(
      `select id, sku, name, category, unit, cost_price, min_stock, notes
       from products where id = $1`,
      [data.productId],
    );
    const product = products[0];
    if (!product) throw new Error("Produk tidak ditemukan");
    const unitCost = parseMoney(product.cost_price);

    const updated = await sql.query<{ qty: number }>(
      `update warehouse_stock
       set qty = qty - $1
       where warehouse_id = $2 and product_id = $3 and qty >= $1
       returning qty`,
      [data.qty, data.warehouseId, data.productId],
    );
    if (!updated[0]) {
      throw new Error("Stok tidak cukup untuk pengeluaran ini");
    }

    const inserted = await sql.query<{ id: number }>(
      `insert into stock_movements
         (warehouse_id, product_id, type, qty, unit_cost, reason, note)
       values ($1, $2, 'out', $3, $4, $5, $6)
       returning id`,
      [
        data.warehouseId,
        data.productId,
        data.qty,
        unitCost,
        data.reason ?? "Penjualan",
        data.note ?? null,
      ],
    );
    return { id: inserted[0]?.id, remaining: updated[0].qty, ok: true as const };
  });

export const recordTransfer = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      fromWarehouseId: z.number().int().positive(),
      toWarehouseId: z.number().int().positive(),
      productId: z.number().int().positive(),
      qty: z.number().int().positive(),
      note: z.string().max(500).optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    if (data.fromWarehouseId === data.toWarehouseId) {
      throw new Error("Gudang asal dan tujuan harus berbeda");
    }
    const sql = await getSql();
    await ensureStockRow(data.fromWarehouseId, data.productId);
    await ensureStockRow(data.toWarehouseId, data.productId);

    const products = await sql.query<ProductRow>(
      `select id, sku, name, category, unit, cost_price, min_stock, notes
       from products where id = $1`,
      [data.productId],
    );
    const product = products[0];
    if (!product) throw new Error("Produk tidak ditemukan");
    const unitCost = parseMoney(product.cost_price);

    const deducted = await sql.query<{ qty: number }>(
      `update warehouse_stock
       set qty = qty - $1
       where warehouse_id = $2 and product_id = $3 and qty >= $1
       returning qty`,
      [data.qty, data.fromWarehouseId, data.productId],
    );
    if (!deducted[0]) {
      throw new Error("Stok di gudang asal tidak cukup");
    }

    try {
      await sql.query(
        `update warehouse_stock
         set qty = qty + $1
         where warehouse_id = $2 and product_id = $3`,
        [data.qty, data.toWarehouseId, data.productId],
      );
      await sql.query(
        `insert into stock_movements
           (warehouse_id, product_id, type, qty, unit_cost, related_warehouse_id, reason, note)
         values
           ($1, $3, 'transfer_out', $4, $5, $2, 'Pindah gudang', $6),
           ($2, $3, 'transfer_in',  $4, $5, $1, 'Pindah gudang', $6)`,
        [
          data.fromWarehouseId,
          data.toWarehouseId,
          data.productId,
          data.qty,
          unitCost,
          data.note ?? null,
        ],
      );
    } catch (err) {
      await sql.query(
        `update warehouse_stock set qty = qty + $1
         where warehouse_id = $2 and product_id = $3`,
        [data.qty, data.fromWarehouseId, data.productId],
      );
      throw err;
    }

    return { ok: true as const };
  });

export const recordOpname = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      warehouseId: z.number().int().positive(),
      items: z
        .array(
          z.object({
            productId: z.number().int().positive(),
            physicalQty: z.number().int().nonnegative(),
          }),
        )
        .min(1),
      note: z.string().max(500).optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    let adjusted = 0;

    for (const item of data.items) {
      await ensureStockRow(data.warehouseId, item.productId);
      const current = await sql.query<{ qty: number; cost_price: string | number }>(
        `select ws.qty, p.cost_price
         from warehouse_stock ws
         join products p on p.id = ws.product_id
         where ws.warehouse_id = $1 and ws.product_id = $2`,
        [data.warehouseId, item.productId],
      );
      const row = current[0];
      if (!row) continue;
      const oldQty = Number(row.qty) || 0;
      if (oldQty === item.physicalQty) continue;

      const delta = item.physicalQty - oldQty;
      await sql.query(
        `update warehouse_stock set qty = $1
         where warehouse_id = $2 and product_id = $3`,
        [item.physicalQty, data.warehouseId, item.productId],
      );

      const sign = delta > 0 ? "Naik" : "Turun";
      await sql.query(
        `insert into stock_movements
           (warehouse_id, product_id, type, qty, unit_cost, reason, note)
         values ($1, $2, 'opname', $3, $4, $5, $6)`,
        [
          data.warehouseId,
          item.productId,
          Math.abs(delta),
          parseMoney(row.cost_price),
          `Penyesuaian ${sign} ${Math.abs(delta)}`,
          data.note?.trim()
            ? `${data.note.trim()} · sistem ${oldQty} → fisik ${item.physicalQty}`
            : `Sistem ${oldQty} → fisik ${item.physicalQty}`,
        ],
      );
      adjusted += 1;
    }

    return { ok: true as const, adjusted };
  });

export const createProduct = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      name: z.string().min(1).max(250),
      sku: z.string().min(1).max(40),
      category: z.string().min(1).max(60),
      unit: z.string().min(1).max(20),
      costPrice: z.number().nonnegative(),
      minStock: z.number().int().nonnegative(),
      notes: z.string().max(500).optional(),
      warehouseId: z.number().int().positive().optional(),
      initialQty: z.number().int().nonnegative().optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const existing = await sql.query<{ id: number }>(
      `select id from products where lower(sku) = lower($1)`,
      [data.sku],
    );
    if (existing[0]) throw new Error("SKU sudah dipakai");

    const inserted = await sql.query<{ id: number }>(
      `insert into products (sku, name, category, unit, cost_price, min_stock, notes)
       values ($1, $2, $3, $4, $5, $6, $7)
       returning id`,
      [
        data.sku.trim(),
        data.name.trim(),
        data.category,
        data.unit || "pcs",
        data.costPrice,
        data.minStock,
        data.notes ?? null,
      ],
    );
    const id = inserted[0]?.id;
    if (!id) throw new Error("Gagal menambah produk");

    const warehouses = data.warehouseId
      ? [{ id: data.warehouseId }]
      : await sql<{ id: number }>`select id from warehouses where is_active = true`;
    for (const w of warehouses) {
      await sql.query(
        `insert into warehouse_stock (warehouse_id, product_id, qty)
         values ($1, $2, 0)
         on conflict do nothing`,
        [w.id, id],
      );
    }

    if (data.warehouseId && data.initialQty && data.initialQty > 0) {
      await sql.query(
        `update warehouse_stock set qty = $1 where warehouse_id = $2 and product_id = $3`,
        [data.initialQty, data.warehouseId, id],
      );
      await sql.query(
        `insert into stock_movements
           (warehouse_id, product_id, type, qty, unit_cost, reason, note)
         values ($1, $2, 'in', $3, $4, 'Stok awal', 'Stok awal produk baru')`,
        [data.warehouseId, id, data.initialQty, data.costPrice],
      );
    }

    return { id, ok: true as const };
  });

export const updateProduct = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      id: z.number().int().positive(),
      name: z.string().min(1).max(250),
      sku: z.string().min(1).max(40),
      category: z.string().min(1).max(60),
      unit: z.string().min(1).max(20),
      costPrice: z.number().nonnegative(),
      minStock: z.number().int().nonnegative(),
      notes: z.string().max(500).optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const clash = await sql.query<{ id: number }>(
      `select id from products where lower(sku) = lower($1) and id <> $2`,
      [data.sku, data.id],
    );
    if (clash[0]) throw new Error("SKU sudah dipakai produk lain");

    const updated = await sql.query<{ id: number }>(
      `update products
       set sku = $1, name = $2, category = $3, unit = $4,
           cost_price = $5, min_stock = $6, notes = $7
       where id = $8
       returning id`,
      [
        data.sku.trim(),
        data.name.trim(),
        data.category,
        data.unit,
        data.costPrice,
        data.minStock,
        data.notes ?? null,
        data.id,
      ],
    );
    if (!updated[0]) throw new Error("Produk tidak ditemukan");
    return { ok: true as const };
  });

export const uploadProductPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      productId: z.number().int().positive(),
      dataUrl: z.string().min(80).max(280_000),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const parsed = parseImageDataUrl(data.dataUrl);
    const sql = await getSql();
    const exists = await sql.query<{ id: number }>(
      `select id from products where id = $1`,
      [data.productId],
    );
    if (!exists[0]) throw new Error("Produk tidak ditemukan");

    const countRows = await sql.query<{ n: number }>(
      `select count(*)::int as n from product_photos where product_id = $1`,
      [data.productId],
    );
    const count = Number(countRows[0]?.n) || 0;
    if (count >= 6) throw new Error("Maksimal 6 foto per produk");

    const inserted = await sql.query<{ id: number }>(
      `insert into product_photos (product_id, is_primary, mime, data)
       values ($1, $2, $3, $4)
       returning id`,
      [data.productId, count === 0, parsed.mime, parsed.data],
    );
    const id = inserted[0]?.id;
    if (!id) throw new Error("Gagal menyimpan foto");
    return { id, url: productPhotoUrl(id), photos: await fetchProductPhotos(sql, data.productId) };
  });

export const setPrimaryProductPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      productId: z.number().int().positive(),
      photoId: z.number().int().positive(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const owned = await sql.query<{ id: number }>(
      `select id from product_photos where id = $1 and product_id = $2`,
      [data.photoId, data.productId],
    );
    if (!owned[0]) throw new Error("Foto tidak ditemukan");
    await sql.query(
      `update product_photos set is_primary = (id = $1) where product_id = $2`,
      [data.photoId, data.productId],
    );
    return { photos: await fetchProductPhotos(sql, data.productId) };
  });

export const deleteProductPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      productId: z.number().int().positive(),
      photoId: z.number().int().positive(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const row = await sql.query<{ id: number; is_primary: boolean }>(
      `delete from product_photos
       where id = $1 and product_id = $2
       returning id, is_primary`,
      [data.photoId, data.productId],
    );
    if (!row[0]) throw new Error("Foto tidak ditemukan");
    if (row[0].is_primary) {
      await sql.query(
        `update product_photos set is_primary = true
         where id = (
           select id from product_photos where product_id = $1 order by id limit 1
         )`,
        [data.productId],
      );
    }
    return { photos: await fetchProductPhotos(sql, data.productId) };
  });

export const createWarehouse = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      name: z.string().min(1).max(80),
      code: z.string().min(1).max(12),
      address: z.string().max(160).optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const clash = await sql.query<{ id: number }>(
      `select id from warehouses where lower(code) = lower($1)`,
      [data.code],
    );
    if (clash[0]) throw new Error("Kode gudang sudah dipakai");

    const inserted = await sql.query<{ id: number }>(
      `insert into warehouses (name, code, address)
       values ($1, $2, $3)
       returning id`,
      [data.name.trim(), data.code.trim().toUpperCase(), data.address ?? null],
    );
    const id = inserted[0]?.id;
    if (!id) throw new Error("Gagal menambah gudang");

    await sql.query(
      `insert into warehouse_stock (warehouse_id, product_id, qty)
       select $1, p.id, 0 from products p
       on conflict do nothing`,
      [id],
    );
    return { id, ok: true as const };
  });

export const updateWarehouse = createServerFn({ method: "POST" }).middleware([authMiddleware])
  .validator(
    z.object({
      id: z.number().int().positive(),
      name: z.string().min(1).max(80),
      code: z.string().min(1).max(12),
      address: z.string().max(160).optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const clash = await sql.query<{ id: number }>(
      `select id from warehouses where lower(code) = lower($1) and id <> $2`,
      [data.code, data.id],
    );
    if (clash[0]) throw new Error("Kode gudang sudah dipakai");
    const updated = await sql.query<{ id: number }>(
      `update warehouses set name = $1, code = $2, address = $3 where id = $4 returning id`,
      [data.name.trim(), data.code.trim().toUpperCase(), data.address ?? null, data.id],
    );
    if (!updated[0]) throw new Error("Gudang tidak ditemukan");
    return { ok: true as const };
  });
