import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { assertActiveStaff } from "@/lib/staff-fn";
import { parseMoney } from "@/lib/inventory";
import { productPhotoUrl } from "@/lib/inventory";
import {
  defaultLandingCopy,
  slugify,
  type CodOrder,
  type LandingListItem,
  type LandingPage,
  type LpProof,
  type LpSpec,
  type LpTestimonial,
  type OrderStatus,
  type ProductOption,
} from "@/lib/lp";
import { parseOrderOnlineEmbed, parseCheckoutUrl } from "@/lib/orderonline";
import { grokExtremeCopy } from "@/lib/lp-ai";
import { grokLongLpPosters } from "@/lib/lp-imagine";
import { parseMetaPixelId, parseTiktokPixelId } from "@/lib/lp-pixels";
import { resolveCdnBase } from "@/lib/settings-fn";
import { normalizeLpHost } from "@/lib/lp-domains";
import { decryptSecret } from "@/lib/secret";
import { resolveXaiKey, setXaiSettingsKey } from "@/lib/xai";

type LandingRow = {
  id: number;
  product_id: number;
  product_name: string;
  sku: string;
  warehouse_id: number;
  warehouse_name: string;
  slug: string;
  is_published: boolean;
  trust_banner: string;
  headline: string;
  subheadline: string;
  hero_image_url: string;
  benefits: unknown;
  gallery: unknown;
  specs: unknown;
  price: number;
  compare_at_price: number;
  sold_count: number;
  cta_primary: string;
  cta_secondary: string;
  proofs: unknown;
  testimonials: unknown;
  form_title: string;
  form_note: string;
  embed_code: string;
  checkout_url?: string;
  meta_pixel_id: string;
  tiktok_pixel_id: string;
  public_domain: string;
  stock_qty: number | string | null;
  order_count: number | string | null;
  updated_at: string | Date;
  has_poster?: boolean;
  has_poster2?: boolean;
};

type OrderRow = {
  id: number;
  landing_page_id: number;
  product_id: number;
  product_name: string;
  slug: string;
  warehouse_id: number;
  warehouse_name: string;
  customer_name: string;
  phone: string;
  address: string;
  city: string;
  qty: number;
  unit_price: number;
  total: number;
  status: OrderStatus;
  note: string | null;
  created_at: string | Date;
};

function parseJson<T>(value: unknown, fallback: T): T {
  if (value == null) return fallback;
  if (typeof value === "string") {
    try {
      return JSON.parse(value) as T;
    } catch {
      return fallback;
    }
  }
  return value as T;
}

function iso(value: string | Date): string {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function flag(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1 || value === "1";
}

function readCheckout(raw: string): {
  embed: ReturnType<typeof parseOrderOnlineEmbed>;
  checkoutUrl: string;
} {
  const embed = parseOrderOnlineEmbed(raw);
  if (embed) return { embed, checkoutUrl: "" };
  const s = raw.trim();
  if (!s || /orderonline-embed-form|ooe\s*\(/i.test(s)) {
    return { embed: null, checkoutUrl: "" };
  }
  const m = s.match(/https?:\/\/[^\s"'<>]+/i);
  if (!m) return { embed: null, checkoutUrl: "" };
  try {
    const href = m[0].startsWith("http") ? m[0] : `https://${m[0]}`;
    const u = new URL(href);
    if (u.protocol !== "http:" && u.protocol !== "https:") {
      return { embed: null, checkoutUrl: "" };
    }
    return { embed: null, checkoutUrl: u.toString() };
  } catch {
    return { embed: null, checkoutUrl: "" };
  }
}

function mapLanding(r: LandingRow): LandingPage {
  return {
    id: r.id,
    productId: r.product_id,
    productName: r.product_name,
    sku: r.sku,
    warehouseId: r.warehouse_id,
    warehouseName: r.warehouse_name,
    slug: r.slug,
    isPublished: flag(r.is_published),
    trustBanner: r.trust_banner,
    headline: r.headline,
    subheadline: r.subheadline,
    heroImageUrl: r.hero_image_url ?? "",
    benefits: parseJson<string[]>(r.benefits, []),
    gallery: parseJson<string[]>(r.gallery, []),
    specs: parseJson<LpSpec[]>(r.specs, []),
    price: Number(r.price) || 0,
    compareAtPrice: Number(r.compare_at_price) || 0,
    soldCount: Number(r.sold_count) || 0,
    ctaPrimary: r.cta_primary,
    ctaSecondary: r.cta_secondary,
    proofs: parseJson<LpProof[]>(r.proofs, []),
    testimonials: parseJson<LpTestimonial[]>(r.testimonials, []),
    formTitle: r.form_title,
    formNote: r.form_note,
    embedCode: r.embed_code ?? "",
    embed: parseOrderOnlineEmbed(r.embed_code ?? ""),
    checkoutUrl: (r.checkout_url ?? "").trim() || readCheckout(r.embed_code ?? "").checkoutUrl,
    metaPixelId: r.meta_pixel_id ?? "",
    tiktokPixelId: r.tiktok_pixel_id ?? "",
    publicDomain: r.public_domain ?? "",
    stockQty: Number(r.stock_qty) || 0,
    orderCount: Number(r.order_count) || 0,
    updatedAt: iso(r.updated_at),
    posterUrl: flag(r.has_poster) ? `/api/lp-poster/${r.id}` : "",
    posterUrl2: flag(r.has_poster2) ? `/api/lp-poster/${r.id}?p=2` : "",
  };
}

function mapOrder(r: OrderRow): CodOrder {
  return {
    id: r.id,
    landingPageId: r.landing_page_id,
    productId: r.product_id,
    productName: r.product_name,
    slug: r.slug,
    warehouseId: r.warehouse_id,
    warehouseName: r.warehouse_name,
    customerName: r.customer_name,
    phone: r.phone,
    address: r.address,
    city: r.city,
    qty: Number(r.qty) || 0,
    unitPrice: Number(r.unit_price) || 0,
    total: Number(r.total) || 0,
    status: r.status,
    note: r.note,
    createdAt: iso(r.created_at),
  };
}

const LANDING_SELECT = `
  select lp.id, lp.product_id, p.name as product_name, p.sku,
         lp.warehouse_id, w.name as warehouse_name,
         lp.slug, lp.is_published, lp.trust_banner, lp.headline, lp.subheadline,
         lp.hero_image_url, lp.benefits, lp.gallery, lp.specs,
         lp.price, lp.compare_at_price, lp.sold_count,
         lp.cta_primary, lp.cta_secondary, lp.proofs, lp.testimonials,
         lp.form_title, lp.form_note, lp.embed_code, lp.checkout_url,
         lp.meta_pixel_id, lp.tiktok_pixel_id, lp.public_domain, lp.updated_at,
         coalesce(ws.qty, 0) as stock_qty,
         (select count(*)::int from lp_orders o where o.landing_page_id = lp.id) as order_count,
         (lp.poster_data is not null) as has_poster,
         (lp.poster2_data is not null) as has_poster2
  from landing_pages lp
  join products p on p.id = lp.product_id
  join warehouses w on w.id = lp.warehouse_id
  left join warehouse_stock ws
    on ws.product_id = lp.product_id and ws.warehouse_id = lp.warehouse_id
`;

async function uniqueSlug(base: string, exceptId?: number): Promise<string> {
  const sql = await getSql();
  let slug = slugify(base);
  for (let i = 0; i < 20; i += 1) {
    const candidate = i === 0 ? slug : `${slug}-${i + 1}`;
    const rows = await sql.query<{ id: number }>(
      exceptId
        ? `select id from landing_pages where slug = $1 and id <> $2`
        : `select id from landing_pages where slug = $1`,
      exceptId ? [candidate, exceptId] : [candidate],
    );
    if (!rows[0]) return candidate;
  }
  return `${slug}-${Date.now()}`;
}

const landingFields = {
  warehouseId: z.number().int().positive(),
  slug: z.string().min(2).max(80),
  isPublished: z.boolean(),
  trustBanner: z.string().min(1).max(200),
  headline: z.string().min(4).max(160),
  subheadline: z.string().max(500),
  heroImageUrl: z.string().max(500),
  benefits: z.array(z.string().min(1).max(160)).max(12),
  gallery: z.array(z.string().min(1).max(500)).max(12),
  specs: z
    .array(z.object({ label: z.string().min(1).max(40), value: z.string().min(1).max(80) }))
    .max(12),
  price: z.number().int().nonnegative(),
  compareAtPrice: z.number().int().nonnegative(),
  soldCount: z.number().int().nonnegative(),
  ctaPrimary: z.string().min(1).max(80),
  ctaSecondary: z.string().min(1).max(80),
  proofs: z
    .array(
      z.object({
        caption: z.string().min(1).max(120),
        imageUrl: z.string().min(1).max(500),
      }),
    )
    .max(12),
  testimonials: z
    .array(
      z.object({
        name: z.string().min(1).max(60),
        city: z.string().min(1).max(60),
        text: z.string().min(1).max(400),
        rating: z.number().int().min(1).max(5),
      }),
    )
    .max(12),
  formTitle: z.string().min(1).max(80),
  formNote: z.string().max(240),
  embedCode: z.string().max(30000),
  checkoutUrl: z.string().max(500).optional(),
  metaPixelId: z.string().max(4000),
  tiktokPixelId: z.string().max(4000),
  publicDomain: z.string().max(80),
};

export const getPublicLanding = createServerFn({ method: "GET" })
  .validator(z.object({ slug: z.string().min(1).max(80) }))
  .handler(async ({ data }): Promise<LandingPage> => {
    const sql = await getSql();
    const rows = await sql.query<LandingRow>(
      `${LANDING_SELECT} where lp.slug = $1 and lp.is_published = true`,
      [data.slug],
    );
    if (!rows[0]) throw new Error("Landing page tidak ditemukan");
    const page = mapLanding(rows[0]);
    if (page.posterUrl) {
      const cdnBase = await resolveCdnBase();
      return { ...page, productPhotoUrls: [], cdnBase };
    }
    const photos = await sql.query<{ id: number }>(
      `select id from product_photos where product_id = $1 order by is_primary desc, id`,
      [page.productId],
    );
    const urls = photos.map((p) => productPhotoUrl(p.id));
    const cdnBase = await resolveCdnBase();
    return {
      ...page,
      productPhotoUrls: urls,
      heroImageUrl: page.heroImageUrl || urls[0] || "",
      gallery: page.gallery.length ? page.gallery : urls.slice(1),
      cdnBase,
    };
  });

export const submitCodOrder = createServerFn({ method: "POST" })
  .validator(
    z.object({
      slug: z.string().min(1).max(80),
      customerName: z.string().min(2).max(80),
      phone: z.string().min(8).max(20),
      address: z.string().min(8).max(400),
      city: z.string().min(2).max(80),
      qty: z.number().int().positive().max(50),
      note: z.string().max(240).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const phone = data.phone.replace(/[^\d+]/g, "");
    if (phone.replace(/\D/g, "").length < 9) {
      throw new Error("Nomor HP / WhatsApp tidak valid");
    }
    const sql = await getSql();
    const pages = await sql.query<LandingRow>(
      `${LANDING_SELECT} where lp.slug = $1 and lp.is_published = true`,
      [data.slug],
    );
    const page = pages[0];
    if (!page) throw new Error("Landing page tidak ditemukan");

    const products = await sql.query<{ cost_price: string | number }>(
      `select cost_price from products where id = $1`,
      [page.product_id],
    );
    const unitCost = parseMoney(products[0]?.cost_price);

    await sql.query(
      `insert into warehouse_stock (warehouse_id, product_id, qty)
       values ($1, $2, 0)
       on conflict (warehouse_id, product_id) do nothing`,
      [page.warehouse_id, page.product_id],
    );

    const updated = await sql.query<{ qty: number }>(
      `update warehouse_stock
       set qty = qty - $1
       where warehouse_id = $2 and product_id = $3 and qty >= $1
       returning qty`,
      [data.qty, page.warehouse_id, page.product_id],
    );
    if (!updated[0]) {
      throw new Error("Stok habis. Pesanan tidak bisa diproses.");
    }

    const movements = await sql.query<{ id: number }>(
      `insert into stock_movements
         (warehouse_id, product_id, type, qty, unit_cost, reason, note)
       values ($1, $2, 'out', $3, $4, 'Penjualan', $5)
       returning id`,
      [
        page.warehouse_id,
        page.product_id,
        data.qty,
        unitCost,
        `COD LP ${page.slug} · ${data.customerName.trim()} · ${phone}`,
      ],
    );

    const total = page.price * data.qty;
    const orders = await sql.query<{ id: number }>(
      `insert into lp_orders
         (landing_page_id, product_id, warehouse_id, movement_id,
          customer_name, phone, address, city, qty, unit_price, total, note)
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       returning id`,
      [
        page.id,
        page.product_id,
        page.warehouse_id,
        movements[0]?.id ?? null,
        data.customerName.trim(),
        phone,
        data.address.trim(),
        data.city.trim(),
        data.qty,
        page.price,
        total,
        data.note?.trim() || null,
      ],
    );

    await sql.query(
      `update landing_pages set sold_count = sold_count + $1, updated_at = now() where id = $2`,
      [data.qty, page.id],
    );

    return {
      ok: true as const,
      orderId: orders[0]?.id,
      total,
      remaining: updated[0].qty,
    };
  });

export const listLandings = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<LandingListItem[]> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows = await sql.query<{
      id: number;
      product_id: number;
      product_name: string;
      sku: string;
      slug: string;
      is_published: boolean;
      public_domain: string | null;
      price: string | number;
      sold_count: number;
      order_count: number;
      stock_qty: number;
      updated_at: string | Date;
    }>(
      `select lp.id, lp.product_id, p.name as product_name, p.sku,
              lp.slug, lp.is_published, lp.public_domain, lp.price, lp.sold_count,
              lp.updated_at, coalesce(ws.qty, 0) as stock_qty,
              coalesce((select count(*)::int from lp_orders o where o.landing_page_id = lp.id), 0) as order_count
       from landing_pages lp
       join products p on p.id = lp.product_id
       left join warehouse_stock ws
         on ws.product_id = lp.product_id and ws.warehouse_id = lp.warehouse_id
       order by lp.updated_at desc`,
    );
    return rows.map((r) => ({
      id: r.id,
      productId: r.product_id,
      productName: r.product_name,
      sku: r.sku,
      slug: r.slug,
      isPublished: Boolean(r.is_published),
      publicDomain: r.public_domain ?? "",
      price: Number(r.price) || 0,
      soldCount: Number(r.sold_count) || 0,
      orderCount: Number(r.order_count) || 0,
      stockQty: Number(r.stock_qty) || 0,
      updatedAt: iso(r.updated_at),
    }));
  });

export const getLanding = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.number().int().positive() }))
  .handler(async ({ data, context }): Promise<LandingPage> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows = await sql.query<LandingRow>(`${LANDING_SELECT} where lp.id = $1`, [
      data.id,
    ]);
    if (!rows[0]) throw new Error("Landing page tidak ditemukan");
    const page = mapLanding(rows[0]);
    const photos = await sql.query<{ id: number }>(
      `select id from product_photos where product_id = $1 order by is_primary desc, id`,
      [page.productId],
    );
    return {
      ...page,
      productPhotoUrls: photos.map((p) => productPhotoUrl(p.id)),
    };
  });

export const listProductOptions = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProductOption[]> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows = await sql.query<{
      id: number;
      name: string;
      sku: string;
      category: string;
      cost_price: string | number;
    }>(
      `select id, name, sku, category, cost_price from products order by lower(name)`,
    );
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      sku: r.sku,
      category: r.category,
      costPrice: parseMoney(r.cost_price),
    }));
  });

export const getLandingByProduct = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ productId: z.number().int().positive() }))
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows = await sql.query<{ id: number; slug: string; is_published: boolean }>(
      `select id, slug, is_published from landing_pages
       where product_id = $1
       order by id
       limit 1`,
      [data.productId],
    );
    const row = rows[0];
    if (!row) return null;
    return { id: row.id, slug: row.slug, isPublished: Boolean(row.is_published) };
  });

export const createLanding = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      productId: z.number().int().positive(),
      warehouseId: z.number().int().positive(),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const products = await sql.query<{
      id: number;
      name: string;
      sku: string;
      cost_price: string | number;
    }>(`select id, name, sku, cost_price from products where id = $1`, [
      data.productId,
    ]);
    const product = products[0];
    if (!product) throw new Error("Produk tidak ditemukan");

    const photos = await sql.query<{
      id: number;
      is_primary: boolean;
      mime: string;
      data: string;
    }>(
      `select id, is_primary, mime, data from product_photos
       where product_id = $1
       order by is_primary desc, id`,
      [product.id],
    );
    if (!photos[0]) {
      throw new Error("Upload foto produk dulu. LP memakai foto itu otomatis.");
    }
    const urls = photos.map((p) => productPhotoUrl(p.id));
    const hero = urls[0] ?? "";
    const gallery = urls.slice(1);

    const cost = parseMoney(product.cost_price);
    const fallback = defaultLandingCopy(product.name, cost);
    const first = photos[0];
    if (!resolveXaiKey()) {
      const stored = await sql.query<{ value: string }>(
        `select value from app_settings where key = 'xai_key'`,
      );
      setXaiSettingsKey(decryptSecret(stored[0]?.value ?? ""));
    }
    let aiError = "";
    if (!resolveXaiKey()) {
      aiError = "Kunci AI belum diisi. Buka Pengaturan → Kunci AI.";
    }
    const ai = !aiError && first?.data
      ? await grokExtremeCopy({
          name: product.name,
          sku: product.sku,
          mime: first.mime,
          data: first.data,
        })
      : null;
    if (!aiError && !ai) {
      aiError = "Grok gagal baca foto. Cek log journalctl -u kaliaren | grep xai";
    }
    const copy = ai ? { ...fallback, ...ai } : fallback;
    const source = ai ? ("grok" as const) : ("template" as const);
    let posters: { top: { mime: string; data: string } | null; bottom: { mime: string; data: string } | null } =
      { top: null, bottom: null };
    if (resolveXaiKey() && first?.data) {
      try {
        posters = await grokLongLpPosters({
          name: product.name,
          mime: first.mime,
          data: first.data,
          copy,
        });
      } catch {
        posters = { top: null, bottom: null };
      }
      if (!posters.top && !posters.bottom && !aiError) {
        aiError = ai ? "Copy Grok siap. Poster panjang gagal." : aiError;
      }
    }

    const existing = await sql.query<{ id: number; slug: string }>(
      `select id, slug from landing_pages where product_id = $1 order by id limit 1`,
      [product.id],
    );

    const writePosters = async (id: number) => {
      if (!posters.top && !posters.bottom) return;
      await sql.query(
        `update landing_pages
         set poster_mime = coalesce($2, poster_mime),
             poster_data = coalesce($3, poster_data),
             poster2_mime = coalesce($4, poster2_mime),
             poster2_data = coalesce($5, poster2_data)
         where id = $1`,
        [
          id,
          posters.top?.mime ?? null,
          posters.top?.data ?? null,
          posters.bottom?.mime ?? null,
          posters.bottom?.data ?? null,
        ],
      );
    };
    const posterOk = Boolean(posters.top || posters.bottom);
    if (existing[0]) {
      await sql.query(
        `update landing_pages
         set warehouse_id = $2,
             hero_image_url = $3,
             gallery = $4::jsonb,
             trust_banner = $5,
             headline = $6,
             subheadline = $7,
             benefits = $8::jsonb,
             specs = $9::jsonb,
             proofs = $10::jsonb,
             testimonials = $11::jsonb,
             cta_primary = $12,
             cta_secondary = $13,
             form_title = $14,
             form_note = $15,
             price = $16,
             compare_at_price = $17,
             is_published = true,
             updated_at = now()
         where id = $1`,
        [
          existing[0].id,
          data.warehouseId,
          hero,
          JSON.stringify(gallery),
          copy.trustBanner,
          copy.headline,
          copy.subheadline,
          JSON.stringify(copy.benefits),
          JSON.stringify(copy.specs),
          JSON.stringify(copy.proofs),
          JSON.stringify(copy.testimonials),
          copy.ctaPrimary,
          copy.ctaSecondary,
          copy.formTitle,
          copy.formNote,
          copy.price,
          copy.compareAtPrice,
        ],
      );
      await writePosters(existing[0].id);
      return {
        id: existing[0].id,
        slug: existing[0].slug,
        reused: true as const,
        source,
        aiError,
        poster: posterOk,
      };
    }

    const slug = await uniqueSlug(product.name);

    const inserted = await sql.query<{ id: number }>(
      `insert into landing_pages (
         product_id, warehouse_id, slug, is_published,
         trust_banner, headline, subheadline, hero_image_url,
         benefits, gallery, specs, price, compare_at_price, sold_count,
         cta_primary, cta_secondary, proofs, testimonials, form_title, form_note
       ) values (
         $1, $2, $3, true,
         $4, $5, $6, $18,
         $7::jsonb, $8::jsonb, $9::jsonb, $10, $11, 0,
         $12, $13, $14::jsonb, $15::jsonb, $16, $17
       ) returning id`,
      [
        product.id,
        data.warehouseId,
        slug,
        copy.trustBanner,
        copy.headline,
        copy.subheadline,
        JSON.stringify(copy.benefits),
        JSON.stringify(gallery),
        JSON.stringify(copy.specs),
        copy.price,
        copy.compareAtPrice,
        copy.ctaPrimary,
        copy.ctaSecondary,
        JSON.stringify(copy.proofs),
        JSON.stringify(copy.testimonials),
        copy.formTitle,
        copy.formNote,
        hero,
      ],
    );
    const id = inserted[0]?.id;
    if (!id) throw new Error("Gagal membuat landing page");
    await writePosters(id);
    return { id, slug, reused: false as const, source, aiError, poster: posterOk };
  });

export const updateLanding = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.number().int().positive(), ...landingFields }))
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const embedCode = data.embedCode.trim();
    const embed = parseOrderOnlineEmbed(embedCode);
    const checkoutUrl =
      parseCheckoutUrl(data.checkoutUrl ?? "") ||
      (embed ? "" : parseCheckoutUrl(embedCode));
    const storedEmbed = embed ? embedCode : "";
    if (embedCode && !embed && !checkoutUrl) {
      throw new Error("Tempel embed OrderOnline, atau tautan https:// di kolom tautan PESAN.");
    }
    const metaPixelId = parseMetaPixelId(data.metaPixelId);
    if (data.metaPixelId.trim() && !metaPixelId) {
      throw new Error("Pixel Meta tidak valid. Isi ID angka, atau tempel kode pixel.");
    }
    const tiktokPixelId = parseTiktokPixelId(data.tiktokPixelId);
    if (data.tiktokPixelId.trim() && !tiktokPixelId) {
      throw new Error("Pixel TikTok tidak valid. Isi ID, atau tempel kode pixel.");
    }
    const sql = await getSql();
    const slug = await uniqueSlug(data.slug, data.id);
    const updated = await sql.query<{ id: number }>(
      `update landing_pages set
         warehouse_id = $2,
         slug = $3,
         is_published = $4,
         trust_banner = $5,
         headline = $6,
         subheadline = $7,
         hero_image_url = $8,
         benefits = $9::jsonb,
         gallery = $10::jsonb,
         specs = $11::jsonb,
         price = $12,
         compare_at_price = $13,
         sold_count = $14,
         cta_primary = $15,
         cta_secondary = $16,
         proofs = $17::jsonb,
         testimonials = $18::jsonb,
         form_title = $19,
         form_note = $20,
         embed_code = $21,
         checkout_url = $25,
         meta_pixel_id = $22,
         tiktok_pixel_id = $23,
         public_domain = $24,
         updated_at = now()
       where id = $1
       returning id`,
      [
        data.id,
        data.warehouseId,
        slug,
        data.isPublished,
        data.trustBanner,
        data.headline,
        data.subheadline,
        data.heroImageUrl,
        JSON.stringify(data.benefits),
        JSON.stringify(data.gallery),
        JSON.stringify(data.specs),
        data.price,
        data.compareAtPrice,
        data.soldCount,
        data.ctaPrimary,
        data.ctaSecondary,
        JSON.stringify(data.proofs),
        JSON.stringify(data.testimonials),
        data.formTitle,
        data.formNote,
        storedEmbed,
        metaPixelId,
        tiktokPixelId,
        normalizeLpHost(data.publicDomain),
        checkoutUrl,
      ],
    );
    if (!updated[0]) throw new Error("Landing page tidak ditemukan");
    return { ok: true as const, slug };
  });

export const listOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      status: z.enum(["semua", "baru", "diproses", "dikirim", "selesai", "batal"]),
    }),
  )
  .handler(async ({ data, context }): Promise<CodOrder[]> => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows =
      data.status === "semua"
        ? await sql.query<OrderRow>(
            `select o.id, o.landing_page_id, o.product_id, p.name as product_name, lp.slug,
                    o.warehouse_id, w.name as warehouse_name,
                    o.customer_name, o.phone, o.address, o.city, o.qty,
                    o.unit_price, o.total, o.status, o.note, o.created_at
             from lp_orders o
             join products p on p.id = o.product_id
             join landing_pages lp on lp.id = o.landing_page_id
             join warehouses w on w.id = o.warehouse_id
             order by o.created_at desc
             limit 200`,
          )
        : await sql.query<OrderRow>(
            `select o.id, o.landing_page_id, o.product_id, p.name as product_name, lp.slug,
                    o.warehouse_id, w.name as warehouse_name,
                    o.customer_name, o.phone, o.address, o.city, o.qty,
                    o.unit_price, o.total, o.status, o.note, o.created_at
             from lp_orders o
             join products p on p.id = o.product_id
             join landing_pages lp on lp.id = o.landing_page_id
             join warehouses w on w.id = o.warehouse_id
             where o.status = $1
             order by o.created_at desc
             limit 200`,
            [data.status],
          );
    return rows.map(mapOrder);
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      id: z.number().int().positive(),
      status: z.enum(["baru", "diproses", "dikirim", "selesai", "batal"]),
    }),
  )
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const sql = await getSql();
    const rows = await sql.query<{
      id: number;
      status: OrderStatus;
      qty: number;
      warehouse_id: number;
      product_id: number;
      landing_page_id: number;
      movement_id: number | null;
    }>(
      `select id, status, qty, warehouse_id, product_id, landing_page_id, movement_id
       from lp_orders where id = $1`,
      [data.id],
    );
    const order = rows[0];
    if (!order) throw new Error("Pesanan tidak ditemukan");
    if (order.status === data.status) return { ok: true as const };

    if (data.status === "batal" && order.status !== "batal") {
      await sql.query(
        `update warehouse_stock set qty = qty + $1
         where warehouse_id = $2 and product_id = $3`,
        [order.qty, order.warehouse_id, order.product_id],
      );
      await sql.query(
        `update landing_pages
         set sold_count = greatest(sold_count - $1, 0), updated_at = now()
         where id = $2`,
        [order.qty, order.landing_page_id],
      );
    }
    if (order.status === "batal" && data.status !== "batal") {
      const updated = await sql.query<{ qty: number }>(
        `update warehouse_stock set qty = qty - $1
         where warehouse_id = $2 and product_id = $3 and qty >= $1
         returning qty`,
        [order.qty, order.warehouse_id, order.product_id],
      );
      if (!updated[0]) throw new Error("Stok tidak cukup untuk mengaktifkan ulang pesanan");
      await sql.query(
        `update landing_pages set sold_count = sold_count + $1, updated_at = now() where id = $2`,
        [order.qty, order.landing_page_id],
      );
    }

    await sql.query(`update lp_orders set status = $2 where id = $1`, [
      data.id,
      data.status,
    ]);
    return { ok: true as const };
  });
