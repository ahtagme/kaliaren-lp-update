export const OO_EMBED_SRC = "https://cdn.orderonline.id/js/embed-v2-slim.min.js?v=8.0.2";
export const OO_JQUERY_SRC = "https://cdn.orderonline.id/js/vendor/jquery.min.js";

export type OrderOnlineEmbed = {
  username: string;
  productSlug: string;
  productId: string;
  storeId: string;
  formId: string;
  redirect: string;
  origin: string;
  mode: string;
  action: string;
  title: string;
};

function pick(html: string, re: RegExp): string {
  return html.match(re)?.[1]?.trim() ?? "";
}

export function parseOrderOnlineEmbed(html: string): OrderOnlineEmbed | null {
  const src = html.trim();
  if (!src) return null;
  const compact = src.replace(/\s+/g, " ");
  const username = pick(compact, /data-username=["']([^"']+)["']/i);
  const productSlug = pick(compact, /data-product-slug=["']([^"']+)["']/i);
  const productId =
    pick(compact, /data-product-id=["']([^"']+)["']/i) ||
    pick(
      compact,
      /ooe\(\s*['"]init['"]\s*,\s*['"][^'"]+['"]\s*,\s*['"]([^'"]+)['"]/i,
    );
  const formId =
    pick(compact, /\sid=["'](oo-embed-form-[^"']+)["']/i) ||
    pick(compact, /['"](oo-embed-form-[^'"]+)['"]/i);
  const storeId = pick(compact, /ooe\(\s*['"]init['"]\s*,\s*['"]([^'"]+)['"]/i);
  const redirect =
    pick(
      compact,
      /ooe\(\s*['"]setup['"]\s*,\s*['"]redirect['"]\s*,\s*['"]([^'"]+)['"]/i,
    ) || (username ? `https://${username}.orderonline.id` : "");
  const origin = pick(compact, /data-origin=["']([^"']+)["']/i) || "orderonline";
  const optsRaw = pick(compact, /ooe\(\s*['"]init['"][\s\S]*?(\{[\s\S]*?\})\s*\)\s*;?/);
  let mode = "page";
  let action = "Klik untuk pemesanan";
  let title = "Form Pemesanan";
  if (optsRaw) {
    try {
      const opts = JSON.parse(optsRaw) as {
        mode?: string;
        action?: string;
        title?: string;
      };
      if (opts.mode) mode = opts.mode;
      if (opts.action) action = opts.action;
      if (opts.title) title = opts.title;
    } catch {
      /* keep defaults */
    }
  }
  if (!username || !productId || !storeId || !formId) return null;
  return {
    username,
    productSlug,
    productId,
    storeId,
    formId,
    redirect,
    origin,
    mode,
    action,
    title,
  };
}

export function describeEmbed(embed: OrderOnlineEmbed): string {
  return `${embed.username} · ${embed.productSlug || embed.productId}`;
}

export function productCheckoutUrl(embed: OrderOnlineEmbed): string {
  if (!embed.username || !embed.productSlug) return "";
  return `https://${embed.username}.orderonline.id/${embed.productSlug}`;
}

/** Keep the official .ooef markup (form + loader). Drop scripts. */
export function extractOoefHtml(html: string, embed: OrderOnlineEmbed): string {
  const src = html.trim();
  const start = src.search(/<div[^>]*class=["'][^"']*ooef[^"']*["'][^>]*>/i);
  const scriptAt = src.search(/<script[\s>]/i);
  if (start >= 0) {
    const end = scriptAt > start ? scriptAt : src.length;
    const chunk = src.slice(start, end).replace(/<script[\s\S]*?<\/script>/gi, "").trim();
    if (chunk.includes("orderonline-embed-form")) return chunk;
  }
  return `<div class="ooef"><form class="orderonline-embed-form" data-username="${embed.username}" data-product-slug="${embed.productSlug}" data-product-id="${embed.productId}" id="${embed.formId}" data-origin="${embed.origin}"></form></div>`;
}

export function orderOnlineBootScript(embed: OrderOnlineEmbed): string {
  const q = JSON.stringify;
  return `(function(){window.__ooBoot=window.__ooBoot||{};if(window.__ooBoot[${q(embed.formId)}])return;window.__ooBoot[${q(embed.formId)}]=1;function n(){var o=window.ooe;if(o)return o;function e(){if(e.callMethod)e.callMethod.apply(e,arguments);else e.queue.push(arguments)}e.queue=[];e.loaded=true;e.version="8.0.2";e.push=e;window.ooe=e;window._ooe=e;return e}var o=n();o("setup","redirect",${q(embed.redirect)});o("init",${q(embed.storeId)},${q(embed.productId)},null,${q(embed.formId)},${JSON.stringify({ mode: embed.mode, action: embed.action, title: embed.title, triggerPixel: false, triggerGtm: false })});function add(src,id,cb){if(document.getElementById(id)){cb();return}var s=document.createElement("script");s.id=id;s.async=true;s.src=src;s.onload=cb;s.onerror=cb;document.head.appendChild(s)}add(${q(OO_JQUERY_SRC)},"oo-embed-jquery",function(){add(${q(OO_EMBED_SRC)},"oo-embed-js",function(){})})})();`;
}

export function parseCheckoutUrl(raw: string): string {
  const s = raw.trim();
  if (!s || /orderonline-embed-form|ooe\s*\(/i.test(s)) return "";
  const m =
    s.match(/https?:\/\/[^\s"'<>]+/i) ||
    s.match(/^(?:www\.)?[a-z0-9.-]+\.[a-z]{2,}(?:\/\S*)?$/i);
  if (!m) return "";
  const href = m[0].startsWith("http") ? m[0] : `https://${m[0]}`;
  try {
    const u = new URL(href);
    if (u.protocol !== "http:" && u.protocol !== "https:") return "";
    if (!u.hostname || u.hostname === "localhost") return "";
    return u.toString();
  } catch {
    return "";
  }
}

export function parseLpCheckout(raw: string): {
  embed: OrderOnlineEmbed | null;
  checkoutUrl: string;
} {
  const embed = parseOrderOnlineEmbed(raw);
  if (embed) return { embed, checkoutUrl: "" };
  return { embed: null, checkoutUrl: parseCheckoutUrl(raw) };
}
