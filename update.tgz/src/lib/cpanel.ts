export type CpanelConfig = {
  host: string;
  user: string;
  token: string;
};

export type CpanelResult<T> = {
  ok: boolean;
  data: T | null;
  error: string;
};

function apiOrigin(host: string): string {
  const h = host.replace(/^https?:\/\//, "").replace(/\/$/, "");
  if (h.includes(":")) return `https://${h}`;
  return `https://${h}:2083`;
}

export async function cpanelExecute<T = unknown>(
  cfg: CpanelConfig,
  module: string,
  func: string,
  params: Record<string, string> = {},
): Promise<CpanelResult<T>> {
  if (!cfg.host || !cfg.user || !cfg.token) {
    return { ok: false, data: null, error: "cPanel belum dikonfigurasi" };
  }
  const url = new URL(`${apiOrigin(cfg.host)}/execute/${module}/${func}`);
  const body = new URLSearchParams(params);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `cpanel ${cfg.user}:${cfg.token}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body,
      signal: ctrl.signal,
    });
    const json = (await res.json()) as {
      status?: number | boolean;
      errors?: string[] | null;
      messages?: string[] | null;
      data?: T;
    };
    const ok = json.status === 1 || json.status === true;
    if (!ok) {
      const err =
        (json.errors && json.errors.filter(Boolean).join(" ")) ||
        `cPanel ${module}::${func} gagal (${res.status})`;
      return { ok: false, data: json.data ?? null, error: err };
    }
    return { ok: true, data: json.data ?? null, error: "" };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Gagal hubungi cPanel";
    if (msg.includes("abort")) return { ok: false, data: null, error: "cPanel timeout" };
    return { ok: false, data: null, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

export type CpanelDomainList = {
  main_domain?: string;
  addon_domains?: string[] | Record<string, string>;
  sub_domains?: string[];
  parked_domains?: string[];
};

function namesOf(value: string[] | Record<string, string> | undefined): string[] {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  return Object.keys(value);
}

export async function cpanelListDomains(cfg: CpanelConfig): Promise<CpanelResult<string[]>> {
  const attempts: Array<[string, string]> = [
    ["DomainInfo", "list_domains"],
    ["Domain", "list_domains"],
    ["DomainInfo", "domains_data"],
  ];
  let last = "cPanel list domain gagal";
  for (const [mod, fn] of attempts) {
    const res = await cpanelExecute<CpanelDomainList>(cfg, mod, fn);
    if (!res.ok || !res.data) {
      last = shortErr(res.error);
      continue;
    }
    const data = res.data as CpanelDomainList & { data?: CpanelDomainList };
    const block = data.main_domain ? data : data.data ?? data;
    const list = [
      block.main_domain ?? "",
      ...namesOf(block.addon_domains),
      ...(block.sub_domains ?? []),
      ...(block.parked_domains ?? []),
    ]
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);
    return { ok: true, data: [...new Set(list)], error: "" };
  }
  return { ok: false, data: [], error: last };
}

export async function cpanelAddDomain(
  cfg: CpanelConfig,
  host: string,
): Promise<CpanelResult<unknown>> {
  const sub = (host.split(".")[0] || "lp").replace(/[^a-z0-9-]/g, "").slice(0, 30) || "lp";
  const attempts: Array<[string, string, Record<string, string>]> = [
    ["Domain", "add_domain", { domain: host }],
    ["Park", "park", { domain: host }],
    [
      "AddonDomain",
      "addaddondomain",
      { newdomain: host, subdomain: sub, dir: `public_html/${host}` },
    ],
    [
      "SubDomain",
      "addsubdomain",
      { domain: sub, rootdomain: host.split(".").slice(1).join("."), dir: `public_html/${host}` },
    ],
  ];
  let last = "cPanel tidak bisa membuat domain";
  for (const [mod, fn, params] of attempts) {
    const res = await cpanelExecute(cfg, mod, fn, params);
    if (res.ok) return res;
    last = shortErr(res.error);
  }
  return { ok: false, data: null, error: last };
}

function shortErr(raw: string): string {
  const line = raw.split("\n")[0]?.trim() ?? raw;
  if (line.length > 180) return `${line.slice(0, 177)}…`;
  return line;
}

export async function cpanelDeleteDomain(
  cfg: CpanelConfig,
  host: string,
): Promise<CpanelResult<unknown>> {
  const del = await cpanelExecute(cfg, "Domain", "delete", { domain: host });
  if (del.ok) return del;
  return cpanelExecute(cfg, "AddonDomain", "deladdondomain", {
    domain: host,
    subdomain: host.split(".")[0] || "lp",
  });
}
