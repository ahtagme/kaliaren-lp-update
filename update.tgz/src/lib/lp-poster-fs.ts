import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

function posterDir() {
  return join(process.cwd(), "data", "posters");
}

function posterFile(id: number, panel: 1 | 2, ext: string) {
  return join(posterDir(), `${id}-${panel}.${ext}`);
}

function extFor(mime: string) {
  if (mime.includes("webp")) return "webp";
  if (mime.includes("png")) return "png";
  return "jpg";
}

export function writePosterFile(
  id: number,
  panel: 1 | 2,
  mime: string,
  base64: string,
) {
  const raw = Buffer.from(base64.replace(/\s/g, ""), "base64");
  if (raw.length < 32) return;
  mkdirSync(posterDir(), { recursive: true });
  writeFileSync(posterFile(id, panel, extFor(mime)), raw);
}

export function readPosterFile(
  id: number,
  panel: 1 | 2,
): { mime: string; body: Buffer } | null {
  const dir = posterDir();
  if (!existsSync(dir)) return null;
  for (const [ext, mime] of [
    ["webp", "image/webp"],
    ["jpg", "image/jpeg"],
    ["jpeg", "image/jpeg"],
    ["png", "image/png"],
  ] as const) {
    const path = posterFile(id, panel, ext);
    if (!existsSync(path)) continue;
    const body = readFileSync(path);
    if (body.length > 32) return { mime, body };
  }
  return null;
}
