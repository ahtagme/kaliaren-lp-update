import type { LandingPage, LpSpec, LpTestimonial } from "@/lib/lp";
import { extremeCopyFor } from "@/lib/lp-copy";

export const LP_BADGES = ["100% asli", "Stok gudang", "Sisa terbatas"];

export const LP_WHY = [
  { title: "Stok fisik", text: "Gudang. Bukan PHP." },
  { title: "COD", text: "Cek di kurir, baru bayar." },
  { title: "Terbatas", text: "Sisa dikit. Jangan nanti." },
  { title: "Ikut beli", text: "Yang lain sudah checkout." },
];

export const LP_EDU = [
  "Stok dari gudang. Bukan foto temple.",
  "Cek di kurir. Pas, bayar.",
  "Yang scroll “nanti” biasanya kehabisan.",
  "Ikut yang sudah order. Jangan nyesel.",
];

export const LP_PERKS = [
  "Produk 100% original",
  "Packing aman",
  "Ready stock",
  "Fast response",
  "Praktis dipakai",
  "Cocok dipakai rutin",
  "Siap kirim cepat",
];

export const LP_SPECS: LpSpec[] = [
  { label: "Stok", value: "Fisik gudang, siap kirim" },
  { label: "Bayar", value: "COD. Cek di kurir" },
  { label: "Packing", value: "Aman, bubble + dus" },
  { label: "Retur", value: "Cek di tempat. Deal" },
];

export const LP_TRUST = [
  "Produk sesuai foto",
  "Dikemas aman",
  "Admin cepat balas",
];

export const LP_PROOF_CAPTIONS = [
  "Packing hari ini",
  "Siap kirim gudang",
  "Cek di kurir",
];

export const LP_SHIPPING_PROOF = "/lp/testi-pengiriman.webp";
export const LP_CUSTOMER_PROOF = "/lp/testi-pelanggan.webp";

export const LP_DEFAULT_TESTIMONIALS: LpTestimonial[] = [
  {
    name: "Rina S.",
    city: "Bandung",
    rating: 5,
    text: "Ragu 2 hari. Pas checkout stok tinggal dikit. Untung sempat.",
  },
  {
    name: "Andi P.",
    city: "Bekasi",
    rating: 5,
    text: "Yang lain PHP. Ini barang beneran. COD, cek, bayar. Selesai.",
  },
  {
    name: "Laila M.",
    city: "Surabaya",
    rating: 5,
    text: "Temen beli duluan. Gua nyusul. Kalau masih ada, ambil.",
  },
];

export function lpPhotos(page: LandingPage): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const src of [
    page.heroImageUrl,
    ...(page.gallery ?? []),
    ...(page.productPhotoUrls ?? []),
  ]) {
    const url = (src || "").trim();
    if (!url || seen.has(url)) continue;
    seen.add(url);
    out.push(url);
  }
  return out;
}

export function lpHeadline(page: LandingPage): string {
  const raw = page.headline?.trim();
  if (raw && !looksLikeCatalog(raw, page.productName)) return raw;
  return extremeCopyFor(page.productName).headline;
}

export function lpPunch(page: LandingPage): string {
  const raw = page.subheadline?.trim();
  const text = raw && !looksLikeCatalog(raw, page.productName) ? raw : extremeCopyFor(page.productName).subheadline;
  return text.replace(/COD\.?\s*cek dulu[^.]*(baru bayar)?\.?/gi, "BARANG SESUAI FOTO. SIAP KIRIM.");
}

function looksLikeCatalog(text: string, name: string): boolean {
  const t = text.toLowerCase();
  const n = name.toLowerCase();
  if (t === n || t.startsWith(n)) return true;
  return /isi\s*\d|stok terbatas|ready stock|hpp/i.test(text);
}
