import { createServerFn } from "@tanstack/react-start";
import { Resolver } from "node:dns/promises";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { parseCdnBase, publicOrigin } from "@/lib/cdn";
import {
  LP_A_RECORD_IP,
  isCloudflareIp,
  mergeDomainChoices,
  normalizeLpHost,
  parseLpDomainRecords,
  type LpDomain,
} from "@/lib/lp-domains";
import { assertActiveStaff } from "@/lib/staff-fn";
import { decryptSecret, encryptSecret } from "@/lib/secret";
import { cpanelAddDomain, cpanelDeleteDomain, cpanelListDomains } from "@/lib/cpanel";
import { setXaiSettingsKey } from "@/lib/xai";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

async function readSetting(key: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql.query<{ value: string }>(
    `select value from app_settings where key = $1`,
    [key],
  );
  return rows[0]?.value?.trim() ?? "";
}

function primaryHost(): string {
  const raw = process.env.BETTER_AUTH_URL?.trim();
  if (raw) {
    try {
      return normalizeLpHost(new URL(raw).host);
    } catch {
      /* ignore */
    }
  }
  return normalizeLpHost(publicOrigin()) || "store.ahtagroup.com";
}

async function writeDomains(records: LpDomain[]): Promise<void> {
  const sql = await getSql();
  await sql.query(
    `insert into app_settings (key, value, updated_at)
     values ('lp_domains', $1, now())
     on conflict (key) do update set value = excluded.value, updated_at = now()`,
    [JSON.stringify(records)],
  );
}

async function resolveIps(host: string): Promise<string[]> {
  const resolver = new Resolver();
  resolver.setServers(["1.1.1.1", "8.8.8.8"]);
  const timer = setTimeout(() => resolver.cancel(), 4000);
  try {
    const ips = await resolver.resolve4(host);
    return [...new Set(ips)];
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    if (code === "ENOTFOUND" || code === "ENODATA" || code === "CANCELLED") return [];
    return [];
  } finally {
    clearTimeout(timer);
  }
}

async function expectedIps(): Promise<string[]> {
  const primary = primaryHost();
  const ips = primary ? await resolveIps(primary) : [];
  if (!ips.includes(LP_A_RECORD_IP)) ips.push(LP_A_RECORD_IP);
  return ips;
}

async function verifyHost(host: string): Promise<LpDomain> {
  const ips = await resolveIps(host);
  if (ips.length === 0) {
    return {
      host,
      status: "invalid",
      detail: `Domain tidak ketemu di DNS. Pasang A record ke ${LP_A_RECORD_IP}`,
    };
  }
  const expected = await expectedIps();
  const hit = ips.some((ip) => expected.includes(ip));
  const viaCf = ips.some((ip) => isCloudflareIp(ip));
  if (!hit && !viaCf) {
    return {
      host,
      status: "pending",
      detail: `DNS masih ${ips.join(", ")}. Ubah A record ke ${LP_A_RECORD_IP}`,
    };
  }
  return {
    host,
    status: "active",
    detail: viaCf && !hit
      ? `Aktif · Cloudflare → origin ${LP_A_RECORD_IP}`
      : `Aktif · A ${ips.filter((ip) => expected.includes(ip) || isCloudflareIp(ip)).join(", ")}`,
  };
}

async function writeSetting(key: string, value: string): Promise<void> {
  const sql = await getSql();
  await sql.query(
    `insert into app_settings (key, value, updated_at)
     values ($1, $2, now())
     on conflict (key) do update set value = excluded.value, updated_at = now()`,
    [key, value],
  );
}

async function readCpanelConfig() {
  const host = await readSetting("cpanel_host");
  const user = await readSetting("cpanel_user");
  const token = decryptSecret(await readSetting("cpanel_token"));
  return { host, user, token };
}

async function attachProxy(host: string): Promise<string> {
  const bin = process.env.KALIAREN_CONNECT_BIN?.trim() || "/usr/local/sbin/kaliaren-connect-domain";
  try {
    const { stdout, stderr } = await execFileAsync("sudo", ["-n", bin, host], {
      timeout: 45000,
      env: { ...process.env, KALIAREN_CPANEL_USER: "dewastoreid" },
    });
    return (stdout || stderr || "ok").trim();
  } catch (err) {
    const msg = err instanceof Error ? err.message : "proxy gagal";
    if (msg.includes("ENOENT") || msg.includes("sudo")) {
      return "";
    }
    return "";
  }
}

export async function resolveCdnBase(): Promise<string> {
  const custom = parseCdnBase(await readSetting("image_cdn"));
  if (custom && !custom.startsWith("weserv:")) return custom;
  const origin = publicOrigin();
  if (origin) return `weserv:${origin}`;
  return "";
}

export const getImageCdn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await assertActiveStaff(context.userId);
    return {
      base: parseCdnBase(await readSetting("image_cdn")),
      auto: Boolean(publicOrigin()),
    };
  });

export const setImageCdn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ base: z.string().max(300) }))
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin yang bisa mengatur CDN");
    const base = parseCdnBase(data.base);
    const sql = await getSql();
    await sql.query(
      `insert into app_settings (key, value, updated_at)
       values ('image_cdn', $1, now())
       on conflict (key) do update set value = excluded.value, updated_at = now()`,
      [base],
    );
    return { ok: true as const, base };
  });

export const listLpDomains = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await assertActiveStaff(context.userId);
    const primary = primaryHost();
    const extra = parseLpDomainRecords(await readSetting("lp_domains")).filter(
      (d) => d.host !== primary,
    );
    return {
      primary,
      extra,
      extraHosts: extra.map((d) => d.host),
      choices: mergeDomainChoices(
        primary,
        extra.map((d) => d.host),
      ),
    };
  });

export const saveLpDomains = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ domains: z.array(z.string().max(80)).max(40) }))
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin yang bisa menambah domain");
    const primary = primaryHost();
    const existing = parseLpDomainRecords(await readSetting("lp_domains"));
    const wanted = [...new Set(data.domains.map(normalizeLpHost).filter(Boolean))].filter(
      (h) => h !== primary,
    );
    const byHost = new Map(existing.map((d) => [d.host, d]));
    const extra: LpDomain[] = wanted.map(
      (host) => byHost.get(host) ?? { host, status: "pending", detail: "Belum dicek" },
    );
    await writeDomains(extra);
    return {
      ok: true as const,
      primary,
      extra,
      extraHosts: extra.map((d) => d.host),
      choices: mergeDomainChoices(
        primary,
        extra.map((d) => d.host),
      ),
    };
  });

export const connectLpDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ host: z.string().max(80) }))
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin yang bisa menambah domain");
    const host = normalizeLpHost(data.host);
    if (!host) throw new Error("Nama domain tidak valid");
    const primary = primaryHost();
    if (host === primary) throw new Error("Itu domain utama, tidak perlu ditambah");
    const checked = await verifyHost(host);
    const notes: string[] = [];
    const cfg = await readCpanelConfig();
    if (cfg.token) {
      const added = await cpanelAddDomain(cfg, host);
      notes.push(added.ok ? "cPanel: domain dibuat" : `cPanel: ${added.error}`);
    } else {
      notes.push("cPanel belum diisi di Pengaturan");
    }
    const proxy = await attachProxy(host);
    if (proxy) notes.push("Proxy Apache: ok");
    else notes.push("Proxy: belum. Pasang skrip sekali di VPS.");
    if (checked.status === "active" && proxy) {
      checked.detail = `Aktif · ${notes.join(" · ")}`;
    } else if (checked.status === "active") {
      checked.detail = `${checked.detail} · ${notes.join(" · ")}`;
    } else {
      checked.detail = `${checked.detail} · ${notes.join(" · ")}`;
    }
    const extra = parseLpDomainRecords(await readSetting("lp_domains")).filter(
      (d) => d.host !== primary && d.host !== host,
    );
    extra.push(checked);
    await writeDomains(extra);
    return {
      ok: true as const,
      primary,
      domain: checked,
      extra,
      extraHosts: extra.map((d) => d.host),
      choices: mergeDomainChoices(
        primary,
        extra.map((d) => d.host),
      ),
    };
  });

export const refreshLpDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ host: z.string().max(80).optional() }))
  .handler(async ({ data, context }) => {
    await assertActiveStaff(context.userId);
    const primary = primaryHost();
    const extra = parseLpDomainRecords(await readSetting("lp_domains")).filter(
      (d) => d.host !== primary,
    );
    const targets = data.host ? extra.filter((d) => d.host === normalizeLpHost(data.host ?? "")) : extra;
    const checked = await Promise.all(targets.map((d) => verifyHost(d.host)));
    const byHost = new Map(checked.map((d) => [d.host, d]));
    const next = extra.map((d) => byHost.get(d.host) ?? d);
    await writeDomains(next);
    return {
      ok: true as const,
      primary,
      extra: next,
      extraHosts: next.map((d) => d.host),
      choices: mergeDomainChoices(
        primary,
        next.map((d) => d.host),
      ),
    };
  });

export const getCpanelConfig = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const cfg = await readCpanelConfig();
    return {
      host: cfg.host,
      user: cfg.user,
      hasToken: Boolean(cfg.token),
    };
  });

export const saveCpanelConfig = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      host: z.string().max(120),
      user: z.string().max(80),
      token: z.string().max(300),
    }),
  )
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const host = data.host.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
    await writeSetting("cpanel_host", host);
    await writeSetting("cpanel_user", data.user.trim());
    if (data.token.trim()) {
      await writeSetting("cpanel_token", encryptSecret(data.token.trim()));
    }
    return { ok: true as const, host, user: data.user.trim() };
  });

export const testCpanel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const cfg = await readCpanelConfig();
    const listed = await cpanelListDomains(cfg);
    if (!listed.ok) return { ok: false as const, error: listed.error, domains: [] as string[] };
    return { ok: true as const, error: "", domains: listed.data ?? [] };
  });

export const removeLpDomain = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ host: z.string().max(80), deleteCpanel: z.boolean().optional() }))
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const host = normalizeLpHost(data.host);
    const primary = primaryHost();
    const extra = parseLpDomainRecords(await readSetting("lp_domains")).filter(
      (d) => d.host !== host && d.host !== primary,
    );
    await writeDomains(extra);
    if (data.deleteCpanel) {
      const cfg = await readCpanelConfig();
      if (cfg.token) await cpanelDeleteDomain(cfg, host);
    }
    return {
      ok: true as const,
      primary,
      extra,
      extraHosts: extra.map((d) => d.host),
      choices: mergeDomainChoices(
        primary,
        extra.map((d) => d.host),
      ),
    };
  });

export const getAiConfig = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const env = Boolean(process.env.XAI_API_KEY?.trim());
    const stored = Boolean(decryptSecret(await readSetting("xai_key")));
    return { hasKey: env || stored, fromEnv: env };
  });

export const saveAiKey = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ key: z.string().max(200) }))
  .handler(async ({ data, context }) => {
    const profile = await assertActiveStaff(context.userId);
    if (profile.role !== "admin") throw new Error("Hanya admin");
    const key = data.key.trim();
    if (key) {
      await writeSetting("xai_key", encryptSecret(key));
      setXaiSettingsKey(key);
    }
    return { ok: true as const, hasKey: Boolean(key || process.env.XAI_API_KEY) };
  });

